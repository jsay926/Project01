create PROCEDURE PRODUCT_DEPEND_FOR_HD is
     v_product_code     NUMBER(12);
     v_product_name    VARCHAR2(200);
begin
    for cur in ( SELECT  t.relat_product_item_id  from product.up_plan_prod_rel t WHERE 1 = 1  and t.extend_attr_f=800300000001 and t.product_item_id in (800500070003,800500070001) and t.del_flag=0)  loop
     select  p.product_item_id, p.name into v_product_code, v_product_name from product.up_product_item p WHERE 1 = 1 and p.product_item_id=cur.relat_product_item_id and p.item_type='SERVICE_PRICE';
         insert into base.cfg_static_data (
           CODE_TYPE,
           CODE_VALUE,
           CODE_NAME,
            CODE_DESC,
            CODE_TYPE_ALIAS,
            SORT_ID,
            STATE,
            EXTERN_CODE_TYPE,
            CORP_ORG_ID,
            ENT_ID)
        values (
            'PRODUCT_DEPEND',
            v_product_code,
            v_product_code,
            v_product_name,
             '',
             1,
             '1',
              '',
             null,
             null);
     commit;
    end loop;

exception
   when others then
      rollback;

end PRODUCT_DEPEND_FOR_HD;





/

