create FUNCTION     rmicaller RETURN VARCHAR2 AS
  LANGUAGE JAVA NAME 'Client.SimpleRMIClient.rmicaller () return java.lang.String';


/

