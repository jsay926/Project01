create PROCEDURE       "GET_INS_DATA" 
(
in_cust_code  in varchar2
) 
IS

lv_where_str   varchar2(1000);
ln_count  number;
ln_year   varchar2(1000);

lr_cm_customer   so1.cm_customer%rowtype;

begin
  
dbms_output.enable;

  select to_char(trunc(sysdate),'yyyy') into ln_year
  from dual;
  
  select * into  lr_cm_customer
  from so1.cm_customer
  where cust_code=in_cust_code;
  lv_where_str:=' where cust_id='||lr_cm_customer.cust_id;
  --??????
  print_insert('cm_customer',lv_where_str);
  print_insert('H_CM_CUSTOMER_'||ln_year,lv_where_str);
  --??????
  print_insert('acct',lv_where_str);
  print_insert('H_acct_'||ln_year,lv_where_str);
  
  --??INS_ADDRESS??
  print_insert('INS_ADDRESS',lv_where_str);
  print_insert('H_INS_ADDRESS_'||ln_year,lv_where_str);
  
  --??INS_OFFER??
  print_insert('INS_OFFER',lv_where_str);
  print_insert('H_INS_OFFER_'||ln_year,lv_where_str);
  
/*  
    --??INS_ACCREL??
  print_insert('INS_ACCREL',lv_where_str);
  print_insert('H_INS_ACCREL_'||ln_year,lv_where_str);
  */
  
  
  
    --??INS_OFF_INS_PROD_REL??
  print_insert('INS_OFF_INS_PROD_REL',lv_where_str);
  print_insert('H_INS_OFF_INS_PROD_REL_'||ln_year,lv_where_str);
  
    --??INS_PROD??
  print_insert('INS_PROD',lv_where_str);
  print_insert('H_INS_PROD_'||ln_year,lv_where_str);
  
    --??INS_PROD_RES??
  print_insert('INS_PROD_RES',lv_where_str);
  print_insert('H_INS_PROD_RES_'||ln_year,lv_where_str);
  
  lv_where_str:=' where prod_inst_id in (select prod_inst_id from ins_prod where cust_id='||lr_cm_customer.cust_id||')';
  
      --??INS_SRVPKG??
  print_insert('INS_SRVPKG',lv_where_str);
  print_insert('H_INS_SRVPKG_'||ln_year,lv_where_str);
  
  
      --??INS_SRVPKG_INS_SRV_REL??
  print_insert('INS_SRVPKG_INS_SRV_REL',lv_where_str);
  print_insert('H_INS_SRVPKG_INS_SRV_REL_'||ln_year,lv_where_str);
  
  
      --??INS_SRV??
  print_insert('INS_SRV',lv_where_str);
  print_insert('H_INS_SRV_'||ln_year,lv_where_str);
  
  
      --??INS_SRV_ATTR??
  print_insert('INS_SRV_ATTR',lv_where_str);
  print_insert('H_INS_SRV_ATTR_'||ln_year,lv_where_str);
  
      --??INS_PRICE??
  print_insert('INS_PRICE',lv_where_str);
  print_insert('H_INS_PRICE_'||ln_year,lv_where_str);
    
exception
   when others then
      rollback;
end;









/

