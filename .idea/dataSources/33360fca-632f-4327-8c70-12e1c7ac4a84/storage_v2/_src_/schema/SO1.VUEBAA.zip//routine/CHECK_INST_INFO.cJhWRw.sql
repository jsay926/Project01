create PROCEDURE       "CHECK_INST_INFO" 
  ( 
     in_cust_order_id IN number,
    in_log_level     number default 1  -- 1 error  2 info  3 debug   
    )
 IS
/****************************************************************************************************************************************************************************************************
检查业务订单表
*****************************************************************************************************************************************************************************************************/
CURSOR cur_ins_prod(iln_cust_id  number)
IS
select * from so1.ins_prod
where cust_id=iln_cust_id;


CURSOR cur_srvpkg_price_plan(in_prod_inst_id  number)
IS
select  c.SRVPKG_INST_ID,c.OFFER_INST_ID,c.SRVPKG_ID ,c.PROD_INST_ID,c.VALID_TYPE,c.OPER_STATE,c.STATE ,c.REGION_ID ,c.CREATE_DATE ,c.DONE_CODE ,c.DONE_DATE ,c.VALID_DATE,c.EXPIRE_DATE ,c.OP_ID ,c.ORG_ID,c.SRC_SYSTEM_ID ,c.SRC_SYSTEM_EXT_CODE ,c.PROD_SERVICE_ID ,c.OS_STATUS ,b.PRICE_PLAN_ID,b.PRICE_PLAN_TYPE_CD,b.PARA_FLAG,b.INTERFACE_CODE,b.DEL_FLAG,b.CHARGE_ITEM ,nvl(d.extend_id ,-1)
from  product.up_item_relat  a, product.up_price_plan b,so1.ins_srvpkg c,product.up_product_item d
where a.relat_product_item_id=b.price_plan_id
and prod_item_relat_kind_id in ('SERVICE_PRICE_GENERAL_PRICE_PLAN_PKG_BOSS','SERVICE_PRICE_GENERAL_PRICE_PLAN_PKG_BILLING')
and  a.product_item_id=c.srvpkg_id
and b.price_plan_id=d.product_item_id
and c.prod_inst_id=in_prod_inst_id;


lv_sql                        varchar2(3000);
lv_info                        varchar2(3000);


  TYPE INS_SRVPKG_PRICE_PLAN_WHY IS RECORD (
        SRVPKG_INST_ID      NUMBER(12)  ,
        OFFER_INST_ID  NUMBER(12)  ,      
        SRVPKG_ID    NUMBER(12)  ,      
        PROD_INST_ID    NUMBER(14)  ,      
        VALID_TYPE    NUMBER(2)    ,    
        OPER_STATE    NUMBER(12)  ,      
        STATE    NUMBER(2)  ,      
        REGION_ID    VARCHAR2(6),    
        CREATE_DATE    DATE  ,      
        DONE_CODE    NUMBER(15)    ,    
        DONE_DATE    DATE  ,  
        VALID_DATE      DATE    ,      
        EXPIRE_DATE    DATE  ,
        OP_ID    NUMBER(12)  ,  
        ORG_ID    NUMBER(12)  ,      
        SRC_SYSTEM_ID    NUMBER (12)    ,    
        SRC_SYSTEM_EXT_CODE    VARCHAR2(200)  ,    
        PROD_SERVICE_ID    NUMBER(12)  ,    
        OS_STATUS    VARCHAR2(30)  ,
        PRICE_PLAN_ID  NUMBER (12)    ,        
        PRICE_PLAN_TYPE_CD    VARCHAR2 (40)  ,          
        PARA_FLAG   NUMBER (2)          ,  
        INTERFACE_CODE  VARCHAR2 (50 )    ,              
        DEL_FLAG    NUMBER (2)        ,                
        CHARGE_ITEM    NUMBER (12),
        extend_id    NUMBER
   );
  lr_INS_SRVPKG   INS_SRVPKG_PRICE_PLAN_WHY;




lr_ins_prod                    so1.ins_prod%rowtype;
lr_cm_customer                so1.cm_customer%rowtype;
lr_ins_address                so1.ins_address%rowtype;
lr_org                        sec.sec_organize%rowtype;
lr_std                        pBOSS.ADDR_STD_ADDR%rowtype;
lr_i_user                      zg.i_user%rowtype;
lr_i_user_plan                 zg.i_user_plan%rowtype;
lr_i_user_status                 zg.i_user_status%rowtype;

lr_i_user_msc                zg.i_user_msc%rowtype;
lr_i_user_sprom                zg.i_user_sprom%rowtype;
lr_i_user_prod_sts            zg.i_user_prod_sts%rowtype;

ln_OWN_ORG_ORGTYPE            number;
ln_temp                        number;
ln_os_status                  number;
ln_param_temp                  number;
ln_prod_sts_temp              number;
ln_cust_id                    number;

ln_shuzi_spec                  number:=800200000001;
    
lv_boss_run                                        VARCHAR2(10);

            
 
 
 
/*声明函数*/
function get_product_info (in_product_item_id  number) return number
as
ln_product_item_id  number;
begin  
  
  select product_item_id  
  into ln_product_item_id
  from product.up_product_item
  where product_item_id=in_product_item_id;
  
exception
  when no_data_found then
    return -1;
  when others  then
    return -2;        
end;

 
 
 
 

BEGIN
  
  dbms_output.enable(10000000000);
  execute immediate 'alter session set nls_date_format='||''''||'yyyy-mm-dd hh24:mi:ss'||'''';
  
  begin
    select distinct (cust_id) into ln_cust_id
    from  so1.ord_cust_f_2011
    where cust_order_id=in_cust_order_id;
  exception
  when no_data_found then
    lv_info:='根据cust_order_id:'||in_cust_order_id||'查询so1.ord_cust_f_2011，没有查询到数据,无法获取cust_id！！！'||chr(10);
    WHY_save_log(in_cust_order_id,lv_info,in_log_level,1);
    goto proc_end;
  end;
    
  begin
    select code_value into lv_boss_run
    from  base.cfg_static_data
    where code_type='BOSS_RUN';
  exception
  when no_data_found then
      lv_boss_run:='CQ';
      lv_info:='base.cfg_static_data表中参数BOSS_RUN配置错误,默认为“CQ”'||chr(10);
      WHY_save_log(in_cust_order_id,lv_info,in_log_level,1);
  end; 
    
    
  
   begin
    select to_number(code_value) into ln_OWN_ORG_ORGTYPE
    from  base.cfg_static_data
    where code_type='OWN_ORG_ORGTYPE';
  exception
  when no_data_found then
    lv_info:='base.cfg_static_data表中参数OWN_ORG_ORGTYPE配置错误'||chr(10);
    WHY_save_log(in_cust_order_id,lv_info,in_log_level,1);
    goto proc_end;
  end;
  
  
  BEGIN
    select * into  lr_cm_customer
    from so1.cm_customer
    where cust_id=ln_cust_id;        
    
    lr_org:=FUNC_GET_ORG_NAME(lr_cm_customer.own_org_id);
    if(lr_org.organize_id is null) then
      lv_info:='';
      lv_info:='【own_org_id:='||lr_cm_customer.own_org_id||'】在sec.sec_organize中没有定义，可能导致查不出客户信息！！！'||chr(10);
      WHY_save_log(in_cust_order_id,lv_info,in_log_level,1);
    else
      if(lr_org.org_role_type_id<>ln_OWN_ORG_ORGTYPE) then
        lv_info:='';
        lv_info:='【own_org_id:='||lr_cm_customer.own_org_id||'】的组织类型（sec.sec_organize.org_role_type_id）不是数据区或分公司类型！！！'||chr(10);
        WHY_save_log(in_cust_order_id,lv_info,in_log_level,1);
      end if;
    end if;
    
    lr_org:=FUNC_GET_ORG_NAME(lr_cm_customer.own_corp_org_id);
    if(lr_org.organize_id is null) then
      lv_info:='';
      lv_info:='【own_org_id:='||lr_cm_customer.own_corp_org_id||'】在sec.sec_organize中没有定义，可能导致查不出客户信息！！！'||chr(10);
      WHY_save_log(in_cust_order_id,lv_info,in_log_level,1);
    end if;
    
    lr_org:=FUNC_GET_ORG_NAME(lr_cm_customer.ORG_ID);
    if(lr_org.organize_id is null) then
      lv_info:='';
      lv_info:='【客户的ORG_ID:='||lr_cm_customer.ORG_ID||'】在sec.sec_organize中没有定义，可能导致查不出客户信息！！！'||chr(10);
      WHY_save_log(in_cust_order_id,lv_info,in_log_level,1);     
    end if;
    
    
    ln_temp:=0;
    select count(*) into ln_temp
    from   sec.sec_operator
    where operator_id=lr_cm_customer.op_id;
    
    if(ln_temp<>1) then
      lv_info:='';
      lv_info:='【op_id:='||lr_cm_customer.op_id||'】在sec.sec_operator中没有定义，可能导致查不出客户信息！！！'||chr(10);
      WHY_save_log(in_cust_order_id,lv_info,in_log_level,1);     
    end if;
    
  EXCEPTION
    when no_data_found then
      lv_info:='';
      lv_info:='根据【cust_id:='||lr_cm_customer.cust_id||'】在so1.cm_customer没有查询到记录！！！'||chr(10);
      WHY_save_log(in_cust_order_id,lv_info,in_log_level,1); 
      goto  proc_end;
    when others  then
      lv_info:='';
      lv_info:='根据【cust_id:='||lr_cm_customer.cust_id||'】查询so1.cm_customer表出错！！！'||chr(10);  
      WHY_save_log(in_cust_order_id,lv_info,in_log_level,1); 
      goto  proc_end;    
  END;
  
  BEGIN
    select * into  lr_ins_address
    from so1.ins_address
    where cust_id=lr_cm_customer.cust_id;  
    
    ln_temp:=0;
    select count(*) into ln_temp
    from   pBOSS.ADDR_STD_ADDR
    where std_addr_id=lr_ins_address.std_addr_id;
    
    if(ln_temp<=0) then
      lv_info:='';
      lv_info:='根据【std_addr_id:='||lr_ins_address.std_addr_id||'】在PBOSS.ADDR_STD_ADDR没有查询到记录！！！'||chr(10);
      lv_info:=lv_info||'【select count(*) into ln_temp
    from   pBOSS.ADDR_STD_ADDR
    where std_addr_id='||lr_ins_address.std_addr_id||'】'||chr(10);      
      WHY_save_log(in_cust_order_id,lv_info,in_log_level,1);
    elsif(ln_temp>1)then  
      lv_info:='';
      lv_info:='根据【std_addr_id:='||lr_ins_address.std_addr_id||'】在PBOSS.ADDR_STD_ADDR查询到<'||ln_temp||'条>记录！！！'||chr(10);
      lv_info:=lv_info||'【select count(*) into ln_temp
    from   pBOSS.ADDR_STD_ADDR
    where std_addr_id='||lr_ins_address.std_addr_id||'】'||chr(10);
      WHY_save_log(in_cust_order_id,lv_info,in_log_level,1);
    end if;
    
  EXCEPTION
    when no_data_found then
      lv_info:='';
      lv_info:='根据【cust_id:='||lr_cm_customer.cust_id||'】在so1.ins_address没有查询到记录！！！'||chr(10);
      WHY_save_log(in_cust_order_id,lv_info,in_log_level,1);   
    when others  then
      lv_info:='';
      lv_info:='根据【cust_id:='||lr_cm_customer.cust_id||'】查询so1.ins_address表出错！！！'||chr(10);  
      WHY_save_log(in_cust_order_id,lv_info,in_log_level,1);   
  END;  
  
  ln_temp:=0;
  select count(*) 
  into ln_temp
  from so1.ins_offer  a
  where a.cust_id=ln_cust_id
  and not exists (
    select * from so1.ins_off_ins_prod_rel  b
    where b.cust_id=ln_cust_id
    and a.offer_inst_id=b.offer_inst_id
    and a.offer_id=b.offer_id
    and decode(a.offer_type,1,1,2,0,99)=b.is_main_offer
    and a.main_role_prod_id=b.prod_spec_id
  );
  
  if(ln_temp>0) then
      lv_info:='';
      lv_info:='根据【cust_id:='||ln_cust_id||'】在ins_offer中有的offer_inst_id在so1.ins_off_ins_prod_rel中找不到对应的记录，或offer_type,main_role_prod_id不对应！！！'||chr(10);
      lv_info:=lv_info||'【 select count(*) 
  into ln_temp
  from so1.ins_offer  a
  where a.cust_id=ln_cust_id
  and not exists (
    select * from so1.ins_off_ins_prod_rel  b
    where b.cust_id='||ln_cust_id||'
    and a.offer_inst_id=b.offer_inst_id
    and a.offer_id=b.offer_id
    and decode(a.offer_type,1,1,2,0,99)=b.is_main_offer
    and a.main_role_prod_id=b.prod_spec_id】'||chr(10);          
      WHY_save_log(in_cust_order_id,lv_info,in_log_level,1);
  end if;
  
  OPEN cur_ins_prod(ln_cust_id);
  LOOP
     fetch cur_ins_prod into lr_ins_prod;
     exit when cur_ins_prod%notfound;
     
         lr_org:=FUNC_GET_ORG_NAME(lr_ins_prod.own_org_id);
        if(lr_org.organize_id is null) then
          lv_info:='';
          lv_info:='【用户'||lr_ins_prod.PROD_INST_ID||'的own_org_id:='||lr_ins_prod.own_org_id||'】在sec.sec_organize中没有定义，可能导致查不出用户信息！！！'||chr(10);
          WHY_save_log(in_cust_order_id,lv_info,in_log_level,1); 
        else
          if(lr_org.org_role_type_id<>ln_OWN_ORG_ORGTYPE) then
            lv_info:='';
            lv_info:='【用户'||lr_ins_prod.PROD_INST_ID||'的own_org_id:='||lr_ins_prod.own_org_id||'】的组织类型（sec.sec_organize.org_role_type_id）不是数据区或分公司类型！！！'||chr(10);
            WHY_save_log(in_cust_order_id,lv_info,in_log_level,1);
          end if;
        end if;
        
        lr_org:=FUNC_GET_ORG_NAME(lr_ins_prod.own_corp_org_id);
        if(lr_org.organize_id is null) then
          lv_info:='';
          lv_info:='【用户'||lr_ins_prod.PROD_INST_ID||'的own_corp_org_id:='||lr_ins_prod.own_corp_org_id||'】在sec.sec_organize中没有定义，可能导致查不出客户信息！！！'||chr(10);
          WHY_save_log(in_cust_order_id,lv_info,in_log_level,1);     
        end if;
        
        
        lr_org:=FUNC_GET_ORG_NAME(lr_ins_prod.ORG_ID);
        if(lr_org.organize_id is null) then
          lv_info:='';
          lv_info:='【用户'||lr_ins_prod.PROD_INST_ID||'的org_id:='||lr_ins_prod.ORG_ID||'】在sec.sec_organize中没有定义，可能导致查不出客户信息！！！'||chr(10);
          WHY_save_log(in_cust_order_id,lv_info,in_log_level,1);     
        end if;
          
          
        ln_temp:=0;
        select count(*) into ln_temp
        from   so1.INS_ACCREL  
        where PROD_INST_ID=lr_ins_prod.prod_inst_id
        and   offer_inst_id=lr_ins_prod.offer_inst_id
        and  acct_id=lr_ins_prod.acct_id
        and  VALID_DATE=lr_ins_prod.VALID_DATE
        and  CHARGE_ITEM_id=82000001
        and CHARGE_type=1
        and pay_mode=1
        and pay_value=9999999
        and state=1;
        
        if(ln_temp<>1) then
          lv_info:='';
          lv_info:='用户：<'||lr_ins_prod.prod_inst_id||'>查询在INS_ACCREL表没有找到对应的记录！！！'||chr(10);  
          lv_info:=lv_info||'【select count(*)
                from   so1.INS_ACCREL  
                where PROD_INST_ID='||lr_ins_prod.prod_inst_id||'
                and   offer_inst_id='||lr_ins_prod.offer_inst_id||'
                and  acct_id='||lr_ins_prod.acct_id||'
                and  VALID_DATE='||lr_ins_prod.VALID_DATE||'
                and  CHARGE_ITEM_id=82000001
                and CHARGE_type=1
                and pay_mode=1
                and pay_value=9999999
                and state=1;】'||chr(10);
          
          WHY_save_log(in_cust_order_id,lv_info,in_log_level,1);     
        end if;
        
        
        ln_temp:=0;
        select count(*) into ln_temp
        from   sec.sec_operator
        where operator_id=lr_ins_prod.op_id;
        
        if(ln_temp<>1) then
          lv_info:='';
          lv_info:='【ins_prod表的op_id:='||lr_ins_prod.op_id||'】在sec.sec_operator中没有定义或有多条，可能导致查不出用户信息！！！'||chr(10);
          WHY_save_log(in_cust_order_id,lv_info,in_log_level,1);     
        end if;
     
     
     
         
         --检查用户的offer_id是否为基本套餐
             if(lr_ins_prod.prod_spec_id=800200000015)     then
                 ln_temp:=0;
                 select count(*) into ln_temp
                 from product.up_product_item a,product.up_offer B
                 where a.product_item_id=b.offer_id
                 and b.offer_id=lr_ins_prod.offer_id
                 and b.offer_type='OFFER_COMPOSITE'
                 and a.state=5;
             else
                 ln_temp:=0;
                 select count(*) into ln_temp
                 from product.up_product_item a,product.up_offer B
                 where a.product_item_id=b.offer_id
             and b.offer_id=lr_ins_prod.offer_id
             and b.offer_type='OFFER_PLAN'
             and a.state=5;
           end if;
                  
         if(ln_temp<=0) then
           lv_info:='';
          lv_info:='用户：<'||lr_ins_prod.prod_inst_id||'>根据【offer_id:='||lr_ins_prod.offer_id||'】查询product.up_product_item a,product.up_offer b表 没有找到OFFER_TYPE=OFFER_PLAN的记录！！！'||chr(10);  
          lv_info:=lv_info||'【select count(*) into ln_temp
         from product.up_product_item a,product.up_offer B
         where a.product_item_id=b.offer_id
         and b.offer_id='||lr_ins_prod.offer_id||'
         and b.offer_type in (''''OFFER_PLAN'''',''''OFFER_COMPOSITE'''')
         and a.state=5;】'||chr(10);
          
          WHY_save_log(in_cust_order_id,lv_info,in_log_level,1); 
         end if;
         
         --检查用户的规格ID是否有定义
         ln_temp:=0;
         select count(*) into ln_temp
         from product.up_product_item
         where product_item_id=lr_ins_prod.prod_spec_id
         and item_type='PRODUCT_SPEC'
         and state=5;
                  
         if(ln_temp<=0) then
           lv_info:='';
          lv_info:='用户：<'||lr_ins_prod.prod_inst_id||'>根据【prod_spec_id:='||lr_ins_prod.prod_spec_id||'】查询product.up_product_item 表 没有找到ITEM_TYPE=PRODUCT_SPEC的记录！！！'||chr(10);  
          WHY_save_log(in_cust_order_id,lv_info,in_log_level,1); 
         end if;
         
         
         --检查数字电视且state=1的用户的设备是否有对应的资源记录
         if(lr_ins_prod.prod_spec_id=ln_shuzi_spec  and lr_ins_prod.state='1') then
           ln_temp:=0;
           select count(*) into ln_temp
           from res.res_terminal
           where serial_no=lr_ins_prod.bill_id           
           and state=3;
           
           if(ln_temp<=0) then
             lv_info:='';
            lv_info:='用户：<'||lr_ins_prod.prod_inst_id||'>根据【bill_id:='||lr_ins_prod.bill_id||'】查询res.res_terminal 表 没有找到state=3的记录！！！'||chr(10);  
            WHY_save_log(in_cust_order_id,lv_info,in_log_level,1);
           end if;
           
           ln_temp:=0;
           select count(*) into ln_temp
           from res.res_terminal
           where serial_no=lr_ins_prod.sub_bill_id
           and state=3;
           
           if(ln_temp<=0) then
             lv_info:='';
            lv_info:='用户：<'||lr_ins_prod.prod_inst_id||'>根据【sub_bill_id:='||lr_ins_prod.sub_bill_id||'】查询res.res_terminal 表 没有找到state=3的记录！！！'||chr(10);  
            WHY_save_log(in_cust_order_id,lv_info,in_log_level,1);
           end if;
           --检查数字电视且state=1的用户的设备在ins_prod_res是否有记录
           ln_temp:=0;
           select count(distinct cust_id) into ln_temp
           from so1.ins_prod_res
           where res_equ_no=lr_ins_prod.bill_id;
           
           if(ln_temp<>1) then
               lv_info:='';
              lv_info:='用户：<'||lr_ins_prod.prod_inst_id||'>根据【bill_id:='||lr_ins_prod.bill_id||'】查询ins_prod_res 表 没有找到或找到多条记录！！！'||chr(10);  
              lv_info:=lv_info||'【select count(distinct cust_id)
               from so1.ins_prod_res
               where res_equ_no='||lr_ins_prod.bill_id||'】'||chr(10);
              WHY_save_log(in_cust_order_id,lv_info,in_log_level,1);
           end if;
           
           ln_temp:=0;
           select count(*) into ln_temp
           from so1.ins_prod_res
           where res_equ_no=lr_ins_prod.sub_bill_id;
           
           if(ln_temp<>1) then
             lv_info:='';
            lv_info:='用户：<'||lr_ins_prod.prod_inst_id||'>根据【sub_bill_id:='||lr_ins_prod.sub_bill_id||'】查询ins_prod_res 表 没有找到或找到多条记录！！！'||chr(10);  
            lv_info:=lv_info||'【select count(*) into ln_temp
           from so1.ins_prod_res
           where res_equ_no='||lr_ins_prod.sub_bill_id||'】'||chr(10);
            WHY_save_log(in_cust_order_id,lv_info,in_log_level,1);
           end if;
           
           
           ln_temp:=0;    
           select count(*) into ln_temp
           from so1.ins_prod_res  a
           where not exists
           (
                   select * from res.res_terminal b
                   where b.serial_no=a.res_equ_no
                   and a.res_code=b.res_code
                   and b.state=3
           )  and a.prod_inst_id=lr_ins_prod.prod_inst_id
           or not exists
           (
                   select * from res.RES_PHONE_NUM_ORIGIN c
                   where c.bill_id=a.res_equ_no
                   and a.res_code=c.res_code
                   and c.MANAGE_STATE=3
           );
           
           if(ln_temp<>0) then
             lv_info:='';
            lv_info:='用户：<'||lr_ins_prod.prod_inst_id||'>查询ins_prod_res 表在res.res_terminal 找不到对应的记录！！！'||chr(10);  
            lv_info:=lv_info||'【                select *
           from so1.ins_prod_res  a
           where not exists
           (
                   select * from res.res_terminal b
                   where b.serial_no=a.res_equ_no
                   and a.res_code=b.res_code
                   and b.state=3
                   ) and a.prod_inst_id='||lr_ins_prod.prod_inst_id||'
                   or not exists
           (
                   select * from res.RES_PHONE_NUM_ORIGIN c
                   where c.bill_id=a.res_equ_no
                   and a.res_code=c.res_code
                   and c.MANAGE_STATE=3);'||chr(10);
            WHY_save_log(in_cust_order_id,lv_info,in_log_level,1);
           end if;
           
           
           
           --检查用户状态为暂停的，其设备如果回收了bill_id应该写prod_inst_id,sub_bill_id和tv_number应该为空
         elsif (lr_ins_prod.prod_spec_id=ln_shuzi_spec  and lr_ins_prod.state='M') then
           
           ln_temp:=0;
           select count(*) into ln_temp
           from so1.ins_prod_res
           where res_equ_no=lr_ins_prod.bill_id;                      
           
           IF(lr_ins_prod.bill_id<>to_char(lr_ins_prod.prod_inst_id)  and ln_temp=0) then
             lv_info:='';
             lv_info:='【用户：<'||lr_ins_prod.prod_inst_id||'>为暂停状态，但bill_id不等于prod_inst_id！！！】'||chr(10);  
             lv_info:=lv_info||'【select count(*) into ln_temp
                from so1.ins_prod_res
                where res_equ_no='||lr_ins_prod.bill_id||'】'||chr(10);
             WHY_save_log(in_cust_order_id,lv_info,in_log_level,1);
           elsif (ln_temp>0) then
                    ln_temp:=0;    
                    select count(*) into ln_temp
                    from so1.ins_prod_res  a
                    where not exists
                    (
                            select * from res.res_terminal b
                            where b.serial_no=a.res_equ_no
                            and a.res_code=b.res_code
                            and b.state=3
                    )  and a.prod_inst_id=lr_ins_prod.prod_inst_id;
                    
                    if(ln_temp<>0) then
                      lv_info:='';
                      lv_info:='用户：<'||lr_ins_prod.prod_inst_id||'>查询ins_prod_res 表在res.res_terminal 找不到对应的记录！！！'||chr(10);  
                      lv_info:=lv_info||'【select *
                         from so1.ins_prod_res  a
                         where not exists
                         (
                                 select * from res.res_terminal b
                                 where b.serial_no=a.res_equ_no
                                 and a.res_code=b.res_code
                                 and b.state=3
                                 )and a.prod_inst_id='||lr_ins_prod.prod_inst_id||';'||chr(10);
                         WHY_save_log(in_cust_order_id,lv_info,in_log_level,1);
                       end if;
               
           END IF;
           
           IF((lr_ins_prod.sub_bill_id is not null or lr_ins_prod.tv_number is not null)  and ln_temp=0) then
             lv_info:='';

                lv_info:='用户：<'||lr_ins_prod.prod_inst_id||'>为暂停状态，但sub_bill_id和tv_number不为空！！！'||chr(10);  
                WHY_save_log(in_cust_order_id,lv_info,in_log_level,1);
           END IF;
               
           
         end if;
                         
        if(lr_ins_prod.address_id<>lr_ins_address.cust_addr_id) then
          lv_info:='';
          lv_info:='【ins_prod.address_id:='||lr_ins_prod.address_id||'】与客户地址ins_address表的cust_addr_id不一致！！！'||chr(10);
          WHY_save_log(in_cust_order_id,lv_info,in_log_level,1); 
        end if;
        
        --检查用户是否有多个主套餐
        if(lr_ins_prod.prod_spec_id=800200000015) then 
            ln_temp:=0;
            select count(*) INTO ln_temp
            from so1.ins_off_ins_prod_rel a,product.up_offer b
            where a.offer_id=b.offer_id
            and B.OFFER_TYPE='OFFER_COMPOSITE'
            AND  a.PROD_INST_ID =lr_ins_prod.PROD_INST_ID;
        else
            ln_temp:=0;
            select count(*) INTO ln_temp
            from so1.ins_off_ins_prod_rel a,product.up_offer b
            where a.offer_id=b.offer_id
            and B.OFFER_TYPE='OFFER_PLAN'
            AND  a.PROD_INST_ID =lr_ins_prod.PROD_INST_ID;
        end if;
        if(ln_temp<>1) then
          lv_info:='';
          lv_info:='【PROD_INST_ID:='||lr_ins_prod.PROD_INST_ID||'】在ins_off_ins_prod_rel定义了'||ln_temp||'个主套餐！！！'||chr(10);
          lv_info:=lv_info||'【 select count(*) INTO ln_temp
        from so1.ins_off_ins_prod_rel a,product.up_offer b
        where a.offer_id=b.offer_id
        and B.OFFER_TYPE in (''''OFFER_PLAN'''',''''OFFER_COMPOSITE'''')
        AND  a.PROD_INST_ID ='||lr_ins_prod.PROD_INST_ID||'】'||chr(10);
        
          WHY_save_log(in_cust_order_id,lv_info,in_log_level,1); 
        end if;
        
        --检查ins_off_ins_prod_rel表中的记录是否都对应ins_offer
        ln_temp:=0;
        select count(*) INTO ln_temp
        from so1.ins_off_ins_prod_rel a
        where  a.PROD_INST_ID =lr_ins_prod.PROD_INST_ID        
        and not exists
        (
          select * from so1.ins_offer b
          where b.offer_inst_id=a.offer_inst_id
          and a.offer_id=b.offer_id
          and decode(b.offer_type,1,1,2,0,99)=a.is_main_offer
          and b.main_role_prod_id=a.prod_spec_id
        );
        
        if(ln_temp>0) then
          lv_info:='';
          lv_info:='【PROD_INST_ID:='||lr_ins_prod.PROD_INST_ID||'】在ins_off_ins_prod_rel有'||ln_temp||'条记录对应不到ins_offer！！！'||chr(10);
          lv_info:=lv_info||'【 select count(*) INTO ln_temp
        from so1.ins_off_ins_prod_rel a
        where  a.PROD_INST_ID ='||lr_ins_prod.PROD_INST_ID ||'       
        and not exists
        (
          select * from so1.ins_offer b
          where b.offer_inst_id=a.offer_inst_id
          and a.offer_id=b.offer_id
          and decode(b.offer_type,1,1,2,0,99)=a.is_main_offer
          and b.main_role_prod_id=a.prod_spec_id
        )】'||chr(10);
          WHY_save_log(in_cust_order_id,lv_info,in_log_level,1); 
        end if;
         
         --检查ins_off_ins_prod_rel表中的记录是否都对应ins_prod
        ln_temp:=0;
        select count(*) INTO ln_temp
        from so1.ins_off_ins_prod_rel a
        where  a.PROD_INST_ID =lr_ins_prod.PROD_INST_ID
        and a.is_main_offer=1
        and  exists
        (
          select * from so1.ins_prod b
          where a.PROD_INST_ID=b.PROD_INST_ID
          and a.prod_spec_id=b.prod_spec_id
          and a.offer_id=b.offer_id          
        );
        
        if(ln_temp<>1) then
          lv_info:='';
          lv_info:='【PROD_INST_ID:='||lr_ins_prod.PROD_INST_ID||'】在ins_off_ins_prod_rel定义了，但是在ins_prod找到了<'||ln_temp||'条>记录！！！'||chr(10);
          lv_info:=lv_info||'【select count(*) INTO ln_temp
        from so1.ins_off_ins_prod_rel a
        where  a.PROD_INST_ID ='||lr_ins_prod.PROD_INST_ID||'
        and a.is_main_offer=1
        and  exists
        (
          select * from so1.ins_prod b
          where a.PROD_INST_ID=b.PROD_INST_ID
          and a.prod_spec_id=b.prod_spec_id
          and a.offer_id=b.offer_id          
        );】'||chr(10);
          WHY_save_log(in_cust_order_id,lv_info,in_log_level,1); 
        end if;
         
         
         --检查ins_srvpkg表中的记录是否都对应ins_offer
        ln_temp:=0;
        select count(*) INTO ln_temp
        from so1.ins_srvpkg a
        where  a.PROD_INST_ID =lr_ins_prod.PROD_INST_ID
        and not exists
        (
          select * from so1.ins_offer b
          where a.offer_inst_id=b.offer_inst_id      
        );
        
        if(ln_temp>0) then
          lv_info:='';
          lv_info:='【PROD_INST_ID:='||lr_ins_prod.PROD_INST_ID||'】在ins_srvpkg中有<'||ln_temp||'条>记录没有对应到ins_offer！！！'||chr(10);
          lv_info:=lv_info||'【 select count(*) INTO ln_temp
        from so1.ins_srvpkg a
        where  a.PROD_INST_ID ='||lr_ins_prod.PROD_INST_ID||'
        and not exists
        (
          select * from so1.ins_offer b
          where a.offer_inst_id=b.offer_inst_id      
        )】'||chr(10);
          WHY_save_log(in_cust_order_id,lv_info,in_log_level,1); 
        end if;
        
        --检查ins_srvpkg表和ins_srvpkg_ins_srv_rel
        ln_temp:=0;
        select count(*) INTO ln_temp
        from so1.ins_srvpkg a
        where  a.PROD_INST_ID =lr_ins_prod.PROD_INST_ID
        and not exists
        (
          select * from so1.ins_srvpkg_ins_srv_rel b
          where a.srvpkg_inst_id=b.srvpkg_inst_id
          and b.PROD_INST_ID=a.PROD_INST_ID
          and a.offer_inst_id=b.offer_inst_id
        );
        
        if(ln_temp>0) then
          lv_info:='';
          lv_info:='【PROD_INST_ID:='||lr_ins_prod.PROD_INST_ID||'】在ins_srvpkg中有<'||ln_temp||'条>记录在ins_srvpkg_ins_srv_rel没有对应的记录！！！'||chr(10);
          lv_info:=lv_info||'【select count(*) INTO ln_temp
        from so1.ins_srvpkg a
        where  a.PROD_INST_ID ='||lr_ins_prod.PROD_INST_ID||'
        and not exists
        (
          select * from so1.ins_srvpkg_ins_srv_rel b
          where a.srvpkg_inst_id=b.srvpkg_inst_id
          and b.PROD_INST_ID=a.PROD_INST_ID
          and a.offer_inst_id=b.offer_inst_id
        )】'||chr(10);
          WHY_save_log(in_cust_order_id,lv_info,in_log_level,1); 
        end if;
         
         
         --检查ins_srvpkg_ins_srv_rel表和ins_srvpkg
        ln_temp:=0;
        select count(*) INTO ln_temp
        from so1.ins_srvpkg_ins_srv_rel a
        where  a.PROD_INST_ID =lr_ins_prod.PROD_INST_ID
        and not exists
        (
          select * from so1.ins_srvpkg b
          where a.srvpkg_inst_id=b.srvpkg_inst_id
          and b.PROD_INST_ID=a.PROD_INST_ID
          and a.offer_inst_id=b.offer_inst_id
        );
        
        if(ln_temp>0) then
          lv_info:='';
          lv_info:='【PROD_INST_ID:='||lr_ins_prod.PROD_INST_ID||'】在ins_srvpkg_ins_srv_rel中有<'||ln_temp||'条>记录在ins_srvpkg没有对应的记录！！！';
          lv_info:=lv_info||'【  select count(*) INTO ln_temp
        from so1.ins_srvpkg_ins_srv_rel a
        where  a.PROD_INST_ID ='||lr_ins_prod.PROD_INST_ID||'
        and not exists
        (
          select * from so1.ins_srvpkg b
          where a.srvpkg_inst_id=b.srvpkg_inst_id
          and b.PROD_INST_ID=a.PROD_INST_ID
          and a.offer_inst_id=b.offer_inst_id
        )】'||chr(10);
            
          WHY_save_log(in_cust_order_id,lv_info,in_log_level,1); 
        end if;
         
         
         --检查ins_srv表和ins_srvpkg_ins_srv_rel对应关系
        ln_temp:=0;
        select count(*) INTO ln_temp
        from so1.ins_srv a
        where  a.PROD_INST_ID =lr_ins_prod.PROD_INST_ID
        and not exists
        (
          select * from so1.ins_srvpkg_ins_srv_rel b
          where a.srv_inst_id=b.srv_inst_id
          and b.PROD_INST_ID=a.PROD_INST_ID
        );
        
        if(ln_temp>0) then
          lv_info:='';
          lv_info:='【PROD_INST_ID:='||lr_ins_prod.PROD_INST_ID||'】在ins_srv中有<'||ln_temp||'条>记录在ins_srvpkg_ins_srv_rel没有对应的记录！！！';
          lv_info:=lv_info||'【select count(*) INTO ln_temp
        from so1.ins_srv a
        where  a.PROD_INST_ID ='||lr_ins_prod.PROD_INST_ID||'
        and not exists
        (
          select * from so1.ins_srvpkg_ins_srv_rel b
          where a.srv_inst_id=b.srv_inst_id
          and b.PROD_INST_ID=a.PROD_INST_ID
        )】'||chr(10);
          WHY_save_log(in_cust_order_id,lv_info,in_log_level,1); 
        end if;
         
         --检查ins_srv表和ins_srvpkg_ins_srv_rel对应关系
        ln_temp:=0;
        select count(*) INTO ln_temp
        from so1.ins_srvpkg_ins_srv_rel a
        where  a.PROD_INST_ID =lr_ins_prod.PROD_INST_ID
        and not exists
        (
          select * from so1.ins_srv b
          where a.srv_inst_id=b.srv_inst_id
          and b.PROD_INST_ID=a.PROD_INST_ID
        );
        
        if(ln_temp>0) then
          lv_info:='';
          lv_info:='【PROD_INST_ID:='||lr_ins_prod.PROD_INST_ID||'】在ins_srvpkg_ins_srv_rel中有<'||ln_temp||'条>记录在ins_srv没有对应的记录！！！';
          lv_info:=lv_info||'【select count(*) INTO ln_temp
        from so1.ins_srvpkg_ins_srv_rel a
        where  a.PROD_INST_ID ='||lr_ins_prod.PROD_INST_ID||'
        and not exists
        (
          select * from so1.ins_srv b
          where a.srv_inst_id=b.srv_inst_id
          and b.PROD_INST_ID=a.PROD_INST_ID
        )】'||chr(10);
          WHY_save_log(in_cust_order_id,lv_info,in_log_level,1); 
        end if;
         
         --检查i_user表和ins_prod是否一一对应
         ln_temp:=0;
         select count(*)
         into  ln_temp
         from zg.i_user
         where serv_id=lr_ins_prod.PROD_INST_ID
         and expire_date>sysdate;
         
         if(ln_temp<>1) then
             lv_info:='';
            lv_info:='【PROD_INST_ID:='||lr_ins_prod.PROD_INST_ID||'】在i_user中有<'||ln_temp||'条>记录对应，应该只有一条！！！';
            WHY_save_log(in_cust_order_id,lv_info,in_log_level,1); 
          else
              --检查i_user表和ins_prod的字段是否对应
             select *
             into  lr_i_user
             from zg.i_user
             where serv_id=lr_ins_prod.PROD_INST_ID
             and expire_date>sysdate
             and valid_date<sysdate;
             
             if(lr_i_user.cust_id<>lr_ins_prod.cust_id) then
                 lv_info:='';
                  lv_info:='【PROD_INST_ID:='||lr_ins_prod.PROD_INST_ID||'】在ins_prod和i_user表中serv_id一至，但cust_id不一致！！！'||chr(10);
                  lv_info:=lv_info||'【i_user.cust_id='||lr_i_user.cust_id||'】'||chr(10);
                  lv_info:=lv_info||'【ins_prod.cust_id='||lr_ins_prod.cust_id||'】'||chr(10);
                  WHY_save_log(in_cust_order_id,lv_info,in_log_level,1); 
              end if; 
              
              if(lr_i_user.acct_id<>lr_ins_prod.acct_id) then
                 lv_info:='';
                  lv_info:='【PROD_INST_ID:='||lr_ins_prod.PROD_INST_ID||'】在ins_prod和i_user表中 serv_id 一致，但 acct_id 不一致！！！'||chr(10);
                  lv_info:=lv_info||'【i_user.acct_id='||lr_i_user.acct_id||'】'||chr(10);
                  lv_info:=lv_info||'【ins_prod.acct_id='||lr_ins_prod.acct_id||'】'||chr(10);
                  WHY_save_log(in_cust_order_id,lv_info,in_log_level,1); 
              end if; 
              
              if(lr_i_user.USER_PROPERTY<>0) then
                 lv_info:='';
                  lv_info:='【PROD_INST_ID:='||lr_ins_prod.PROD_INST_ID||'】在i_user表中 USER_PROPERTY 不为0，该字段无意义，程序只会写0，不会写其他值！！！'||chr(10);
                  lv_info:=lv_info||'【i_user.USER_PROPERTY='||lr_i_user.USER_PROPERTY||'】'||chr(10);                  
                  WHY_save_log(in_cust_order_id,lv_info,in_log_level,1); 
              end if;    
              
              ln_temp:=0;
              BEGIN
                  select extend_id into ln_temp
                  from product.up_product_item
                  where product_item_id=lr_ins_prod.prod_spec_id
                  and item_type='PRODUCT_SPEC';
              EXCEPTION
                when no_data_found then
                  lv_info:='';
                  lv_info:='【PROD_INST_ID:='||lr_ins_prod.PROD_INST_ID||'】ins_prod.prod_spec_id字段的值未在up_product_item定义，或item_type<>PRODUCT_SPEC！！！';
                  WHY_save_log(in_cust_order_id,lv_info,in_log_level,1);
                when others then
                  lv_info:='';
                  lv_info:='【PROD_INST_ID:='||lr_ins_prod.PROD_INST_ID||'】根据ins_prod.prod_spec_id字段的值查询up_product_item表出错！！！';
                  WHY_save_log(in_cust_order_id,lv_info,in_log_level,1);
              end;
              
              if(ln_temp<>0  and lr_i_user.user_type<>ln_temp) then              
                 lv_info:='';
                 lv_info:='【PROD_INST_ID:='||lr_ins_prod.PROD_INST_ID||'】在i_user表中 user_type 字段的值不正确，应该为用户规格ID对应产品单元表extend_id的值！！！'||chr(10);
                  lv_info:=lv_info||'【i_user.user_type='||lr_i_user.user_type||'】'||chr(10);
                  lv_info:=lv_info||'【ins_prod.prod_spec_id(extend_id)='||ln_temp||'】'||chr(10);
                 WHY_save_log(in_cust_order_id,lv_info,in_log_level,1); 
             end if;
             
             if( lr_i_user.msisdn<>lr_ins_prod.bill_id) then              
                 lv_info:='';
                 lv_info:='【PROD_INST_ID:='||lr_ins_prod.PROD_INST_ID||'】i_user.msisdn和ins_prod.bill_id 字段的值不一致！！！'||chr(10);
                  lv_info:=lv_info||'【i_user.msisdn='||lr_i_user.msisdn||'】'||chr(10);
                  lv_info:=lv_info||'【ins_prod.bill_id='||lr_ins_prod.bill_id||'】'||chr(10);
                 WHY_save_log(in_cust_order_id,lv_info,in_log_level,1); 
             end if;
             
             if( lr_i_user.imsi<>lr_ins_prod.sub_bill_id) then              
                 lv_info:='';
                 lv_info:='【PROD_INST_ID:='||lr_ins_prod.PROD_INST_ID||'】i_user.imsi和ins_prod.sub_bill_id 字段的值不一致！！！'||chr(10);
                  lv_info:=lv_info||'【i_user.imsi='||lr_i_user.imsi||'】'||chr(10);
                  lv_info:=lv_info||'【ins_prod.sub_bill_id='||lr_ins_prod.sub_bill_id||'】'||chr(10);
                 WHY_save_log(in_cust_order_id,lv_info,in_log_level,1); 
             end if;
             
             if( lr_i_user.org_id<>lr_ins_prod.org_id) then              
                 lv_info:='';
                 lv_info:='【PROD_INST_ID:='||lr_ins_prod.PROD_INST_ID||'】i_user.org_id和ins_prod.org_id 字段的值不一致！！！'||chr(10);
                  lv_info:=lv_info||'【i_user.org_id='||lr_i_user.org_id||'】'||chr(10);
                  lv_info:=lv_info||'【ins_prod.org_id='||lr_ins_prod.org_id||'】'||chr(10);
                 WHY_save_log(in_cust_order_id,lv_info,in_log_level,1); 
             end if;
             
             if( lr_i_user.corp_org_id<>lr_ins_prod.own_corp_org_id) then              
                 lv_info:='';
                 lv_info:='【PROD_INST_ID:='||lr_ins_prod.PROD_INST_ID||'】i_user.corp_org_id和ins_prod.own_corp_org_id字段的值不一致！！！'||chr(10);
                  lv_info:=lv_info||'【i_user.corp_org_id='||lr_i_user.corp_org_id||'】'||chr(10);
                  lv_info:=lv_info||'【ins_prod.own_corp_org_id='||lr_ins_prod.own_corp_org_id||'】'||chr(10);
                 WHY_save_log(in_cust_order_id,lv_info,in_log_level,1); 
             end if;
             
             if( lr_i_user.region_code<>lr_ins_prod.region_id) then              
                 lv_info:='';
                 lv_info:='【PROD_INST_ID:='||lr_ins_prod.PROD_INST_ID||'】i_user.region_code和ins_prod.region_id字段的值不一致！！！'||chr(10);
                  lv_info:=lv_info||'【i_user.region_code='||lr_i_user.region_code||'】'||chr(10);
                  lv_info:=lv_info||'【ins_prod.region_id='||lr_ins_prod.region_id||'】'||chr(10);
                 WHY_save_log(in_cust_order_id,lv_info,in_log_level,1); 
             end if;
                          
              if( lr_i_user.valid_date<>lr_ins_prod.done_date) then              
                 lv_info:='';
                 lv_info:='【PROD_INST_ID:='||lr_ins_prod.PROD_INST_ID||'】i_user.valid_date和ins_prod.done_date字段的值不一致~~~~'||chr(10);
                  lv_info:=lv_info||'【i_user.valid_date='||lr_i_user.valid_date||'】'||chr(10);
                  lv_info:=lv_info||'【ins_prod.valid_date='||lr_ins_prod.valid_date||'】'||chr(10);
                  lv_info:=lv_info||'【ins_prod.done_date='||lr_ins_prod.done_date||'】'||chr(10);
                 WHY_save_log(in_cust_order_id,lv_info,in_log_level,1); 
             end if; 
             
             if( lr_i_user.expire_date<>lr_ins_prod.expire_date) then              
                 lv_info:='';
                 lv_info:='【PROD_INST_ID:='||lr_ins_prod.PROD_INST_ID||'】i_user.expire_date和ins_prod.expire_date字段的值不一致！！！'||chr(10);
                  lv_info:=lv_info||'【i_user.expire_date='||lr_i_user.expire_date||'】'||chr(10);
                  lv_info:=lv_info||'【ins_prod.expire_date='||lr_ins_prod.expire_date||'】'||chr(10);
                 WHY_save_log(in_cust_order_id,lv_info,in_log_level,1); 
             end if; 
             
             if( lr_i_user.bill_type<>1) then              
                 lv_info:='';
                 lv_info:='【PROD_INST_ID:='||lr_ins_prod.PROD_INST_ID||'】i_user.bill_type字段程序统一都填1，现在为 <'||lr_i_user.bill_type||'> 不正确！！！'||chr(10);
                  lv_info:=lv_info||'【i_user.bill_type='||lr_i_user.bill_type||'】'||chr(10);                  
                 WHY_save_log(in_cust_order_id,lv_info,in_log_level,1); 
             end if;            
              
              if( lr_i_user.sub_status<>0 or lr_i_user.aoc_flag<>0) then              
                 lv_info:='';
                 lv_info:='【PROD_INST_ID:='||lr_ins_prod.PROD_INST_ID||'】i_user.aoc_flag，i_user.sub_status两个字段的值应该都为0！！！'||chr(10);
                  lv_info:=lv_info||'【i_user.sub_status='||lr_i_user.sub_status||'】'||chr(10);
                  lv_info:=lv_info||'【i_user.aoc_flag='||lr_i_user.aoc_flag||'】'||chr(10);
                 WHY_save_log(in_cust_order_id,lv_info,in_log_level,1); 
             end if;                                                                        
          end if;
          --检查i_user_plan表和ins_prod是否一一对应
          
          ln_temp:=0;
          select count(*) 
          into ln_temp
          from  zg.i_user_plan
          where serv_id=lr_ins_prod.PROD_INST_ID
          and valid_date<sysdate
          and expire_date>sysdate;
          if(ln_temp<>1) then
              lv_info:='';
             lv_info:='【PROD_INST_ID:='||lr_ins_prod.PROD_INST_ID||'】在i_user_plan表应该有且只有一条有效的记录，现在为<'||ln_temp||'条>！！！'||chr(10);
             WHY_save_log(in_cust_order_id,lv_info,in_log_level,1);
          else
              select * 
              into lr_i_user_plan
              from zg.i_user_plan
              where serv_id=lr_ins_prod.PROD_INST_ID
              and valid_date<sysdate
              and expire_date>sysdate;
              
              ln_temp:=0;
              BEGIN
                  select extend_id into ln_temp
                  from product.up_product_item
                  where product_item_id=lr_ins_prod.offer_id;
              EXCEPTION
                when no_data_found then
                  lv_info:='';
                  lv_info:='【PROD_INST_ID:='||lr_ins_prod.PROD_INST_ID||'】ins_prod.offer_id字段的值未在up_product_item定义！！！'||chr(10);
                  WHY_save_log(in_cust_order_id,lv_info,in_log_level,1);
                when others then
                  lv_info:='';
                  lv_info:='【PROD_INST_ID:='||lr_ins_prod.PROD_INST_ID||'】根据ins_prod.offer_id字段的值查询up_product_item表出错！！！'||chr(10);
                  WHY_save_log(in_cust_order_id,lv_info,in_log_level,1);
              end;
              
              if(lr_i_user_plan.plan_id<>ln_temp) then
                  lv_info:='';
                  lv_info:='【PROD_INST_ID:='||lr_ins_prod.PROD_INST_ID||'】i_user_plan。plan_id字段的值和up_product_item.extend_id字段的值不一致！！！'||chr(10);
                  lv_info:=lv_info||'【i_user_plan.plan_id='||lr_i_user_plan.plan_id||'】'||chr(10);
                  lv_info:=lv_info||'【ins_prod.offer_id(extend_id)='||ln_temp||'】'||chr(10);
                  WHY_save_log(in_cust_order_id,lv_info,in_log_level,1);
              end if;              
          
          end if;
          
          
          --检查i_user_status表和ins_prod是否一一对应
          
          ln_temp:=0;
          select count(*) 
          into ln_temp
          from  zg.I_USER_STATUS
          where serv_id=lr_ins_prod.PROD_INST_ID
          and valid_date<sysdate
          and expire_date>sysdate;
          if(ln_temp<>1) then
              lv_info:='';
             lv_info:='【PROD_INST_ID:='||lr_ins_prod.PROD_INST_ID||'】在I_USER_STATUS表应该有且只有一条有效的记录，现在为<'||ln_temp||'条>！！！'||chr(10);
             WHY_save_log(in_cust_order_id,lv_info,in_log_level,1);
          else
              select * 
              into lr_i_user_status
              from zg.i_user_status
              where serv_id=lr_ins_prod.PROD_INST_ID
              and valid_date<sysdate
              and expire_date>sysdate;
              
              ln_temp:=0;
              BEGIN
                  select bill_state
                  into ln_temp
                  from base.so_usr_state_map
                  where stop_type_code=lr_ins_prod.state;
              EXCEPTION
                when no_data_found then
                  lv_info:='';
                  lv_info:='【PROD_INST_ID:='||lr_ins_prod.PROD_INST_ID||'】用户状态ins_prod.state字段的值<'||lr_ins_prod.state||'>在状态转换表base.so_usr_state_map没有定义！！！'||chr(10);
                  WHY_save_log(in_cust_order_id,lv_info,in_log_level,1);
                when others then
                  lv_info:='';
                  lv_info:='【PROD_INST_ID:='||lr_ins_prod.PROD_INST_ID||'】根据用户状态ins_prod.state字段的值<'||lr_ins_prod.state||'>表查询状态转换表base.so_usr_state_map出错！！！'||chr(10);
                  WHY_save_log(in_cust_order_id,lv_info,in_log_level,1);
              end;
              
              if(lr_i_user_status.user_sts<>ln_temp) then
                  lv_info:='';
                  lv_info:='【PROD_INST_ID:='||lr_ins_prod.PROD_INST_ID||'】用户状态ins_prod.state字段的值和i_user_status.user_sts的对应关系不正确！！！'||chr(10);
                  lv_info:=lv_info||'【i_user_status.user_sts='||lr_i_user_status.user_sts||'】'||chr(10);
                  lv_info:=lv_info||'【ins_prod.state(转换后)='||ln_temp||'】'||chr(10);
                  WHY_save_log(in_cust_order_id,lv_info,in_log_level,1);
              end if;  
              
              if(lr_i_user_status.valid_date<>lr_ins_prod.done_date) then
                  lv_info:='';
                  lv_info:='【PROD_INST_ID:='||lr_ins_prod.PROD_INST_ID||'】i_user_status.valid_date和ins_prod.valid_date不一致~~~'||chr(10);
                  lv_info:=lv_info||'【i_user_status.valid_date='||lr_i_user_status.valid_date||'】'||chr(10);
                  lv_info:=lv_info||'【ins_prod.valid_date='||lr_ins_prod.valid_date||'】'||chr(10);
                  lv_info:=lv_info||'【ins_prod.done_date='||lr_ins_prod.done_date||'】'||chr(10);
                  WHY_save_log(in_cust_order_id,lv_info,in_log_level,1);
              end if;          
              
              if(lr_i_user_status.expire_date<>lr_ins_prod.expire_date) then
                  lv_info:='';
                  lv_info:='【PROD_INST_ID:='||lr_ins_prod.PROD_INST_ID||'】i_user_status.expire_date和ins_prod.expire_date不一致~~~'||chr(10);
                  lv_info:=lv_info||'【i_user_status.expire_date='||lr_i_user_status.expire_date||'】'||chr(10);                  
                  lv_info:=lv_info||'【ins_prod.expire_date='||lr_ins_prod.expire_date||'】'||chr(10);
                  WHY_save_log(in_cust_order_id,lv_info,in_log_level,1);
              end if; 
              
              if(lr_i_user_status.region_code<>lr_ins_prod.region_id) then
                  lv_info:='';
                  lv_info:='【PROD_INST_ID:='||lr_ins_prod.PROD_INST_ID||'】i_user_status.region_code和ins_prod.region_id不一致！！！'||chr(10);
                  lv_info:=lv_info||'【i_user_status.region_code='||lr_i_user_status.region_code||'】'||chr(10);
                  lv_info:=lv_info||'【ins_prod.region_id='||lr_ins_prod.region_id||'】'||chr(10);
                  WHY_save_log(in_cust_order_id,lv_info,in_log_level,1);
              end if;                                         
          end if;
         
         
         
         --检查i_user_msc,i_user_sprom和ins_srvpkg是否一一对应
          open cur_srvpkg_price_plan(lr_ins_prod.PROD_INST_ID);
          loop
          fetch cur_srvpkg_price_plan into lr_INS_SRVPKG;
          exit when cur_srvpkg_price_plan%notfound;
                                                                                   
              lr_org:=FUNC_GET_ORG_NAME(lr_INS_SRVPKG.org_id);
              if(lr_org.organize_id is null) then
                lv_info:='';
                lv_info:='【srvpkg_inst_id'||lr_INS_SRVPKG.srvpkg_inst_id||'的org_id:='||lr_INS_SRVPKG.org_id||'】在sec.sec_organize中没有定义，可能导致查不出产品信息！！！'||chr(10);
                WHY_save_log(in_cust_order_id,lv_info,in_log_level,1);     
              end if;
              
              
              ln_temp:=0;
              select count(*) into ln_temp
              from   sec.sec_operator
              where operator_id=lr_INS_SRVPKG.op_id;
              
              if(ln_temp<>1) then
                lv_info:='';
                lv_info:='【INS_SRVPKG表的op_id:='||lr_INS_SRVPKG.op_id||'】在sec.sec_operator中没有定义或有多条，可能导致查不出产品信息！！！'||chr(10);
                WHY_save_log(in_cust_order_id,lv_info,in_log_level,1);     
              end if;              
                        
              ln_temp:=-1;
              BEGIN
                SELECT IMPLCLASS_TYPE into ln_temp
                FROM  BASE.CFG_SO_TO_BILLING_DATA
                where PRICE_PLAN_TYPE=lr_INS_SRVPKG.PRICE_PLAN_TYPE_CD
                and INTERFACE_CODE=lr_INS_SRVPKG.INTERFACE_CODE;
              EXCEPTION
              when no_data_found then
                  lv_info:='';
                  lv_info:='【PROD_INST_ID:='||lr_ins_prod.PROD_INST_ID||'】<'||lr_INS_SRVPKG.srvpkg_inst_id||'>服务包下的<'||lr_INS_SRVPKG.PRICE_PLAN_ID||'>价格计划在BASE.CFG_SO_TO_BILLING_DATA表没有对应的配置！！！'||chr(10);
                  WHY_save_log(in_cust_order_id,lv_info,in_log_level,1);
              when  others  then
                  lv_info:='';
                  lv_info:='【PROD_INST_ID:='||lr_ins_prod.PROD_INST_ID||'】<'||lr_INS_SRVPKG.srvpkg_inst_id||'>服务包下的<'||lr_INS_SRVPKG.PRICE_PLAN_ID||'>价格计划查询BASE.CFG_SO_TO_BILLING_DATA表时出错！！！'||chr(10);
                  WHY_save_log(in_cust_order_id,lv_info,in_log_level,1);
              END;                            
              
              if(ln_temp=1)then
                BEGIN
                  select * into lr_i_user_msc
                  from zg.i_user_msc
                  where serv_id=lr_ins_prod.PROD_INST_ID
                  and prod_id=lr_INS_SRVPKG.extend_id
                  and  valid_date<sysdate
                  and expire_date>sysdate; 
                EXCEPTION
                when no_data_found then
                    lv_info:='';
                    lv_info:='【PROD_INST_ID:='||lr_ins_prod.PROD_INST_ID||'】<'||lr_INS_SRVPKG.srvpkg_inst_id||'>服务包下的<'||lr_INS_SRVPKG.PRICE_PLAN_ID||'>价格计划在i_user_msc没有对应的记录！！！'||chr(10);
                    WHY_save_log(in_cust_order_id,lv_info,in_log_level,1);
                    goto end_cur_srvpkg;
                when  others  then
                    lv_info:='';
                    lv_info:='【PROD_INST_ID:='||lr_ins_prod.PROD_INST_ID||'】<'||lr_INS_SRVPKG.srvpkg_inst_id||'>服务包下的<'||lr_INS_SRVPKG.PRICE_PLAN_ID||'>价格计划查询i_user_msc表时出错,可能是一个价格计划在i_user_msc对应了多条记录！！！'||chr(10);
                    WHY_save_log(in_cust_order_id,lv_info,in_log_level,1);
                    goto end_cur_srvpkg;
                END;   
                if(lr_i_user_msc.region_code<>lr_INS_SRVPKG.region_id) then
                  lv_info:='';
                  lv_info:='【PROD_INST_ID:='||lr_ins_prod.PROD_INST_ID||'】<'||lr_INS_SRVPKG.srvpkg_inst_id||'>的region_id与i_user_msc表的region_code不一致！！！'||chr(10);
                  lv_info:=lv_info||'【i_user_msc.region_code='||lr_i_user_msc.region_code||'】'||chr(10);
                  lv_info:=lv_info||'【INS_SRVPKG.region_id='||lr_INS_SRVPKG.region_id||'】'||chr(10);
                  WHY_save_log(in_cust_order_id,lv_info,in_log_level,1);
                end if;
                
                if(lr_i_user_msc.func_type<>lr_INS_SRVPKG.INTERFACE_CODE) then
                  lv_info:='';
                  lv_info:='【PROD_INST_ID:='||lr_ins_prod.PROD_INST_ID||'】<'||lr_INS_SRVPKG.srvpkg_inst_id||'>服务包下的<'||lr_INS_SRVPKG.PRICE_PLAN_ID||'>价格计划上发到i_user_msc的func_type不是价格计划的INTERFACE_CODE！！！'||chr(10);
                  lv_info:=lv_info||'【i_user_msc.func_type='||lr_i_user_msc.func_type||'】'||chr(10);
                  lv_info:=lv_info||'【价格计划'||lr_INS_SRVPKG.PRICE_PLAN_ID||'的'||lr_INS_SRVPKG.INTERFACE_CODE||'】'||chr(10);
                  WHY_save_log(in_cust_order_id,lv_info,in_log_level,1);
                end if;
                
                if(lr_i_user_msc.busi_type<>1) then
                  lv_info:='';
                  lv_info:='【PROD_INST_ID:='||lr_ins_prod.PROD_INST_ID||'】<'||lr_INS_SRVPKG.srvpkg_inst_id||'>服务包下的<'||lr_INS_SRVPKG.PRICE_PLAN_ID||'>价格计划上发到i_user_msc的busi_type不是1,该字段固定写死为1 ！！！'||chr(10);
                  lv_info:=lv_info||'【i_user_msc.busi_type='||lr_i_user_msc.busi_type||'】'||chr(10);
                  WHY_save_log(in_cust_order_id,lv_info,in_log_level,1);
                end if;
                
                if(lr_i_user_msc.offer_inst_id<>lr_INS_SRVPKG.offer_inst_id) then
                  lv_info:='';
                  lv_info:='【PROD_INST_ID:='||lr_ins_prod.PROD_INST_ID||'】<'||lr_INS_SRVPKG.srvpkg_inst_id||'>服务包下的<'||lr_INS_SRVPKG.PRICE_PLAN_ID||'>价格计划上发到i_user_msc的offer_inst_id不是服务包实例对应的offer_inst_id ！！！'||chr(10);
                  lv_info:=lv_info||'【i_user_msc.offer_inst_id='||lr_i_user_msc.offer_inst_id||'】'||chr(10);
                  lv_info:=lv_info||'【INS_SRVPKG.offer_inst_id='||lr_INS_SRVPKG.offer_inst_id||'】'||chr(10);
                  WHY_save_log(in_cust_order_id,lv_info,in_log_level,1);
                end if;
                
                if(lr_i_user_msc.valid_date<>lr_INS_SRVPKG.valid_date) then
                  lv_info:='';
                  lv_info:='【PROD_INST_ID:='||lr_ins_prod.PROD_INST_ID||'】<'||lr_INS_SRVPKG.srvpkg_inst_id||'>服务包下的<'||lr_INS_SRVPKG.PRICE_PLAN_ID||'>价格计划上发到i_user_msc的valid_date与服务包实例的valid_date不一致 ~~~'||chr(10);
                  lv_info:=lv_info||'【i_user_msc.valid_date='||lr_i_user_msc.valid_date||'】'||chr(10);
                  lv_info:=lv_info||'【INS_SRVPKG.valid_date='||lr_INS_SRVPKG.valid_date||'】'||chr(10);
                  lv_info:=lv_info||'【INS_SRVPKG.done_date='||lr_INS_SRVPKG.done_date||'】'||chr(10);
                  WHY_save_log(in_cust_order_id,lv_info,in_log_level,1);
                end if;
                
                if(lr_i_user_msc.expire_date<>lr_INS_SRVPKG.expire_date) then
                  lv_info:='';
                  lv_info:='【PROD_INST_ID:='||lr_ins_prod.PROD_INST_ID||'】<'||lr_INS_SRVPKG.srvpkg_inst_id||'>服务包下的<'||lr_INS_SRVPKG.PRICE_PLAN_ID||'>价格计划上发到i_user_msc的expire_date与服务包实例的expire_date不一致 ~~~'||chr(10);
                  lv_info:=lv_info||'【i_user_msc.expire_date='||lr_i_user_msc.expire_date||'】'||chr(10);                  
                  lv_info:=lv_info||'【INS_SRVPKG.expire_date='||lr_INS_SRVPKG.expire_date||'】'||chr(10);
                  WHY_save_log(in_cust_order_id,lv_info,in_log_level,1);
                end if;  
                  
                   --检查上发i_user_prod_sts   BEGIN
                ln_prod_sts_temp:=-1;
                BEGIN
                  SELECT a.* into lr_i_user_prod_sts
                  FROM  zg.i_user_prod_sts  a,zg.i_user_msc b
                  where a.serv_id=lr_INS_SRVPKG.PROD_INST_ID
                  and a.service_id=lr_INS_SRVPKG.PROD_SERVICE_ID
                  and a.so_id=b.so_id
                  and b.prod_id=lr_INS_SRVPKG.extend_id
                  and a.valid_date<sysdate
                  and a.expire_date>sysdate; 
                  ln_prod_sts_temp:=0;
                EXCEPTION
                when no_data_found then
                    lv_info:='';
                    lv_info:='【PROD_INST_ID:='||lr_ins_prod.PROD_INST_ID||'】<srvpkg_inst_id：'||lr_INS_SRVPKG.srvpkg_inst_id||'><service_id'||lr_INS_SRVPKG.PROD_SERVICE_ID||'>在i_user_prod_sts没有找到对应的记录！！！'||chr(10);
                    lv_info:=lv_info||'【 SELECT a.* into lr_i_user_prod_sts
                  FROM  zg.i_user_prod_sts  a,zg.i_user_msc b
                  where a.serv_id='||lr_INS_SRVPKG.PROD_INST_ID||'
                  and a.service_id='||lr_INS_SRVPKG.PROD_SERVICE_ID||'
                  and a.so_id=b.so_id
                  and b.prod_id='||lr_INS_SRVPKG.extend_id||'
                  and a.valid_date<sysdate
                  and a.expire_date>sysdate;】'||chr(10);
                    WHY_save_log(in_cust_order_id,lv_info,in_log_level,1);
                when  others  then
                    lv_info:='';
                    lv_info:='【PROD_INST_ID:='||lr_ins_prod.PROD_INST_ID||'】<srvpkg_inst_id：'||lr_INS_SRVPKG.srvpkg_inst_id||'><service_id'||lr_INS_SRVPKG.PROD_SERVICE_ID||'>查询i_user_prod_sts时出错，可能是返回了多条记录！！！'||chr(10);
                    lv_info:=lv_info||'【 SELECT a.* 
                  FROM  zg.i_user_prod_sts  a,zg.i_user_msc b
                  where a.serv_id='||lr_INS_SRVPKG.PROD_INST_ID||'
                  and a.service_id='||lr_INS_SRVPKG.PROD_SERVICE_ID||'
                  and a.so_id=b.so_id
                  and b.prod_id='||lr_INS_SRVPKG.extend_id||'
                  and a.valid_date<sysdate
                  and a.expire_date>sysdate; 】'||chr(10);
                    WHY_save_log(in_cust_order_id,lv_info,in_log_level,1);
                END;   
                if (ln_prod_sts_temp=0) then
                    ln_os_status:=nvl(lr_INS_SRVPKG.OS_STATUS,'0');
                    
                    select substr(ln_os_status,-1,1) 
                    into ln_os_status 
                    from dual;
                    
                    if(ln_os_status=1 or ln_os_status=2)then
                      ln_os_status:=2;
                    elsif (ln_os_status=4)then
                      ln_os_status:=3;
                    elsif (ln_os_status=3 or  ln_os_status=6)then
                      ln_os_status:=4;
                    else  
                      ln_os_status:=1;
                    end if;
                    
                    if(lr_i_user_prod_sts.prod_sts<>ln_os_status) then
                      lv_info:='';
                      lv_info:='【PROD_INST_ID:='||lr_ins_prod.PROD_INST_ID||'】<srvpkg_inst_id:='||lr_INS_SRVPKG.srvpkg_inst_id||'>上发到i_user_prod_sts中的prod_sts不对！！！'||chr(10);
                      lv_info:=lv_info||'【i_user_prod_sts.prod_sts='||lr_i_user_prod_sts.prod_sts||'】'||chr(10);
                      lv_info:=lv_info||'【ins_srvpkg.OS_STATUS转换后为 <'||ln_os_status||'>】'||chr(10);                    
                      WHY_save_log(in_cust_order_id,lv_info,in_log_level,1);
                    end if;
                    
                    if(lr_i_user_prod_sts.valid_date<>lr_INS_SRVPKG.done_date and lr_i_user_prod_sts.valid_date<>lr_INS_SRVPKG.valid_date) then
                      lv_info:='';
                      lv_info:='【PROD_INST_ID:='||lr_ins_prod.PROD_INST_ID||'】<srvpkg_inst_id:='||lr_INS_SRVPKG.srvpkg_inst_id||'>上发到i_user_prod_sts中的valid_date不对~~~'||chr(10);
                      lv_info:=lv_info||'【i_user_prod_sts.valid_date='||lr_i_user_prod_sts.valid_date||'】'||chr(10); 
                      lv_info:=lv_info||'【ins_srvpkg.valid_date='||lr_INS_SRVPKG.valid_date||'】'||chr(10);          
                      lv_info:=lv_info||'【ins_srvpkg.done_date='||lr_INS_SRVPKG.done_date||'】'||chr(10);         
                      WHY_save_log(in_cust_order_id,lv_info,in_log_level,1);
                    end if;
                    
                    if(lr_i_user_prod_sts.expire_date<>lr_INS_SRVPKG.expire_date) then
                      lv_info:='';
                      lv_info:='【PROD_INST_ID:='||lr_ins_prod.PROD_INST_ID||'】<srvpkg_inst_id:='||lr_INS_SRVPKG.srvpkg_inst_id||'>上发到i_user_prod_sts中的expire_date不对~~~'||chr(10);
                      lv_info:=lv_info||'【i_user_prod_sts.expire_date='||lr_i_user_prod_sts.expire_date||'】'||chr(10);
                      lv_info:=lv_info||'【ins_srvpkg.expire_date='||lr_INS_SRVPKG.expire_date||'】'||chr(10);                    
                      WHY_save_log(in_cust_order_id,lv_info,in_log_level,1);
                    end if;
                    
                end if;
                --检查上发i_user_prod_sts   END                                                
              elsif (ln_temp=2) then
                BEGIN
                  select * into lr_i_user_sprom
                  from zg.i_user_sprom
                  where serv_id=lr_ins_prod.PROD_INST_ID
                  and sprom_id=lr_INS_SRVPKG.extend_id
                  and  valid_date<sysdate
                  and expire_date>sysdate; 
                EXCEPTION
                when no_data_found then
                    lv_info:='';
                    lv_info:='【PROD_INST_ID:='||lr_ins_prod.PROD_INST_ID||'】<'||lr_INS_SRVPKG.srvpkg_inst_id||'>服务包下的<'||lr_INS_SRVPKG.PRICE_PLAN_ID||'>价格计划在i_user_sprom没有对应的记录！！！'||chr(10);
                    lv_info:=lv_info||'【select * 
                  from zg.i_user_sprom
                  where serv_id='||lr_ins_prod.PROD_INST_ID||'
                  and sprom_id='||lr_INS_SRVPKG.extend_id||'
                  and  valid_date<sysdate
                  and expire_date>sysdate'||'】'||chr(10);
                    WHY_save_log(in_cust_order_id,lv_info,in_log_level,1);
                    goto end_cur_srvpkg;
                when  others  then
                    lv_info:='';
                    lv_info:='【PROD_INST_ID:='||lr_ins_prod.PROD_INST_ID||'】<'||lr_INS_SRVPKG.srvpkg_inst_id||'>服务包下的<'||lr_INS_SRVPKG.PRICE_PLAN_ID||'>价格计划查询i_user_sprom表时出错,可能是一个价格计划在i_user_sprom对应了多条记录！！！'||chr(10);
                    lv_info:=lv_info||'【select * 
                  from zg.i_user_sprom
                  where serv_id='||lr_ins_prod.PROD_INST_ID||'
                  and sprom_id='||lr_INS_SRVPKG.extend_id||'
                  and  valid_date<sysdate
                  and expire_date>sysdate】'||chr(10);
                    WHY_save_log(in_cust_order_id,lv_info,in_log_level,1);
                    goto end_cur_srvpkg;
                END;   
                if(lr_i_user_sprom.region_code<>lr_INS_SRVPKG.region_id) then
                  lv_info:='';
                  lv_info:='【PROD_INST_ID:='||lr_ins_prod.PROD_INST_ID||'】<'||lr_INS_SRVPKG.srvpkg_inst_id||'>的region_id与i_user_sprom表的region_code不一致！！！'||chr(10);
                  lv_info:=lv_info||'【i_user_sprom.region_code='||lr_i_user_sprom.region_code||'】'||chr(10);
                  lv_info:=lv_info||'【INS_SRVPKG.region_id='||lr_INS_SRVPKG.region_id||'】'||chr(10);
                  WHY_save_log(in_cust_order_id,lv_info,in_log_level,1);
                end if;
                
                if(lr_i_user_sprom.sprom_type<>lr_INS_SRVPKG.INTERFACE_CODE) then
                  lv_info:='';
                  lv_info:='【PROD_INST_ID:='||lr_ins_prod.PROD_INST_ID||'】<'||lr_INS_SRVPKG.srvpkg_inst_id||'>服务包下的<'||lr_INS_SRVPKG.PRICE_PLAN_ID||'>价格计划上发到i_user_sprom的sprom_type不是价格计划的INTERFACE_CODE！！！'||chr(10);
                  lv_info:=lv_info||'【lr_i_user_sprom.sprom_type='||lr_i_user_sprom.sprom_type||'】'||chr(10);
                  lv_info:=lv_info||'【价格计划'||lr_INS_SRVPKG.PRICE_PLAN_ID||'的INTERFACE_CODE='||lr_INS_SRVPKG.INTERFACE_CODE||'】'||chr(10);
                  WHY_save_log(in_cust_order_id,lv_info,in_log_level,1);
                end if;
                
                if(lr_i_user_sprom.service_id<>0) then
                  lv_info:='';
                  lv_info:='【PROD_INST_ID:='||lr_ins_prod.PROD_INST_ID||'】<'||lr_INS_SRVPKG.srvpkg_inst_id||'>服务包下的<'||lr_INS_SRVPKG.PRICE_PLAN_ID||'>价格计划上发到i_user_sprom的service_id不是0,该字段固定写死为0 ！！！'||chr(10);
                  lv_info:=lv_info||'【i_user_sprom.service_id='||lr_i_user_sprom.service_id||'】'||chr(10);
                  WHY_save_log(in_cust_order_id,lv_info,in_log_level,1);
                end if;
                
                if(lr_i_user_sprom.offer_inst_id<>lr_INS_SRVPKG.offer_inst_id) then
                  lv_info:='';
                  lv_info:='【PROD_INST_ID:='||lr_ins_prod.PROD_INST_ID||'】<'||lr_INS_SRVPKG.srvpkg_inst_id||'>服务包下的<'||lr_INS_SRVPKG.PRICE_PLAN_ID||'>价格计划上发到lr_i_user_sprom的offer_inst_id不是服务包实例对应的offer_inst_id ！！！'||chr(10);
                  lv_info:=lv_info||'【i_user_sprom.offer_inst_id='||lr_i_user_sprom.offer_inst_id||'】'||chr(10);
                  lv_info:=lv_info||'【INS_SRVPKG.offer_inst_id='||lr_INS_SRVPKG.offer_inst_id||'】'||chr(10);
                  WHY_save_log(in_cust_order_id,lv_info,in_log_level,1);
                end if;
                
                if(lr_i_user_sprom.valid_date<>lr_INS_SRVPKG.valid_date) then
                  lv_info:='';
                  lv_info:='【PROD_INST_ID:='||lr_ins_prod.PROD_INST_ID||'】<'||lr_INS_SRVPKG.srvpkg_inst_id||'>服务包下的<'||lr_INS_SRVPKG.PRICE_PLAN_ID||'>价格计划上发到i_user_sprom的valid_date与服务包实例的valid_date不一致~~~'||chr(10);
                  lv_info:=lv_info||'【i_user_sprom.valid_date='||lr_i_user_sprom.valid_date||'】'||chr(10);
                  lv_info:=lv_info||'【INS_SRVPKG.valid_date='||lr_INS_SRVPKG.valid_date||'】'||chr(10);
                  lv_info:=lv_info||'【INS_SRVPKG.done_date='||lr_INS_SRVPKG.done_date||'】'||chr(10);
                  WHY_save_log(in_cust_order_id,lv_info,in_log_level,1);
                end if;
                
                if(lr_i_user_sprom.expire_date<>lr_INS_SRVPKG.expire_date) then
                  lv_info:='';
                  lv_info:='【PROD_INST_ID:='||lr_ins_prod.PROD_INST_ID||'】<'||lr_INS_SRVPKG.srvpkg_inst_id||'>服务包下的<'||lr_INS_SRVPKG.PRICE_PLAN_ID||'>价格计划上发到i_user_sprom的expire_date与服务包实例的expire_date不一致 ~~~'||chr(10);
                  lv_info:=lv_info||'【i_user_sprom.expire_date='||lr_i_user_sprom.expire_date||'】'||chr(10);
                  lv_info:=lv_info||'【INS_SRVPKG.expire_date='||lr_INS_SRVPKG.expire_date||'】'||chr(10);
                  WHY_save_log(in_cust_order_id,lv_info,in_log_level,1);
                end if;
                
                 --检查上发i_user_prod_sts   BEGIN
                ln_prod_sts_temp:=-1;
                BEGIN
                  SELECT a.* into lr_i_user_prod_sts
                  FROM  zg.i_user_prod_sts  a,zg.i_user_sprom b
                  where a.serv_id=lr_INS_SRVPKG.PROD_INST_ID
                  and a.service_id=lr_INS_SRVPKG.PROD_SERVICE_ID
                  and a.so_id=b.so_id
                  and b.sprom_id=lr_INS_SRVPKG.extend_id
                  and a.valid_date<sysdate
                  and a.expire_date>sysdate; 
                  ln_prod_sts_temp:=0;
                EXCEPTION
                when no_data_found then
                    lv_info:='';
                    lv_info:='【PROD_INST_ID:='||lr_ins_prod.PROD_INST_ID||'】<srvpkg_inst_id：'||lr_INS_SRVPKG.srvpkg_inst_id||'><service_id'||lr_INS_SRVPKG.PROD_SERVICE_ID||'>在i_user_prod_sts没有找到对应的记录！！！'||chr(10);
                    lv_info:=lv_info||'【SELECT a.* into lr_i_user_prod_sts
                  FROM  zg.i_user_prod_sts  a,zg.i_user_sprom b
                  where a.serv_id='||lr_INS_SRVPKG.PROD_INST_ID||'
                  and a.service_id='||lr_INS_SRVPKG.PROD_SERVICE_ID||'
                  and a.so_id=b.so_id
                  and b.sprom_id='||lr_INS_SRVPKG.extend_id||'
                  and a.valid_date<sysdate
                  and a.expire_date>sysdate】'||chr(10);
                    WHY_save_log(in_cust_order_id,lv_info,in_log_level,1);
                when  others  then
                    lv_info:='';
                    lv_info:='【PROD_INST_ID:='||lr_ins_prod.PROD_INST_ID||'】<srvpkg_inst_id：'||lr_INS_SRVPKG.srvpkg_inst_id||'><service_id'||lr_INS_SRVPKG.PROD_SERVICE_ID||'>查询i_user_prod_sts时出错，可能是返回了多条记录！！！'||chr(10);
                    lv_info:=lv_info||'【SELECT a.* into lr_i_user_prod_sts
                  FROM  zg.i_user_prod_sts  a,zg.i_user_sprom b
                  where a.serv_id='||lr_INS_SRVPKG.PROD_INST_ID||'
                  and a.service_id='||lr_INS_SRVPKG.PROD_SERVICE_ID||'
                  and a.so_id=b.so_id
                  and b.sprom_id='||lr_INS_SRVPKG.extend_id||'
                  and a.valid_date<sysdate
                  and a.expire_date>sysdate】'||chr(10);
                    WHY_save_log(in_cust_order_id,lv_info,in_log_level,1);
                END;   
                if (ln_prod_sts_temp=0) then
                    ln_os_status:=nvl(lr_INS_SRVPKG.OS_STATUS,'0');
                    
                    select substr(ln_os_status,-1,1) 
                    into ln_os_status 
                    from dual;
                    
                    if(ln_os_status=1 or ln_os_status=2)then
                      ln_os_status:=2;
                    elsif (ln_os_status=4)then
                      ln_os_status:=3;
                    elsif (ln_os_status=3 or  ln_os_status=6)then
                      ln_os_status:=4;
                    else  
                      ln_os_status:=1;
                    end if;
                    
                    if(lr_i_user_prod_sts.prod_sts<>ln_os_status) then
                      lv_info:='';
                      lv_info:='【PROD_INST_ID:='||lr_ins_prod.PROD_INST_ID||'】<srvpkg_inst_id:='||lr_INS_SRVPKG.srvpkg_inst_id||'>上发到i_user_prod_sts中的prod_sts不对！！！'||chr(10);
                      lv_info:=lv_info||'【i_user_prod_sts.prod_sts='||lr_i_user_prod_sts.prod_sts||'】'||chr(10);
                      lv_info:=lv_info||'【ins_srvpkg.OS_STATUS转换后为 <'||ln_os_status||'>】'||chr(10);                    
                      WHY_save_log(in_cust_order_id,lv_info,in_log_level,1);
                    end if;
                    
                    if(lr_i_user_prod_sts.valid_date<>lr_INS_SRVPKG.done_date and lr_i_user_prod_sts.valid_date<>lr_INS_SRVPKG.valid_date) then
                      lv_info:='';
                      lv_info:='【PROD_INST_ID:='||lr_ins_prod.PROD_INST_ID||'】<srvpkg_inst_id:='||lr_INS_SRVPKG.srvpkg_inst_id||'>上发到i_user_prod_sts中的valid_date不对~~~'||chr(10);
                      lv_info:=lv_info||'【i_user_prod_sts.valid_date='||lr_i_user_prod_sts.valid_date||'】'||chr(10);
                      lv_info:=lv_info||'【ins_srvpkg.valid_date='||lr_INS_SRVPKG.valid_date||'】'||chr(10);          
                      lv_info:=lv_info||'【ins_srvpkg.done_date='||lr_INS_SRVPKG.done_date||'】'||chr(10);            
                      WHY_save_log(in_cust_order_id,lv_info,in_log_level,1);
                    end if;
                    
                    if(lr_i_user_prod_sts.expire_date<>lr_INS_SRVPKG.expire_date) then
                      lv_info:='';
                      lv_info:='【PROD_INST_ID:='||lr_ins_prod.PROD_INST_ID||'】<srvpkg_inst_id:='||lr_INS_SRVPKG.srvpkg_inst_id||'>上发到i_user_prod_sts中的expire_date不对~~~'||chr(10);
                      lv_info:=lv_info||'【i_user_prod_sts.expire_date='||lr_i_user_prod_sts.expire_date||'】'||chr(10);
                      lv_info:=lv_info||'【ins_srvpkg.expire_date='||lr_INS_SRVPKG.expire_date||'】'||chr(10);                    
                      WHY_save_log(in_cust_order_id,lv_info,in_log_level,1);
                    end if;
                    
                end if;
                --检查上发i_user_prod_sts   END                                                          
              else
                  lv_info:='';
                  lv_info:='【PROD_INST_ID:='||lr_ins_prod.PROD_INST_ID||'】<'||lr_INS_SRVPKG.srvpkg_inst_id||'>服务包下的<'||lr_INS_SRVPKG.PRICE_PLAN_ID||'>价格计划在base.CFG_SO_TO_BILLING_DATA中配置的IMPLCLASS_TYPE为<'||ln_temp||'> ，改值不知道是上发到i_user_sprom,还是i_user_sprom！！！';
                  WHY_save_log(in_cust_order_id,lv_info,in_log_level,1);
              end if;
              
                              --参数的校验 暂缺                
                ln_param_temp:=0;
                
                select  count(*)    into ln_param_temp
                 from so1.ins_srvpkg a,  so1.INS_SRV_ATTR b,product.up_product_item c,product.up_item_relat f,product.up_item_relat g
                where A.SRVPKG_INST_ID=B.SRV_INST_ID
                and b.attr_id=c.product_item_id
                and srvpkg_inst_id=lr_INS_SRVPKG.srvpkg_inst_id
                and A.SRVPKG_ID=F.PRODUCT_ITEM_ID
                and F.RELAT_PRODUCT_ITEM_ID=G.PRODUCT_ITEM_ID
                and B.ATTR_ID=G.RELAT_PRODUCT_ITEM_ID
                and G.PROD_ITEM_RELAT_KIND_ID='SERVICE_PRICE_GENERAL_ATTRIBUTE'
                and f.prod_item_relat_kind_id in ('SERVICE_PRICE_GENERAL_PRICE_PLAN_PKG_BOSS','SERVICE_PRICE_GENERAL_PRICE_PLAN_PKG_BILLING')
                and not exists (
                    select * from zg.i_sprom_param  d
                    where d.serv_id=a.prod_inst_id
                    and d.key_id=c.extend_id
                    and d.sprom_para=B.ATTR_VALUE
                    and d.valid_date<sysdate
                    and d.expire_date>sysdate
                    and d.sprom_type=lr_INS_SRVPKG.INTERFACE_CODE
                );
                if(ln_param_temp>0) then
                  lv_info:='';
                  lv_info:='【PROD_INST_ID:='||lr_ins_prod.PROD_INST_ID||'】<'||lr_INS_SRVPKG.srvpkg_inst_id||'>服务包下有的属性没有上发，或上发的不正确 ！！！'||chr(10);
                  lv_info:=lv_info||'查询sql如下：'||chr(10); 
                  lv_info:=lv_info||'【              select  count(*)    into ln_param_temp
                 from so1.ins_srvpkg a,  so1.INS_SRV_ATTR b,product.up_product_item c,product.up_item_relat f,product.up_item_relat g
                where A.SRVPKG_INST_ID=B.SRV_INST_ID
                and b.attr_id=c.product_item_id
                and srvpkg_inst_id='||lr_INS_SRVPKG.srvpkg_inst_id||'
                and A.SRVPKG_ID=F.PRODUCT_ITEM_ID
                and F.RELAT_PRODUCT_ITEM_ID=G.PRODUCT_ITEM_ID
                and B.ATTR_ID=G.RELAT_PRODUCT_ITEM_ID
                and G.PROD_ITEM_RELAT_KIND_ID=''''SERVICE_PRICE_GENERAL_ATTRIBUTE''''
                and f.prod_item_relat_kind_id in (''''SERVICE_PRICE_GENERAL_PRICE_PLAN_PKG_BOSS'''',''''SERVICE_PRICE_GENERAL_PRICE_PLAN_PKG_BILLING'''')
                and not exists (
                    select * from zg.i_sprom_param  d
                    where d.serv_id=a.prod_inst_id
                    and d.key_id=c.extend_id
                    and d.sprom_para=B.ATTR_VALUE
                    and d.valid_date<sysdate
                    and d.expire_date>sysdate
                    and d.sprom_type='||lr_INS_SRVPKG.INTERFACE_CODE||'
                );】'||chr(10);                 
                  WHY_save_log(in_cust_order_id,lv_info,in_log_level,1);
                end if;
            <<end_cur_srvpkg>>
            null;
          end loop;
          close cur_srvpkg_price_plan;     
     
  end loop;
  close cur_ins_prod;
  
  <<proc_end>>
   null;
end;





/

