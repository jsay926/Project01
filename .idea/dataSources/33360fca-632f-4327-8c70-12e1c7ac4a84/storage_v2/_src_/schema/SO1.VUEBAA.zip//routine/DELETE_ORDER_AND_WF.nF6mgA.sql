create procedure delete_order_and_wf(v_cust_ord_id in number)
as
v_cust_id_pattern varchar2(16);
begin

v_cust_id_pattern := '%'||v_cust_ord_id||'%';

delete from so1.ord_busi ob where ob.cust_order_id=v_cust_ord_id;
delete from so1.ord_busi_attr oba where oba.cust_order_id=v_cust_ord_id;
--策划（套餐）订单
delete from so1.ord_offer oo where oo.cust_order_id=v_cust_ord_id;
--用户订单
delete from so1.ord_prod op where op.cust_order_id=v_cust_ord_id;

--资源订单
delete from so1.ord_prod_res opr where opr.cust_order_id=v_cust_ord_id;

--账户信息订单
delete from so1.ord_acctinfo oa where oa.cust_order_id=v_cust_ord_id;
--群组成员订单
delete from so1.ord_grp_member og where og.cust_order_id=v_cust_ord_id;

--客户订单信息
delete from so1.ord_custinfo ocif where ocif.cust_order_id=v_cust_ord_id;
delete from so1.ord_cust_attr oca where oca.cust_order_id=v_cust_ord_id;
delete from so1.ord_cust_attr_f ocaf where ocaf.cust_order_id=v_cust_ord_id;
delete from so1.ord_cust_f ocf where ocf.cust_order_id=v_cust_ord_id;

delete from so1.vm_schedule vs where vs.workflow_id in (
  select wf.task_id from so1.vm_work_flow wf where wf.vars like v_cust_id_pattern
);

delete from so1.vm_task vt where vt.workflow_id in (
  select wf.task_id from so1.vm_work_flow wf where wf.vars like v_cust_id_pattern
);

delete from so1.vm_work_flow wf where wf.vars like v_cust_id_pattern;

--客户订单
delete from so1.ord_cust oc where oc.cust_order_id=v_cust_ord_id;
commit;
end;




/

