create PROCEDURE     p_roll_prod_card_order (in_order_id IN VARCHAR2 )

AS

BEGIN

  dbms_output.put_line('需要处理的订单编号为:'||in_order_id);

----------------删除实例表
delete from so1.ins_offer t where t.cust_order_id=in_order_id;
delete from so1.ins_off_ins_prod_rel t where  t.cust_order_id=in_order_id;
delete from so1.ins_srvpkg t where t.cust_order_id=in_order_id;
delete from so1.ins_srvpkg_ins_srv_rel t where t.cust_order_id=in_order_id;
delete from so1.ins_srv t where t.cust_order_id=in_order_id;
delete from so1.ins_srv_attr t where t.cust_order_id=in_order_id;
dbms_output.put_line('订单编号为:'||in_order_id||'实例已删除!');

---------------删除订单表
delete from so1.ord_cust_f_2013 t where t.cust_order_id=in_order_id;
delete from so1.ord_offer_f_2013 t where t.cust_order_id=in_order_id;
delete from so1.ord_prod_f_2013 t where t.cust_order_id=in_order_id;
delete from so1.ord_srvpkg_f_2013 t where t.cust_order_id=in_order_id;
delete from so1.ord_srv_f_2013 t where t.cust_order_id=in_order_id;
delete from so1.ord_srv_attr_f_2013 t where t.cust_order_id=in_order_id;
delete from so1.ord_busi_f_2013  t where t.cust_order_id=in_order_id;

dbms_output.put_line('订单编号为:'||in_order_id||'已经删除!');
end;




/

