create procedure batch_rape_prod
as
ls_errmsg varchar2(1000);
cursor vars is select  cust_order_id from so1.ord_prod where cust_id in
(select t.cust_id from  so1.BAT_AUTHOR_TMP t  where t.state=2 and t.create_date > sysdate -17);

Begin

       for cur in vars loop

       so1.p_rape_order(cur.cust_order_id);

      end loop;
       exception

          when others then
          ls_errmsg := substr(sqlerrm,1,1024);
          INSERT INTO DR_EXCEPTION_LOG VALUES ('DR','ERROR',ls_errmsg,SYSDATE);
          commit;
End;




/

