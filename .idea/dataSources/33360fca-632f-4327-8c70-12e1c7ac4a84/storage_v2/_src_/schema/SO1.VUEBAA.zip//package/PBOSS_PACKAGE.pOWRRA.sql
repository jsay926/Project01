create PACKAGE     PBOSS_PACKAGE   AS  TYPE pboss_tasks_cursor  IS REF CURSOR;
end PBOSS_PACKAGE;


/

