create procedure proc_create_result (c_batch number ) is
  /*创建结果表
  create table so1.tmp_check_result
  (
  opcode number(12) not null,
  new_install_part1 varchar2(255),
  new_install_part2 varchar2(255),
  new_install_part3 varchar2(255),
  new_install_part4 varchar2(255),
  new_install_part5 varchar2(255),
  new_install_part6 varchar2(255),
  new_install_part7 varchar2(255),
  new_install_part8 varchar2(255),
  new_install_part9 varchar2(255),
  add_install_part1 varchar2(255),
  add_install_part2 varchar2(255),
  add_install_part3 varchar2(255),
  add_install_part4 varchar2(255),
  work_part1 varchar2(255),
  work_part2 varchar2(255),
  pay_part1 varchar2(255),
  pay_part2 varchar2(255),
  change_part1 varchar2(255),
  change_part2 varchar2(255),
  change_part3 varchar2(255),
  change_part4 varchar2(255),
  change_part5 varchar2(255),
  change_part6 varchar2(255),
  change_part7 varchar2(255),
  change_part8 varchar2(255),
  change_part9 varchar2(255),
  point_part1 varchar2(255)
  );
  */
  v_new_custorderid_d number(18); -- 新装数字电视用户的客户订单ID
  v_new_custorderid_b number(18); -- 加装宽带用户的客户订单ID
  v_cust_id number(18); -- 新装的客户ID
  v_d_mainofferid number(18); -- 数字主策划ID
  v_d_mainoffername varchar2(64); -- 数字主策划名称
  v_d_mainofferorderid number(18); -- 数字主策划订单ID
  v_d_mainsrvpkgid number(18); -- 数字基本服务包ID
  v_d_mainsrvpkgname varchar2(64); -- 数字基本服务包名称
  v_d_spromofferid number(18); -- 数字增值策划ID
  v_d_spromoffername varchar2(64); -- 数字增值策划名称
  v_d_spromofferorderid number(18); -- 数字增值策划订单ID
  v_d_spromsrvpkgid number(18); -- 数字增值服务包ID
  v_d_spromsrvpkgname varchar2(64); -- 数字增值服务包名称
  v_d_res_subtype number(18); -- 机顶盒资源型号
  v_d_res_name varchar2(64); -- 机顶盒资源名称
  v_count number(12); -- 统计数量参数
  v_remark varchar2(255); -- 订单附加信息的备注
  
  v_b_mainofferid number(18); -- 宽带基本策划ID
  v_b_mainoffername varchar2(64); -- 宽带基本策划名称
  v_b_mainofferorderid number(18); -- 宽带基本策划订单ID
  
  v_d_prod_inst_id number(18); -- 数字用户实例ID
  
  v_d_zhcustorderid number(18); -- 置换的套餐变更订单ID
  v_d_zhofferid number(18); -- 置换策划ID
  v_d_zhoffername varchar2(255); -- 置换策划名称
  v_d_zhofferorderid number(18); -- 置换的套餐变更策划订单ID
  
  v_d_zh_res_subtype number(18); -- 高清机顶盒资源型号
  v_d_zh_res_name varchar2(64); -- 高清机顶盒资源名称
  
  v_b_prod_inst_id number(18); -- 宽带用户实例ID
  v_b_zscustorderid number(18); -- 订购增值套餐客户订单ID

  v_new_install_part1 varchar2(255);
  v_new_install_part2 varchar2(255);
  v_new_install_part3 varchar2(255);
  v_new_install_part4 varchar2(255);
  v_new_install_part5 varchar2(255);
  v_new_install_part6 varchar2(255);
  v_new_install_part7 varchar2(255);
  v_new_install_part8 varchar2(255);
  v_new_install_part9 varchar2(255);
  v_add_install_part1 varchar2(255);
  v_add_install_part2 varchar2(255);
  v_add_install_part3 varchar2(255);
  v_add_install_part4 varchar2(255);
  v_work_part1 varchar2(255);
  v_work_part2 varchar2(255);
  v_pay_part1 varchar2(255);
  v_pay_part2 varchar2(255);
  v_change_part1 varchar2(255);
  v_change_part2 varchar2(255);
  v_change_part3 varchar2(255);
  v_change_part4 varchar2(255);
  v_change_part5 varchar2(255);
  v_change_part6 varchar2(255);
  v_change_part7 varchar2(255);
  v_change_part8 varchar2(255);
  v_change_part9 varchar2(255);
  v_point_part1 varchar2(255);

  c_d_mainofferid number(18) := 800500010062; -- 期望数字主策划ID
  c_d_spromofferid number(18) := 800500010003; -- 期望数字增值策划ID
  c_d_mainsrvpkgid number(18) := 800600010429; -- 期望数字基本服务包ID
  c_d_spromsrvpkgid number(18) := 800600010037; -- 期望数字增值服务包ID，09_新视觉高清包_35元
  c_d_res_subtype number(18) := 44; -- 机顶盒资源类型，标清广播式基本型_天柏CA
  
  c_b_mainofferid number(18) := 800500010030; -- 期望宽带主策划ID，有线宽带_4M包年免初装_600元_套餐
  
  c_d_zhofferid number(18) := 80050000204; -- 期望“1209置换_互动(免三月点播)_高清包免费_200元”策划ID
  c_d_zhsrvpkgid number(18) := 800600010350; -- 期望“8元互动产品”服务包ID
  c_d_zhsrvpkgid2 number(18) := 800600010348; -- 期望“一个月免费高清产品”服务包ID
  
  c_d_zh_res_subtype number(18) := 42; -- 高清机顶盒资源类型
  
  c_b_zsofferid number(18) := 800101; -- 赠送点三个月150点策划ID
  
  ---获取员工
  cursor operators is select operator_id from so1.tmp_operator_check where batch_no=c_batch;
  
begin
  /*for c_op.operator_id in startNo .. endNo loop*/
  delete from  so1.tmp_check_result where batch_no=c_batch;
  commit;
  for c_op in operators loop
    -- 1、准备参数
    -- 1.1获取新装数字电视用户的客户订单ID
    begin
      select max(cust_order_id) into v_new_custorderid_d from (
        select op.cust_order_id
        from so1.ord_prod op,so1.ord_busi ob
        where op.busioper_order_id = ob.busioper_order_id
        and op.op_id = c_op.operator_id
        and ob.business_id = 800001000001
        and op.prod_spec_id = 800200000001
        and op.create_date <= to_date('2012-09-02 23:59:59','yyyy-mm-dd hh24:mi:ss')
        union all
        select op.cust_order_id
        from so1.ord_prod_f_2012 op,so1.ord_busi_f_2012 ob
        where op.busioper_order_id = ob.busioper_order_id
        and op.op_id = c_op.operator_id
        and ob.business_id = 800001000001
        and op.prod_spec_id = 800200000001
        and op.create_date <= to_date('2012-09-02 23:59:59','yyyy-mm-dd hh24:mi:ss')
      );
    exception
      when others then
        v_new_custorderid_d := 0;
    end;
    
    -- 1.2获取客户ID、备注
    begin
      select cust_id,remark into v_cust_id,v_remark
      from (
        select oc.cust_id,oc.remark
        from so1.ord_cust oc
        where oc.cust_order_id = v_new_custorderid_d
        union all
        select oc.cust_id,oc.remark
        from so1.ord_cust_f_2012 oc
        where oc.cust_order_id = v_new_custorderid_d
      ) where rownum = 1;
    exception
      when others then
        v_cust_id := 0;
        v_remark := '';
    end;
    
    -- 1.3获取加装宽带用户的客户订单ID
    begin
      select max(cust_order_id) into v_new_custorderid_b from (
        select op.cust_order_id
        from so1.ord_prod op,so1.ord_busi ob
        where op.busioper_order_id = ob.busioper_order_id
        and op.op_id = c_op.operator_id
        and ob.business_id = 800001000001
        and op.prod_spec_id = 800200000003
        and op.cust_id = v_cust_id
        and op.create_date <= to_date('2012-09-02 23:59:59','yyyy-mm-dd hh24:mi:ss')
        union all
        select op.cust_order_id
        from so1.ord_prod_f_2012 op,so1.ord_busi_f_2012 ob
        where op.busioper_order_id = ob.busioper_order_id
        and op.op_id = c_op.operator_id
        and ob.business_id = 800001000001
        and op.prod_spec_id = 800200000003
        and op.cust_id = v_cust_id
        and op.create_date <= to_date('2012-09-02 23:59:59','yyyy-mm-dd hh24:mi:ss')
      );
    exception
      when others then
        v_new_custorderid_b := 0;
    end;
    
    -- 2、开始计算
    -- 2.1 新装
    -- 2.1.1基本策划是否正确
    begin
      select offer_id,offer_name,offer_order_id 
      into v_d_mainofferid,v_d_mainoffername,v_d_mainofferorderid
      from (
        select pi.product_item_id offer_id,pi.name offer_name,oo.offer_order_id
        from so1.ord_offer oo,product.up_product_item pi
        where oo.offer_id = pi.product_item_id
        and oo.cust_order_id = v_new_custorderid_d
        and oo.is_main_offer = 1
        and oo.state = 1
        union all
        select pi.product_item_id offer_id,pi.name offer_name,oo.offer_order_id
        from so1.ord_offer_f_2012 oo,product.up_product_item pi
        where oo.offer_id = pi.product_item_id
        and oo.cust_order_id = v_new_custorderid_d
        and oo.is_main_offer = 1
        and oo.state = 1
      ) where rownum = 1;
    exception
      when others then
        v_d_mainofferid := 0;
        v_d_mainoffername := '未订购';
        v_d_mainofferorderid := 0;
    end;
    if v_d_mainofferid = c_d_mainofferid then
      v_new_install_part1 := '正确';
    else
      v_new_install_part1 := '不正确：'||v_d_mainoffername;
    end if;
    
    -- 2.1.2基本服务包是否正确
    begin
      select srvpkg_id,srvpkg_name 
      into v_d_mainsrvpkgid,v_d_mainsrvpkgname
      from (
        select pi.product_item_id srvpkg_id,pi.name srvpkg_name
        from so1.ord_srvpkg os,product.up_product_item pi
        where os.srvpkg_id = pi.product_item_id
        and os.cust_order_id = v_new_custorderid_d
        and os.state = 1
        and os.offer_order_id = v_d_mainofferorderid
        union all
        select pi.product_item_id srvpkg_id,pi.name srvpkg_name
        from so1.ord_srvpkg_f_2012 os,product.up_product_item pi
        where os.srvpkg_id = pi.product_item_id
        and os.cust_order_id = v_new_custorderid_d
        and os.state = 1
        and os.offer_order_id = v_d_mainofferorderid
      ) where rownum = 1;
    exception
      when others then
        v_d_mainsrvpkgid := 0;
        v_d_mainsrvpkgname := '未订购';
    end;
    if v_d_mainsrvpkgid = c_d_mainsrvpkgid then
      v_new_install_part2 := '正确';
    else
      v_new_install_part2 := '不正确：'||v_d_mainsrvpkgname;
    end if;
    
    -- 2.1.3增值策划是否正确
    begin
      select offer_id,offer_name,offer_order_id 
      into v_d_spromofferid,v_d_spromoffername,v_d_spromofferorderid
      from (
        select pi.product_item_id offer_id,pi.name offer_name,oo.offer_order_id
        from so1.ord_offer oo,product.up_product_item pi
        where oo.offer_id = pi.product_item_id
        and oo.cust_order_id = v_new_custorderid_d
        and oo.is_main_offer = 0
        and oo.state = 1
        union all
        select pi.product_item_id offer_id,pi.name offer_name,oo.offer_order_id
        from so1.ord_offer_f_2012 oo,product.up_product_item pi
        where oo.offer_id = pi.product_item_id
        and oo.cust_order_id = v_new_custorderid_d
        and oo.is_main_offer = 0
        and oo.state = 1
      ) where rownum = 1;
    exception
      when others then
        v_d_spromofferid := 0;
        v_d_spromoffername := '未订购';
        v_d_spromofferorderid := 0;
    end;
    if v_d_spromofferid = c_d_spromofferid then
      v_new_install_part3 := '正确';
    else
      v_new_install_part3 := '不正确：'||v_d_spromoffername;
    end if;
    
    -- 2.1.4增值服务包是否正确
    begin
      select srvpkg_id,srvpkg_name 
      into v_d_spromsrvpkgid,v_d_spromsrvpkgname
      from (
        select pi.product_item_id srvpkg_id,pi.name srvpkg_name
        from so1.ord_srvpkg os,product.up_product_item pi
        where os.srvpkg_id = pi.product_item_id
        and os.cust_order_id = v_new_custorderid_d
        and os.state = 1
        and os.offer_order_id = v_d_spromofferorderid
        union all
        select pi.product_item_id srvpkg_id,pi.name srvpkg_name
        from so1.ord_srvpkg_f_2012 os,product.up_product_item pi
        where os.srvpkg_id = pi.product_item_id
        and os.cust_order_id = v_new_custorderid_d
        and os.state = 1
        and os.offer_order_id = v_d_spromofferorderid
      ) where rownum = 1;
    exception
      when others then
        v_d_spromsrvpkgid := 0;
        v_d_spromsrvpkgname := '未订购';
    end;
    if v_d_spromsrvpkgid = c_d_spromsrvpkgid then
      v_new_install_part4 := '正确';
    else
      v_new_install_part4 := '不正确：'||v_d_spromsrvpkgname;
    end if;
    
    -- 2.1.5机顶盒是否正确
    begin
      select res_subtype,res_name 
      into v_d_res_subtype,v_d_res_name
      from (
        select rcd.res_sub_type res_subtype,rcd.res_name
        from so1.ord_prod_res opr,res.res_code_definition rcd
        where opr.res_code = rcd.res_code
        and rcd.res_type=2
        and opr.cust_order_id = v_new_custorderid_d
        union all
        select rcd.res_sub_type res_subtype,rcd.res_name
        from so1.ord_prod_res_f_2012 opr,res.res_code_definition rcd
        where opr.res_code = rcd.res_code
        and rcd.res_type = 2
        and opr.cust_order_id = v_new_custorderid_d
      ) where rownum = 1;
    exception
      when others then
        v_d_res_subtype := 0;
        v_d_res_name := '未订购';
    end;
    if v_d_res_subtype = c_d_res_subtype then
      v_new_install_part5 := '正确';
    else
      v_new_install_part5 := '不正确：'||v_d_res_name;
    end if;
    
    -- 2.1.6是否产生工单
    begin
      select count(1) into v_count from (
        select 1 from so1.ord_prod op
        where op.outline_flag = 1
        and op.cust_order_id = v_new_custorderid_d
        union all
        select 1 from so1.ord_prod_f_2012 op
        where op.outline_flag = 1
        and op.cust_order_id = v_new_custorderid_d
      );
    exception
      when others then
        v_count := 0;
    end;
    if v_count > 0 then
      v_new_install_part6 := '正确';
    else
      v_new_install_part6 := '不正确';
    end if;
    
    -- 2.1.7是否写了备注
    if v_remark is not null then
      v_new_install_part7 := '正确';
    else
      v_new_install_part7 := '不正确';
    end if;
    
    -- 2.1.8是否打印了受理单
    v_count := 0;
    begin
      select print_count into v_count from (
        select ov.print_count
        from so1.ord_voucher ov 
        where ov.cust_order_id = v_new_custorderid_d
        union all
        select ov.print_count
        from so1.ord_voucher ov 
        where ov.cust_order_id = v_new_custorderid_d
      ) where rownum = 1;
    exception
      when others then
        v_count := 0;
    end;
    if v_count > 0 then
      v_new_install_part8 := '正确';
    else
      v_new_install_part8 := '不正确';
    end if;
    
    -- 2.1.9是否打印了发票
    v_count := 0;
    begin
      select count(1) into v_count from (
        select 1 from so1.ord_invoice ov
        where ov.cust_order_id = v_new_custorderid_d
        and ov.print_count = 0
        union all
        select 1 from so1.ord_invoice_2012 ov 
        where ov.cust_order_id = v_new_custorderid_d
        and ov.print_count = 0
      );
    exception
      when others then
        v_count := 0;
    end;
    if v_count = 0 then
      v_new_install_part9 := '正确';
    else
      v_new_install_part9 := '不正确';
    end if;
    
    -- 2.2加装宽带
    -- 2.2.1宽带策划是否正确
    begin
      select offer_id,offer_name,offer_order_id
      into v_b_mainofferid,v_b_mainoffername,v_b_mainofferorderid
      from (
        select pi.product_item_id offer_id,pi.name offer_name,oo.offer_order_id
        from so1.ord_offer oo,product.up_product_item pi
        where oo.offer_id = pi.product_item_id
        and oo.cust_order_id = v_new_custorderid_b
        and oo.is_main_offer = 1
        and oo.state = 1
        union all
        select pi.product_item_id offer_id,pi.name offer_name,oo.offer_order_id
        from so1.ord_offer_f_2012 oo,product.up_product_item pi
        where oo.offer_id = pi.product_item_id
        and oo.cust_order_id = v_new_custorderid_b
        and oo.is_main_offer = 1
        and oo.state = 1
      ) where rownum = 1;
    exception
      when others then
        v_b_mainofferid := 0;
        v_b_mainoffername := '未订购';
        v_b_mainofferorderid := 0;
    end;
    if v_b_mainofferid = c_b_mainofferid then
      v_add_install_part1 := '正确';
    else
      v_add_install_part1 := '不正确：'||v_b_mainoffername;
    end if;
    
    -- 2.2.2是否选择了CM类型的资源
    v_count := 0;
    begin
      select count(1) into v_count from (
        select 1
        from so1.ord_prod_res opr,res.res_code_definition rcd
        where opr.res_code = rcd.res_code
        and rcd.res_type = 6
        and opr.cust_order_id = v_new_custorderid_b
        union all
        select 1
        from so1.ord_prod_res_f_2012 opr,res.res_code_definition rcd
        where opr.res_code = rcd.res_code
        and rcd.res_type = 6
        and opr.cust_order_id = v_new_custorderid_b
      );
    exception
      when others then
        v_count := 0;
    end;
    if v_count > 0 then
      v_add_install_part2 := '正确';
    else
      v_add_install_part2 := '不正确';
    end if;
    
    -- 2.2.3是否产生了工单
    v_count := 0;
    begin
      select count(1) into v_count from (
        select 1 from so1.ord_prod op
        where op.outline_flag = 1
        and op.cust_order_id = v_new_custorderid_b
        union all
        select 1 from so1.ord_prod_f_2012 op
        where op.outline_flag = 1
        and op.cust_order_id = v_new_custorderid_b
      );
    exception
      when others then
        v_count := 0;
    end;
    if v_count > 0 then
      v_add_install_part3 := '正确';
    else
      v_add_install_part3 := '不正确';
    end if;
    
    -- 2.2.4是否打印了受理单
    v_count := 0;
    begin
      select count(1) into v_count from (
        select 1 from so1.ord_voucher ov
        where ov.cust_order_id = v_new_custorderid_b
        and ov.print_count = 0
        union all
        select 1 from so1.ord_voucher ov 
        where ov.cust_order_id = v_new_custorderid_b
        and ov.print_count = 0
      );
    exception
      when others then
        v_count := 0;
    end;
    if v_count = 0 then
      v_add_install_part4 := '正确';
    else
      v_add_install_part4 := '不正确';
    end if;
    
    -- 2.3工单异常处理
    -- 2.3.1是否完成了数字工单
    v_count := 0;
    begin
      select count(*) into v_count 
      from pboss.sf_order so 
      where so.so_serial_code = v_new_custorderid_d
      and so.state = 3;
    exception
      when others then
        v_count := 0;
    end;
    if v_count > 0 then
      v_work_part1 := '正确';
    else
      v_work_part1 := '不正确';
    end if;
    
    -- 2.3.2是否完成了宽带工单
    v_count := 0;
    begin
      select count(*) into v_count 
      from pboss.sf_order so 
      where so.so_serial_code = v_new_custorderid_b
      and so.state = 3;
    exception
      when others then
        v_count := 0;
    end;
    if v_count > 0 then
      v_work_part2 := '正确';
    else
      v_work_part2 := '不正确';
    end if;
    
    -- 2.4账户续费
    -- 2.4.1是否续费现金998
    v_count := 0;
    begin
      select count(*) into v_count 
      from zg.payment_201209 pm
      where pm.staff_id = c_op.operator_id
      and pm.amount = 99800
      and pm.operation_type = 103000
      and pm.state = 1;
    exception
      when others then
        v_count := 0;
    end;
    if v_count = 1 then
      v_pay_part1 := '正确';
    else
      v_pay_part1 := '不正确';
    end if;
    
    -- 2.4.2是否打印发票
    v_count := 0;
    begin
      select count(*) into v_count 
      from zg.payment_201209 pm,zg.invoice_201209 iv
      where pm.payment_id = iv.payment_id
      and pm.staff_id = c_op.operator_id
      and pm.amount = 99800
      and pm.operation_type = 103000
      and pm.state = 1
      and iv.print_count > 0;
    exception
      when others then
        v_count := 0;
    end;
    if v_count > 0 then
      v_pay_part2 := '正确';
    else
      v_pay_part2 := '不正确';
    end if;
    
    -- 2.5整转置换
    -- 获取数字用户实例ID v_d_prod_inst_id
    begin
      select prod_inst_id into v_d_prod_inst_id
      from (
        select op.prod_inst_id
        from so1.ord_prod op
        where op.cust_order_id = v_new_custorderid_d
        union all
        select op.prod_inst_id
        from so1.ord_prod_f_2012 op
        where op.cust_order_id = v_new_custorderid_d
      ) where rownum = 1;
    exception
      when others then
        v_d_prod_inst_id := 0;
    end;
    
    -- 获取置换的增加增值套餐订单ID
    begin
      select max(cust_order_id) into v_d_zhcustorderid from (
        select op.cust_order_id
        from so1.ord_prod op,so1.ord_busi ob
        where op.busioper_order_id = ob.busioper_order_id
        and op.op_id = c_op.operator_id
        and ob.business_id = 800001000024
        and op.prod_inst_id = v_d_prod_inst_id
        and op.create_date <= to_date('2012-09-02 23:59:59','yyyy-mm-dd hh24:mi:ss')
        union all
        select op.cust_order_id
        from so1.ord_prod_f_2012 op,so1.ord_busi_f_2012 ob
        where op.busioper_order_id = ob.busioper_order_id
        and op.op_id = c_op.operator_id
        and ob.business_id = 800001000024
        and op.prod_inst_id = v_d_prod_inst_id
        and op.create_date <= to_date('2012-09-02 23:59:59','yyyy-mm-dd hh24:mi:ss')
      );
    exception
      when others then
        v_d_zhcustorderid := 0;
    end;
    
    -- 2.5.1增加“1209置换_互动(免三月点播)_高清包免费_200元”活动套餐
    begin
      select offer_id,offer_name,offer_order_id
      into v_d_zhofferid,v_d_zhoffername,v_d_zhofferorderid
      from (
        select pi.product_item_id offer_id,pi.name offer_name,oo.offer_order_id
        from so1.ord_offer oo,product.up_product_item pi
        where oo.offer_id = pi.product_item_id
        and oo.cust_order_id = v_d_zhcustorderid
        and oo.is_main_offer = 0
        and oo.state = 1
        union all
        select pi.product_item_id offer_id,pi.name offer_name,oo.offer_order_id
        from so1.ord_offer_f_2012 oo,product.up_product_item pi
        where oo.offer_id = pi.product_item_id
        and oo.cust_order_id = v_d_zhcustorderid
        and oo.is_main_offer = 0
        and oo.state = 1
      ) where rownum = 1;
    exception
      when others then
        v_d_zhofferid := 0;
        v_d_zhoffername := '未订购';
        v_d_zhofferorderid := 0;
    end;
    if v_d_zhofferid = c_d_zhofferid then
      v_change_part1 := '正确';
    else
      v_change_part1 := '不正确：'||v_d_zhoffername;
    end if;
    
    -- 2.5.2是否订购了8元互动产品
    v_count := 0;
    begin
      select count(1) into v_count
      from (
        select 1
        from so1.ord_srvpkg os,product.up_product_item pi
        where os.srvpkg_id = pi.product_item_id
        and os.cust_order_id = v_d_zhcustorderid
        and os.state = 1
        and os.offer_order_id = v_d_zhofferorderid
        and os.srvpkg_id = c_d_zhsrvpkgid
        union all
        select 1
        from so1.ord_srvpkg_f_2012 os,product.up_product_item pi
        where os.srvpkg_id = pi.product_item_id
        and os.cust_order_id = v_d_zhcustorderid
        and os.state = 1
        and os.offer_order_id = v_d_zhofferorderid
        and os.srvpkg_id = c_d_zhsrvpkgid
      ) where rownum = 1;
    exception
      when others then
        v_count := 0;
    end;
    if v_count > 0 then
      v_change_part2 := '正确';
    else
      v_change_part2 := '不正确';
    end if;
    
    -- 2.5.3是否订购了“一个月免费高清产品”
    v_count := 0;
    begin
      select count(1) into v_count
      from (
        select 1
        from so1.ord_srvpkg os,so1.ord_prod op
        where os.prod_order_id = op.prod_order_id
        and op.prod_inst_id = v_d_prod_inst_id
        and os.state = 1
        and os.srvpkg_id = c_d_zhsrvpkgid2
        union all
        select 1
        from so1.ord_srvpkg_f_2012 os,so1.ord_prod_f_2012 op
        where os.prod_order_id = op.prod_order_id
        and op.prod_inst_id = v_d_prod_inst_id
        and os.state = 1
        and os.srvpkg_id = c_d_zhsrvpkgid2
      ) where rownum = 1;
    exception
      when others then
        v_count := 0;
    end;
    if v_count > 0 then
      v_change_part3 := '正确';
    else
      v_change_part3 := '不正确';
    end if;
    
    -- 2.5.4老资源是否回收
    v_count := 0;
    begin
      select count(*) into v_count from (
        select 1
        from so1.ord_prod_res opr
        where opr.res_state = 2
        and opr.cust_order_id = v_d_zhcustorderid
        union all
        select 1
        from so1.ord_prod_res_f_2012 opr
        where opr.res_state = 2
        and opr.cust_order_id = v_d_zhcustorderid
      );
    exception
      when others then
        v_count := 0;
    end;
    if v_count > 0 then
      v_change_part4 := '正确';
    else
      v_change_part4 := '不正确';
    end if;
    
    -- 2.5.5是否升级一台高清机顶盒
    begin
      select res_subtype,res_name 
      into v_d_zh_res_subtype,v_d_zh_res_name
      from (
        select rcd.res_sub_type res_subtype,rcd.res_name
        from so1.ord_prod_res opr,res.res_code_definition rcd
        where opr.res_code = rcd.res_code
        and rcd.res_type = 2
        and opr.state = 1
        and opr.cust_order_id = v_d_zhcustorderid
        union all
        select rcd.res_sub_type res_subtype,rcd.res_name
        from so1.ord_prod_res_f_2012 opr,res.res_code_definition rcd
        where opr.res_code = rcd.res_code
        and rcd.res_type = 2
        and opr.state = 1
        and opr.cust_order_id = v_d_zhcustorderid
      ) where rownum = 1;
    exception
      when others then
        v_d_zh_res_subtype := 0;
        v_d_zh_res_name := '未订购';
    end;
    if v_d_zh_res_subtype = c_d_zh_res_subtype then
      v_change_part5 := '正确';
    else
      v_change_part5 := '不正确：'||v_d_zh_res_name;
    end if;
    
    -- 2.5.6是否收款200元
    begin
      select count(1) into v_count
      from (
        select 1
        from so1.ord_price op
        where op.cust_order_id = v_d_zhcustorderid
        and op.fact_money = 20000
        union all
        select 1
        from so1.ord_price_f_2012 op
        where op.cust_order_id = v_d_zhcustorderid
        and op.fact_money = 20000
      );
    exception
      when others then
        v_count := 0;
    end;
    if v_count > 0 then
      v_change_part6 := '正确';
    else
      v_change_part6 := '不正确';
    end if;
    
    -- 2.5.7是否产生工单
    begin
      select count(1) into v_count from (
        select 1 from so1.ord_prod op
        where op.outline_flag = 1
        and op.cust_order_id = v_d_zhcustorderid
        union all
        select 1 from so1.ord_prod_f_2012 op
        where op.outline_flag = 1
        and op.cust_order_id = v_d_zhcustorderid
      );
    exception
      when others then
        v_count := 0;
    end;
    if v_count > 0 then
      v_change_part7 := '正确';
    else
      v_change_part7 := '不正确';
    end if;
    
    -- 2.5.8是否打印了受理单
    v_count := 0;
    begin
      select print_count into v_count from (
        select ov.print_count
        from so1.ord_voucher ov 
        where ov.cust_order_id = v_d_zhcustorderid
        union all
        select ov.print_count
        from so1.ord_voucher ov 
        where ov.cust_order_id = v_d_zhcustorderid
      ) where rownum = 1;
    exception
      when others then
        v_count := 0;
    end;
    if v_count > 0 then
      v_change_part8 := '正确';
    else
      v_change_part8 := '不正确';
    end if;
    
    -- 2.5.9是否打印了发票
    v_count := 0;
    begin
      select count(1) into v_count from (
        select 1 from so1.ord_invoice ov
        where ov.cust_order_id = v_d_zhcustorderid
        and ov.print_count = 0
        union all
        select 1 from so1.ord_invoice_2012 ov 
        where ov.cust_order_id = v_d_zhcustorderid
        and ov.print_count = 0
      );
    exception
      when others then
        v_count := 0;
    end;
    if v_count = 0 then
      v_change_part9 := '正确';
    else
      v_change_part9 := '不正确';
    end if;
    
    -- 2.6赠送点
    -- 获取宽带用户实例ID
    begin
      select prod_inst_id into v_b_prod_inst_id
      from (
        select op.prod_inst_id
        from so1.ord_prod op
        where op.cust_order_id = v_new_custorderid_b
        union all
        select op.prod_inst_id
        from so1.ord_prod_f_2012 op
        where op.cust_order_id = v_new_custorderid_b
      ) where rownum = 1;
    exception
      when others then
        v_d_prod_inst_id := 0;
    end;
    
    -- 获取订购活动套餐的订购增值套餐订单ID
    begin
      select max(cust_order_id) into v_b_zscustorderid from (
        select op.cust_order_id
        from so1.ord_prod op,so1.ord_busi ob
        where op.busioper_order_id = ob.busioper_order_id
        and op.op_id = c_op.operator_id
        and ob.business_id = 800001000024
        and op.prod_inst_id = v_b_prod_inst_id
        union all
        select op.cust_order_id
        from so1.ord_prod_f_2012 op,so1.ord_busi_f_2012 ob
        where op.busioper_order_id = ob.busioper_order_id
        and op.op_id = c_op.operator_id
        and ob.business_id = 800001000024
        and op.prod_inst_id = v_b_prod_inst_id
      );
    exception
      when others then
        v_b_zscustorderid := 0;
    end;
    
    -- 2.6.1宽带用户是否订购了“赠送点三个月150点”
    v_count := 0;
    begin
      select count(*) into v_count
      from (
        select 1
        from so1.ord_offer oo,product.up_product_item pi
        where oo.offer_id = pi.product_item_id
        and oo.cust_order_id = v_b_zscustorderid
        and oo.is_main_offer = 0
        and oo.state = 1
        and oo.offer_id = c_b_zsofferid
        union all
        select 1
        from so1.ord_offer_f_2012 oo,product.up_product_item pi
        where oo.offer_id = pi.product_item_id
        and oo.cust_order_id = v_b_zscustorderid
        and oo.is_main_offer = 0
        and oo.state = 1
        and oo.offer_id = c_b_zsofferid
      ) where rownum = 1;
    exception
      when others then
        v_count := 0;
    end;
    if v_count > 0 then
      v_point_part1 := '正确';
    else
      v_point_part1 := '不正确';
    end if;
    
    --记录考试结果
    insert into so1.tmp_check_result
  (
  operator_id ,
  is_install_offer_right  ,
  is_install_prod_right ,
  is_install_sp_off_right  ,
  is_install_sp_pro_right  ,
  is_install_res_right  ,
  is_install_outline_right  ,
  is_install_remark_right  ,
  is_install_voucher_right ,
  is_install_invoice_right ,
  is_add_offer_right  ,
  is_add_res_right  ,
  is_add_outline_right  ,
  is_add_voucher_right  ,
  is_install_outline_done  ,
  is_add_outline_done  ,
  is_payfee_right ,
  is_pay_invoice_right ,
  is_chg_offer_right ,
  is_chg_prod1_right  ,
  is_chg_prod2_right ,
  is_chg_res_back ,
  is_chg_res_prom  ,
  is_chg_price_200 ,
  is_chg_outline_right ,
  is_chg_voucher_right ,
  is_chg_invoice_rigth  ,
  is_point_right,
  batch_no 
  )
  select c_op.operator_id,
          v_new_install_part1 ,
          v_new_install_part2 ,
          v_new_install_part3 ,
          v_new_install_part4 ,
          v_new_install_part5 ,
          v_new_install_part6 ,
          v_new_install_part7 ,
          v_new_install_part8 ,
          v_new_install_part9 ,
          v_add_install_part1 ,
          v_add_install_part2 ,
          v_add_install_part3 ,
          v_add_install_part4 ,
          v_work_part1 ,
          v_work_part2 ,
          v_pay_part1 ,
          v_pay_part2 ,
          v_change_part1 ,
          v_change_part2 ,
          v_change_part3 ,
          v_change_part4 ,
          v_change_part5 ,
          v_change_part6 ,
          v_change_part7 ,
          v_change_part8 ,
          v_change_part9 ,
          v_point_part1,
          c_batch 
    from dual;
    commit;
  end loop;
end proc_create_result;





/

