create procedure create_prod_grp(v_cust_id in number, v_grp_name in varchar2, v_org_id in number, v_region_id in number)
is
v_grp_inst_id number(14);
v_rl_count number(2);
begin

  select so1.ins_prod_grp$seq.nextval into v_grp_inst_id from dual;
  insert into so1.ins_prod_grp values(
  v_grp_inst_id,v_grp_inst_id,v_grp_name,v_cust_id,1,0,sysdate,sysdate,sysdate, to_date('2099-12-31 23:59:59', 'yyyy-mm-dd hh24:mi:ss'), 0, v_org_id,v_region_id,null);

  for cur_ins_prod in (select ip.prod_inst_id from so1.ins_prod ip where ip.cust_id=v_cust_id)
  loop
    select count(gr.ins_grp_relat_id) into v_rl_count from so1.ins_grp_relat gr where gr.prod_inst_id=cur_ins_prod.prod_inst_id;
    if v_rl_count = 0 then
      insert into so1.ins_grp_relat values(
      so1.ins_grp_relat$seq.nextval, v_grp_inst_id, cur_ins_prod.prod_inst_id,1,0,sysdate,sysdate,0,v_org_id,v_region_id,v_region_id,0);
    end if;
  end loop;
end;




/

