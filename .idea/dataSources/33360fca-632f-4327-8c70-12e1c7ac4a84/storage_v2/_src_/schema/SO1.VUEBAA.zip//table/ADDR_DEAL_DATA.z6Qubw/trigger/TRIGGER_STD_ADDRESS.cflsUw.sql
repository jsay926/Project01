create trigger TRIGGER_STD_ADDRESS
  after insert
  on ADDR_DEAL_DATA
  for each row
  Declare

  v_Pstd_Addrid   NUMBER;
  v_Rec_Pstd      Pboss.Addr_Std_Addr%ROWTYPE;
  v_Rec_Stb       Pboss.Addr_Std_Addr%ROWTYPE;
  v_Trunc_Address VARCHAR2(512);
  v_Trunc_Address2 VARCHAR2(512);
  v_Rec_Dist Pboss.i_Addr_To_Pboss%Rowtype;
  v_Mgd_Id   NUMBER;
  std_parent_id Number;


Begin
  If Inserting Then
    Begin
      /*     Select *
       Into :Ndata
      From So1.Addr_Deal_Data
      Where Addr_Deal_Data_Id = :Ndata.Addr_Deal_Data_Id;*/

      If :Ndata.Op_Type = 3 Then
        Begin
          Begin
            If :Ndata.Addr_Type = 1 Then
           Begin
             select *
               INTO v_Rec_Pstd
               from Pboss.Addr_Std_Addr Pstd
              where Pstd.Topic_Word = To_Char(:Ndata.Old_Addr_Id)
                And Pstd.Std_Addr_Type = :Ndata.Addr_Type + 1
                And Pstd.Name = :Ndata.Old_Addr_Name
                And pstd.state=1;
             UPDATE Pboss.Addr_Std_Addr Sstd
                SET Sstd.District_Id = Sstd.District_Id + 77000000,
                    Sstd.Modify_Date = Sysdate,state=0
              Where Sstd.Std_Addr_Id = v_Rec_Pstd.Std_Addr_Id
                And Sstd.Std_Addr_Type = 2
                And Sstd.State = 1;
        /*     UPDATE Pboss.Addr_Mgr_Addr_Addr_Rel Rel
                SET Rel.State = 0
              WHERE Rel.Std_Addr_Id = v_Rec_Pstd.Std_Addr_Id
                And rel.Addr_Type = 2;*/

                UPDATE Pboss.Addr_Std_Addr Sstd
                   SET Sstd.District_Id = Sstd.District_Id + 77000000,
                       Sstd.Modify_Date = Sysdate,state=0
                 Where  Sstd.Topic_Word = To_Char(:Ndata.Old_Addr_Id)
                   And Sstd.Std_Addr_Type In (4,3)
                   And Sstd.State = 1;
           End;

            Elsif :Ndata.Addr_Type = 2 Then
              Begin
                select *
                  INTO v_Rec_Pstd
                  from Pboss.Addr_Std_Addr Pstd
                 where Pstd.Topic_Word = To_Char(:Ndata.Ext0)
                   And Pstd.Std_Addr_Type = :Ndata.Addr_Type + 1
                   And Pstd.Name = Regexp_Replace(:Ndata.Old_Addr_Name,
                                                  '(.*)-(.*)',
                                                  '\1')
                  And pstd.state=1;
                UPDATE Pboss.Addr_Std_Addr Sstd
                   SET Sstd.District_Id = Sstd.District_Id + 77000000,
                       Sstd.Modify_Date = Sysdate,state=0
                 Where Sstd.Std_Addr_Id = v_Rec_Pstd.Std_Addr_Id
                   And Sstd.Std_Addr_Type = 3
                   And Sstd.State = 1;

                 UPDATE Pboss.Addr_Std_Addr Sstd
                   SET Sstd.District_Id = Sstd.District_Id + 77000000,
                       Sstd.Modify_Date = Sysdate,state=0
                 Where Sstd.Parent_Addr_Id = v_Rec_Pstd.Std_Addr_Id
                   And Sstd.Std_Addr_Type = 4
                   And Sstd.State = 1;
              End;

            Elsif :Ndata.Addr_Type = 3 Then
              Begin
                select *
                  INTO v_Rec_Pstd
                  from Pboss.Addr_Std_Addr Pstd
                 where Pstd.Topic_Word = To_Char(:Ndata.Ext0)
                   And Pstd.Std_Addr_Type = :Ndata.Addr_Type + 1
                   And Pstd.Name = Regexp_Replace(:Ndata.Old_Addr_Name,
                                                  '(.*)-(.*)',
                                                  '\2')
                  And pstd.state=1;
                UPDATE Pboss.Addr_Std_Addr Sstd
                   SET Sstd.District_Id = Sstd.District_Id + 77000000,
                       Sstd.Modify_Date = Sysdate,state=0
                 Where Sstd.Std_Addr_Id = v_Rec_Pstd.Std_Addr_Id
                   And Sstd.Std_Addr_Type = 4
                   And Sstd.State = 1;

              End;
            End If;
          End;
        End;

      Elsif :Ndata.Op_Type = 2 Then
         Begin
             If :Ndata.Addr_Type = 1 Then
               Begin
                 select *
                   INTO v_Rec_Pstd
                   from Pboss.Addr_Std_Addr Pstd
                  where Pstd.Topic_Word = To_Char(:Ndata.Old_Addr_Id)
                    And Pstd.Std_Addr_Type = :Ndata.Addr_Type + 1
                    And Pstd.Name = :Ndata.Old_Addr_Name
                    And Pstd.State = 1;
                 UPDATE Pboss.Addr_Std_Addr Sstd
                    SET Sstd.Name        = :Ndata.New_Addr_Name,
                        Sstd.Detail_Name = replace(Sstd.Detail_Name,
                                                   :Ndata.Old_Addr_Name,
                                                   :Ndata.New_Addr_Name),
                                           Sstd.Modify_Date = Sysdate
                  Where Sstd.Std_Addr_Id = v_Rec_Pstd.Std_Addr_Id
                    And Sstd.Std_Addr_Type = 2
                    And Sstd.State = 1;
                 UPDATE Pboss.Addr_Std_Addr Sstd
                    SET Sstd.Detail_Name = replace(Sstd.Detail_Name,
                                                   :Ndata.Old_Addr_Name,
                                                   :Ndata.New_Addr_Name),
                        Sstd.Modify_Date = Sysdate
                  Where Sstd.Topic_Word = To_Char(:Ndata.Old_Addr_Id)
                    And Sstd.Std_Addr_Type In (3, 4)
                    And Sstd.State = 1;

               End;
             Elsif :Ndata.Addr_Type = 2 Then
               Begin

               Select  sstd.std_addr_id Into std_parent_id  From  Pboss.Addr_Std_Addr Sstd
                Where Sstd.Topic_Word = To_Char(:Ndata.Ext0)
                    And Sstd.Std_Addr_Type = 3
                    And Sstd.State = 1
                    And Name = Regexp_Replace(:Ndata.Old_Addr_Name, '(.*)-(.*)','\1');

                    Select replace(Sstd.Detail_Name,
                                                   Regexp_Replace(:Ndata.Old_Addr_Name, '(.*)-(.*)', '\1'),
                                                   Regexp_Replace(:Ndata.New_Addr_Name, '(.*)-(.*)', '\1'))
                                                    Into v_Trunc_Address2  From Pboss.Addr_Std_Addr Sstd
                                                    Where Sstd.Topic_Word = To_Char(:Ndata.Ext0)
                    And Sstd.Std_Addr_Type = 3
                    And Sstd.State = 1
                    And Name = Regexp_Replace(:Ndata.Old_Addr_Name, '(.*)-(.*)','\1');

                 UPDATE Pboss.Addr_Std_Addr Sstd
                    SET Sstd.Detail_Name = v_Trunc_Address2,
                        Sstd.Name = Regexp_Replace(:Ndata.New_Addr_Name, '(.*)-(.*)', '\1'),
                        Sstd.Modify_Date = Sysdate,
                        Sstd.spell=:Ndata.New_Addr_Name,
                        Sstd.remark=:Ndata.Ext3,
                        Sstd.detail_spell=:Ndata.New_Addr_Name
                  Where Sstd.Topic_Word = To_Char(:Ndata.Ext0)
                    And Sstd.Std_Addr_Type = 3
                    And Sstd.State = 1
                    And Name = Regexp_Replace(:Ndata.Old_Addr_Name, '(.*)-(.*)','\1');


                     /* UPDATE Pboss.Addr_Std_Addr Sstd
                   SET Sstd.District_Id = Sstd.District_Id + 77000000,
                       Sstd.Modify_Date = Sysdate,state=0
                 Where Sstd.Topic_Word = To_Char(:Ndata.Ext0)
                    And Sstd.Std_Addr_Type = 4
                    And Sstd.State = 1
                    And sstd.parent_addr_id=std_parent_id;*/

                         UPDATE Pboss.Addr_Std_Addr Sstd
                    SET Sstd.Detail_Name = v_Trunc_Address2|| ' ' ||sstd.name,
                        --Sstd.Name = Regexp_Replace(:Ndata.New_Addr_Name, '(.*)-(.*)', '\2'),
                        Sstd.Modify_Date = Sysdate,
                        Sstd.spell=:Ndata.New_Addr_Name,
                        Sstd.remark=:Ndata.Ext3,
                        Sstd.detail_spell=Regexp_Replace(:Ndata.New_Addr_Name, '(.*)-(.*)','\1')||'-'||sstd.name
                  Where Sstd.Topic_Word = To_Char(:Ndata.Ext0)
                    And Sstd.Std_Addr_Type = 4
                    And Sstd.State = 1
                    And sstd.parent_addr_id = std_parent_id;




                     Update Pboss.Addr_Attr_Ins
                        Set Attr_Value = :Ndata.Ext2
                      Where Attr_Code = 'ADDR_TYPE'
                        And Addr_Id In
                            (Select Std_Addr_Id
                               From Pboss.Addr_Std_Addr
                              Where Parent_Addr_Id = Std_Parent_Id);

                     Update Pboss.Addr_Attr_Ins
                        Set Attr_Value = :Ndata.Ext1
                      Where Attr_Code = 'FUNC_TYPE'
                        And Addr_Id In
                            (Select Std_Addr_Id
                               From Pboss.Addr_Std_Addr
                              Where Parent_Addr_Id = Std_Parent_Id);
                 End;

            /* Elsif :Ndata.Addr_Type = 3 Then
               Begin
                   Select  sstd.std_addr_id Into std_parent_id  From  Pboss.Addr_Std_Addr Sstd
                Where Sstd.Topic_Word = To_Char(:Ndata.Ext0)
                    And Sstd.Std_Addr_Type = 3
                    And Sstd.State = 1
                    And Name = Regexp_Replace(:Ndata.Old_Addr_Name, '(.*)-(.*)','\1');

                       UPDATE Pboss.Addr_Std_Addr Sstd
                    SET Sstd.Detail_Name = replace(Sstd.Detail_Name,
                                                   Regexp_Replace(:Ndata.Old_Addr_Name, '(.*)-(.*)','\2'),
                                                   Regexp_Replace(:Ndata.New_Addr_Name,'(.*)-(.*)','\2')),
                        Sstd.Name = Regexp_Replace(:Ndata.New_Addr_Name, '(.*)-(.*)', '\2'),
                        Sstd.Modify_Date = Sysdate,
                        Sstd.spell=:Ndata.New_Addr_Name,
                        Sstd.remark=:Ndata.Ext3,
                        Sstd.detail_spell=:Ndata.New_Addr_Name
                  Where Sstd.Topic_Word = To_Char(:Ndata.Ext0)
                    And Sstd.Std_Addr_Type = 4
                    And Sstd.State = 1
                    And Name = Regexp_Replace(:Ndata.Old_Addr_Name, '(.*)-(.*)','\2');
               End; */
             End If;
           End;

      Else
        Begin
          Select Pboss.Addr_Std_Addr$seq.Nextval
            Into v_Pstd_Addrid
            From Dual;

          --v_Pstd_Addrid := Pboss.Addr_Std_Addr$seq.Nextval;
          If :Ndata.Addr_Type = 1 And :Ndata.Op_Type = 1 Then
            Select *
              Into v_Rec_Dist
              From Pboss.i_Addr_To_Pboss
             Where Region_Id = :Ndata.Ext0;
            Select *
              Into v_Rec_Stb
              From Pboss.Addr_Std_Addr
             Where Std_Addr_Type = 1
               And Std_Addr_Id = v_Rec_Dist.Std_Addr_Id
               And state=1;
            Begin
              INSERT INTO Pboss.Addr_Std_Addr
              VALUES
                (v_Pstd_Addrid,
                 :Ndata.New_Addr_Name,
                 2,
                 v_Rec_Dist.District_Id,
                 v_Pstd_Addrid,
                 null,
                 v_Rec_Dist.Std_Addr_Id,
                 1,
                 :Ndata.New_Addr_Id,
                 v_Rec_Stb.Detail_Name || ' ' || :Ndata.New_Addr_Name,
                 Null,
                 :Ndata.New_Addr_Id,
                 sysdate,
                 sysdate);

              SELECT Mgd.Mgr_Addr_Id
                INTO v_Mgd_Id
                FROM Pboss.Addr_Mgr_Addr Mgd
               WHERE Mgd.Remark = To_Char(v_Rec_Dist.District_Id)
                 And Mgr_Addr_Type = 42;

              INSERT INTO Pboss.Addr_Mgr_Addr_Addr_Rel
                SELECT Pboss.Addr_Mgr_Addr_Addr_Rel$seq.Nextval,
                       42,
                       v_Mgd_Id,
                       2,
                       v_Pstd_Addrid,
                       1,
                       NULL,
                       4201
                  from Dual;

            End;
          Elsif :Ndata.Addr_Type = 2 And :Ndata.Op_Type = 1 Then
            Begin
              Select *
                Into v_Rec_Pstd
                From Pboss.Addr_Std_Addr
               Where Topic_Word = To_Char(:Ndata.Ext0)
                 And Std_Addr_Type = 2
                 And state =1;

              /* Select Pboss.Addr_Std_Addr$seq.Nextval
              Into v_Pstd_Addrid
              From Dual;*/

              --v_Pstd_Addrid   := Pboss.Addr_Std_Addr$seq.Nextval;
              
              Select  Regexp_Replace(:Ndata.New_Addr_Name, '(.*)-(.*)', '\1')
                Into v_Trunc_Address
                From Dual;
        
                   
                                insert into Pboss.Addr_Std_Addr
                select v_Pstd_Addrid,
                       v_Trunc_Address,                       
                       3,
                       v_Rec_Pstd.District_Id,
                       v_Rec_Pstd.Parent_Addr_Id || '-' ||
                       v_Rec_Pstd.Std_Addr_Id || '-' || v_Pstd_Addrid,
                       :Ndata.New_Addr_Name,
                       v_Rec_Pstd.Std_Addr_Id,
                       1,
                       Nvl(:Ndata.New_Addr_Id, ''),
                       v_Rec_Pstd.Detail_Name || ' ' || v_Trunc_Address,
                       :Ndata.New_Addr_Name,
                       v_Rec_Pstd.Topic_Word,
                       sysdate,
                       sysdate
                  from Dual;
            End;
          Else
            Begin
              If :Ndata.Op_Type = 1 And :Ndata.Addr_Type = 3 Then
                Begin
                  /*  Select t.*, rowid
                    From Pboss.Addr_Std_Addr t
                   Where Std_Addr_Type = 4;
                  v_Pstd_Addrid := Pboss.Addr_Std_Addr$seq.Nextval;*/
                  /*       Select Pboss.Addr_Std_Addr$seq.Nextval
                  Into v_Pstd_Addrid
                  From Dual;*/
                  --dbms_lock.sleep(3);
                  --grant execute on dbms_lock to so1;

                  Select Regexp_Replace(:Ndata.New_Addr_Name,
                                        '(.*)-(.*)',
                                        '\1')
                    Into v_Trunc_Address
                    From Dual;
                  Select *
                    Into v_Rec_Pstd
                    From Pboss.Addr_Std_Addr
                   Where Topic_Word = To_Char(:Ndata.Ext0)
                     And Name = v_Trunc_Address
                     And Std_Addr_Type = 3
                     And state =1;
                  --Select V_REC_PSTD From pboss.ADDR_STD_ADDR  Where topic_word =to_char(Ndata.EXT0) And std_addr_type=2;

                  insert into Pboss.Addr_Std_Addr
                    select v_Pstd_Addrid,
                           Regexp_Replace(:Ndata.New_Addr_Name,
                                          '(.*)-(.*)',
                                          '\2'),
                           4,
                           v_Rec_Pstd.District_Id,
                           v_Rec_Pstd.Std_Addr_Code || '-' || v_Pstd_Addrid,
                           :Ndata.New_Addr_Name,
                           v_Rec_Pstd.Std_Addr_Id,
                           1,
                           :Ndata.Ext3,
                           v_Rec_Pstd.Detail_Name || ' ' ||
                          -- :Ndata.Ext3,
                           Regexp_Replace(:Ndata.New_Addr_Name,
                                          '(.*)-(.*)',
                                          '\2'),
                           :Ndata.New_Addr_Name,
                           v_Rec_Pstd.Topic_Word,
                           sysdate,
                           sysdate
                      from Dual 
                    Where v_Rec_Pstd.Name<>:Ndata.New_Addr_Name;

                  insert into Pboss.Addr_Std_Addr
                    select v_Pstd_Addrid,
                           Regexp_Replace(:Ndata.New_Addr_Name,
                                          '(.*)-(.*)',
                                          '\2'),
                           4,
                           v_Rec_Pstd.District_Id,
                           v_Rec_Pstd.Std_Addr_Code || '-' || v_Pstd_Addrid,
                           :Ndata.New_Addr_Name,
                           v_Rec_Pstd.Std_Addr_Id,
                           1,
                           :Ndata.Ext3,
                           v_Rec_Pstd.Detail_Name || ' ' ||' ',  
                          -- :Ndata.Ext3,
                          /* Regexp_Replace(:Ndata.New_Addr_Name,
                                          '(.*)-(.*)',
                                          '\2'),*/
                           :Ndata.New_Addr_Name,
                           v_Rec_Pstd.Topic_Word,
                           sysdate,
                           sysdate
                      from Dual 
                    Where v_Rec_Pstd.Name=:Ndata.New_Addr_Name;


                  insert into Pboss.Addr_Attr_Ins
                    select Pboss.Addr_Attr_Ins$seq.Nextval,
                           'ADDR_TYPE',
                           1,
                           4,
                           v_Pstd_Addrid,
                           :Ndata.Ext2,
                           sysdate,
                           sysdate
                      from Dual;
                  insert into Pboss.Addr_Attr_Ins
                    select Pboss.Addr_Attr_Ins$seq.Nextval,
                           'FUNC_TYPE',
                           1,
                           4,
                           v_Pstd_Addrid,
                           :Ndata.Ext1,
                           sysdate,
                           sysdate
                      from Dual;
                End;
              End If;
            End;
          End If;
        End;
      End If;
    End;
  End If;

End Trigger_Std_Address;


/

