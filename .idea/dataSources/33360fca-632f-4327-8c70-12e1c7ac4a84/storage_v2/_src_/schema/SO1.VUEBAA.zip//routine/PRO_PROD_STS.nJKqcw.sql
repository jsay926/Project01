create PROCEDURE       "PRO_PROD_STS" (
                                            v_status          In Number,
                                            v_prod_status Out Varchar2,
                                            v_offer_status Out Varchar2,
                                            v_srvpkg_status Out Number,
                                            v_serv_status Out Number
                                           )
      Is
      v_result Varchar2(50);
      -- v_status : 1????2????3???
Begin
     If v_status Not In (1,2,3) Then
        v_result :='??????????';
        Insert Into so1.pro_log Values(so1.error_msg_seq.nextval,v_result,Sysdate);
        Commit;
     Else
         Select decode(v_status,1,'1',2,'3',3,'D'),decode(v_status,1,1,2,1,3,0),decode(v_status,1,1,2,3,3,0),decode(v_status,1,1,2,2,3,2)
         Into v_prod_status,v_offer_status,v_srvpkg_status,v_serv_status
         From dual;
     End If;
End;





/

