create FUNCTION       "GETSTATIONIDBYSTDADDRID" (stdAddrId in number) return number is
  Result number;
begin
  ---?????
select distinct station.organize_id into  Result
  from pboss.addr_mgr_addr_addr_rel rel,
       pboss.addr_mgr_addr          mgr,
       sec.sec_organize             blk,
       sec.sec_organize             station
 where rel.std_addr_id = stdAddrId
   and rel.mgr_addr_id = mgr.mgr_addr_id
   and rel.mgr_addr_type = 42 /*????????*/
   and mgr.mgr_addr_type = 42 /*????????*/
   and blk.organize_id = mgr.rel_obj_value
   and blk.org_role_type_id = 99 /*????*/
   and station.organize_id = blk.parent_organize_id
   and station.org_role_type_id =100; /*???*/
  return(Result);
end getStationIdByStdAddrId;







/

