create PROCEDURE p_task_state_99 (in_cust_code IN VARCHAR2 )

AS

BEGIN
  insert into  gj.tmp_wf_list_2015092501
  SELECT ip.PROD_INST_ID
    FROM SO1.INS_PROD ip
   WHERE CUST_ID IN (SELECT CUST_ID
                       FROM SO1.CM_CUSTOMER
                      WHERE CUST_CODE = in_cust_code)
     AND STATE = '99' and ip.PROD_INST_ID not in (select t.prod_inst_id from gj.tmp_wf_list_2015092501 t);

     dbms_output.put_line('客户证号为:'||in_cust_code||'已完成录入临时表!');
-------------更新crm
Update so1.ins_prod prod Set prod.state=1, prod.os_status='1'
Where Exists (Select 1 From  gj.tmp_wf_list_2015092501 wf Where wf.prod_inst_id=prod.prod_inst_id)
and prod.state ='99' ;
---套餐订购和产品订购关系表
Update so1.ins_off_ins_prod_rel rel Set rel.state=1
Where Exists (Select 1 From  gj.tmp_wf_list_2015092501 wf Where wf.prod_inst_id=rel.prod_inst_id)
and rel.state='99';
---套餐订购
Update so1.ins_offer offer Set offer.state=1
Where Exists (Select 1 From so1.ins_off_ins_prod_rel rel,gj.tmp_wf_list_2015092501 wf
Where wf.prod_inst_id=rel.prod_inst_id And rel.offer_inst_id=offer.offer_inst_id)
and offer.state='99';
---产品订购
Update so1.ins_srvpkg pkg Set pkg.state=1,pkg.os_status='',valid_date=sysdate
Where Exists (Select * From  gj.tmp_wf_list_2015092501 wf Where wf.prod_inst_id=pkg.prod_inst_id)
and ( pkg.state='99' or pkg.os_status='99' );
---服务订购
Update so1.ins_srv srv Set srv.state=1,valid_date=sysdate
Where Exists (Select 1 From  gj.tmp_wf_list_2015092501 wf Where wf.prod_inst_id=srv.prod_inst_id)
and srv.state='99' ;
----产品订购和服务订购的关系
Update so1.ins_srvpkg_ins_srv_rel rel Set rel.state=1,valid_date=sysdate
Where Exists (Select 1 From  gj.tmp_wf_list_2015092501 wf ,  so1.ins_srvpkg pkg
Where pkg.prod_inst_id=wf.prod_inst_id And pkg.srvpkg_inst_id=rel.srvpkg_inst_id)
and rel.state='99';

dbms_output.put_line('客户证号为:'||in_cust_code||'crm侧完成更新!');

--------------------------------帐管和帐处接口表
----帐管用户接口表
INSERT INTO zg.i_user(ACCT_ID,CUST_ID,SERV_ID,USER_PROPERTY,USER_TYPE,MSISDN,IMSI,IMEI,BRAND,ORG_ID
                       ,REGION_CODE,COUNTY_CODE,CREATE_DATE,FIRST_USE_TIME,BEGIN_DATE,VALID_DATE,EXPIRE_DATE
                       ,CYCLE_DAY,NEXT_CYCLE_DAY,DONE_CODE,RES_FLAG,REMARK,SO_NBR,MAIN_SERV_ID,BILL_TYPE
                       ,SUB_STATUS,AOC_FLAG,SPEC_FLAG,USER_STS,CORP_ORG_ID
                      )
SELECT PROD.ACCT_ID,PROD.CUST_ID,PROD.PROD_INST_ID,PROD.USER_PROP,DECODE(prod.prod_spec_id,800200000001,1,800200000002,2,800200000003,3,1)
       ,SUBSTRB(PROD.BILL_ID,1,50),SUBSTRB(PROD.SUB_BILL_ID,1,50),NULL IMEI,0 BRAND_ID,NVL(PROD.ORG_ID,0)
       ,prod.region_id REGION_CODE,0 COUNTY_CODE,PROD.CREATE_DATE,NVL(PROD.BILL_START_DATE,PROD.CREATE_DATE),PROD.CREATE_DATE,PROD.Create_Date,PROD.EXPIRE_DATE
       ,0 CYCLE_DAY,0 NEXT_CYCLE_DAY,0 DONE_CODE,NULL RES_FLAG,NULL REMARK,PROD.DONE_CODE,PROD.MAIN_PROD_INST_ID,1 BILL_TYPE
       ,0 SUB_STATUS,0 AOC_FLAG,NULL SPEC_FLAG,0 USER_STS,PROD.OWN_CORP_ORG_ID
FROM SO1.INS_PROD PROD
Join  gj.tmp_wf_list_2015092501 wf On wf.prod_inst_id=prod.prod_inst_id
WHERE  Not Exists (Select 1 From zg.i_user u Where u.serv_id=wf.prod_inst_id);
---帐处订购接口表
INSERT INTO  zg.i_user_msc nologging(SO_ID,SERV_ID,REGION_CODE,FUNC_TYPE,PROD_ID,BUSI_TYPE
                           ,FUNC_PARAM
                           ,PROPERTY,PLAN_ID,BEGIN_DATE,VALID_DATE,EXPIRE_DATE,DONE_CODE
                           ,REMARK,SO_NBR,OFFER_INST_ID,OPER_TYPE
                          )
SELECT c.so_id,NVL(pkg.PROD_INST_ID,0),NVL(pkg.REGION_ID,'0'),102 FUNC_TYPE
       ,c.prod_id,1 BUSI_TYPE
       ,NULL FUNC_PARAM,NULL PROPERTY,0 PLAN_ID,  nvl(pkg.create_date,sysdate),
        pkg.valid_date ,pkg.expire_date,0 DONE_CODE
       ,NULL REMARK,NULL SO_NBR,pkg.offer_inst_id,NULL OPER_TYPE
FROM SO1.INS_SRVPKG  PKG
join PRODUCT.UP_ITEM_RELAT pm on pkg.srvpkg_id=pm.Product_Item_Id and pm.prod_item_relat_kind_id ='SERVICE_PRICE_GENERAL_PRICE_PLAN_PKG_BOSS'  and pm.del_flag=0
join PRODUCT.UP_PRODUCT_ITEM B on PM.RELAT_PRODUCT_ITEM_ID=B.PRODUCT_ITEM_ID
join so1.INS_SRVPKG_SO_ID_REL C on C.INS_SRVPKG_ID=PKG.SRVPKG_INST_ID AND  b.extend_id=c.prod_id
Join  gj.tmp_wf_list_2015092501 wf On wf.prod_inst_id=PKG.prod_inst_id
WHERE NOT EXISTS(SELECT 1 FROM zg.i_user_msc d WHERE c.so_id=d.so_id);

---帐处优惠接口表
INSERT /*+ append */INTO zg.i_user_sprom nologging(SO_ID,SERV_ID,SERVICE_ID,REGION_CODE,SPROM_TYPE,SPROM_ID
                             ,BUSI_TYPE,SPROM_PARA,MAX_PROM,PROPERTY,PLAN_ID,VALID_DATE
                             ,EXPIRE_DATE,DONE_CODE,REMARK,SO_NBR,BEGIN_DATE
                             ,REFERENCE_OBJECT,RESULT_OBJECT,OFFER_INST_ID,OPER_TYPE
                            )
SELECT DISTINCT C.SO_ID,PKG.PROD_INST_ID,0 SERVICE_ID,PKG.REGION_ID,0 SPROM_TYPE
       ,nvl(B.EXTEND_ID,0)
       ,0 BUSI_TYPE,NULL SPROM_PARA,NULL MAX_PROM,NULL PROPERTY,10001 PLAN_ID,pkg.valid_date
       ,PKG.EXPIRE_DATE,0 DONE_CODE,NULL REMARK,0 DONE_CODE,PKG.CREATE_DATE
       ,0 REFERENCE_OBJECT,0 REFERENCE_OBJECT,PKG.OFFER_INST_ID,0 OPER_TYPE
FROM SO1.INS_SRVPKG PKG
inner join PRODUCT.UP_ITEM_RELAT pm on pkg.srvpkg_id=pm.Product_Item_Id and pm.prod_item_relat_kind_id ='SERVICE_PRICE_GENERAL_PRICE_PLAN_PKG_BILLING'  and pm.del_flag=0
inner join PRODUCT.UP_PRODUCT_ITEM B on PM.RELAT_PRODUCT_ITEM_ID=B.PRODUCT_ITEM_ID
join so1.INS_SRVPKG_SO_ID_REL C on C.INS_SRVPKG_ID=PKG.SRVPKG_INST_ID AND  b.extend_id=c.prod_id
Join  gj.tmp_wf_list_2015092501 wf On wf.prod_inst_id=PKG.prod_inst_id
WHERE NOT EXISTS(SELECT 1 FROM zg.i_user_sprom d WHERE c.so_id=d.so_id);

---接口用户状态
INSERT INTO ZG.I_USER_STATUS(SERV_ID,USER_STS,STOP_STS,REGION_CODE,VALID_DATE,EXPIRE_DATE
                              ,DONE_CODE,REMARK,SO_NBR,MGNT_STS,OPER_STS,ACCT_STS
                             )
SELECT PROD.PROD_INST_ID,DECODE(PROD.STATE,'1',1,'M',4,'C',1,'D',14,6,1,0),0,PROD.REGION_ID,PROD.VALID_DATE
       ,PROD.EXPIRE_DATE,0,PROD.REMARK,0,NULL MGNT_STS,NULL OPER_STS,NULL ACCT_STS
FROM SO1.INS_PROD PROD,gj.tmp_wf_list_2015092501 u
Where u.prod_inst_id=prod.prod_inst_id
AND  NOT EXISTS(SELECT 1 FROM zg.I_USER_STATUS d WHERE PROD.PROD_INST_ID=d.SERV_ID);

----订购状态
INSERT INTO ZG.I_USER_PROD_STS(SO_ID,SERV_ID,REGION_CODE,SERVICE_ID,PROD_STS,BEGIN_DATE
                                ,VALID_DATE,EXPIRE_DATE,SO_NBR,DONE_CODE,REMARK,pay_service_id
                               )
 SELECT c.SO_ID,NVL(PKG.PROD_INST_ID,0),NVL(PKG.REGION_ID,0),0 ,
                 (case
                            when pkg.state=1 then 1  ---正常出账
                            when pkg.state=3 and ( pkg.os_status like '%6%'  or  pkg.os_status like '%f%' )then 5     ---出账
                            when pkg.state=3 and ( pkg.os_status like '%1%' )then 2     ---欠费停
                            when pkg.state=3 and ( pkg.os_status like '%2%' )then 2     ---连带欠费停
                            when pkg.state=3 and ( pkg.os_status like '%3%'  )then 4     ---主动暂停
                            when pkg.state=3 and ( pkg.os_status like '%4%'  )then 3     ---管理停
                            when pkg.state=3  then 2   ---
                            else 1 end) prod_sts,nvl(PKG.Valid_Date,SYSDATE),greatest(nvl(PKG.Done_Date,SYSDATE),PKG.Valid_Date),nvl(PKG.EXPIRE_DATE,SYSDATE),
                              PKG.DONE_CODE,0 DONE_CODE,NULL REMARK,pkg.prod_service_id
                              FROM SO1.INS_SRVPKG PKG
JOIN SO1.INS_PROD PROD ON PROD.PROD_INST_ID=PKG.PROD_INST_ID
JOIN SO1.INS_OFFER OFFER ON OFFER.OFFER_INST_ID=PKG.OFFER_INST_ID
join so1.INS_SRVPKG_SO_ID_REL C on C.INS_SRVPKG_ID=PKG.SRVPKG_INST_ID
Join gj.tmp_wf_list_2015092501 u On u.prod_inst_id=prod.prod_inst_id
WHERE NOT EXISTS(SELECT 1 FROM zg.I_USER_PROD_STS d WHERE c.so_id=d.so_id);


---分业务表

INSERT INTO ZG.USER_SERVICE_STS(SERV_ID,SERVICE_ID,OWE_BUSINESS_TYPE_ID,STATE,
                                EFF_DATE,EXP_DATE,SO_NBR,OS_STS,ACCT_ID)
SELECT PKG.PROD_INST_ID,NVL(PKG.PROD_SERVICE_ID,0),min(DECODE(PKG.OS_STATUS,1,0,3,8,0,0)),1 STATE
       ,min(PKG.CREATE_DATE),max(PKG.EXPIRE_DATE),0 SO_NBR
       ,min( case when pkg.state=3 and (pkg.os_status like '%1%')
                       then '00000000000000010000000000000000000000000000000000'
                       else '00000000000000000000000000000000000000000000000000'
                       end),PROD.ACCT_ID
FROM SO1.INS_SRVPKG PKG
JOIN SO1.INS_PROD PROD ON PROD.PROD_INST_ID=PKG.PROD_INST_ID
WHERE pkg.prod_inst_id in (select wf.prod_inst_id from gj.tmp_wf_list_2015092501 wf)
AND  NOT EXISTS(SELECT 1 FROM zg.USER_SERVICE_STS d WHERE d.SERV_ID=PKG.PROD_INST_ID AND pkg.PROD_SERVICE_ID=d.SERVICE_ID)
GROUP BY PKG.PROD_INST_ID,PKG.PROD_SERVICE_ID,PROD.ACCT_ID;


---帐管用户
INSERT INTO ZG.SERV(SERV_ID,CUST_ID,PRODUCT_ID,BILLING_CYCLE_TYPE_ID,PRODUCT_FAMILY_ID,CREATE_DATE
                    ,RENT_DATE,COMPLETED_DATE,STATE,EFF_DATE,EXP_DATE,SERV_CODE
                    ,CUST_CODE,PRODUCT_CODE
                    ,ORDER_NUMBER,PRE_FLAG,TRANS_FEE_FLAG,PROMOTION_ID,INSTANCE_NUM,PROMOTION_FLAG
                    ,GROUP_SERV_CODE,GROUP_PRODUCT_CODE,USER_TYPE,MOB_MENU_LEVEL,CREDIT_LEVEL,REGION_ID
                    ,EXCHANGE_ID,C6,AREA_ID,SO_NBR,ACC_NBR,BILL_TYPE,ACCT_ID,WRITEOFF_PROPERTY,BRAND
                    ,GROUP_FLAG,CORP_ORG_ID,DATA_ORG_ID,SUB_BILL_ID,RES_EQU_NO,CUST_ADDR_ID,MAIN_SERV_ID
                   )
Select PROD.PROD_INST_ID,PROD.CUST_ID,0 PRODUCT_ID,0 BILLING_CYCLE_TYPE_ID,0 PRODUCT_FAMILY_ID,PROD.CREATE_DATE
       ,PROD.CREATE_DATE,PROD.CREATE_DATE,DECODE(PROD.STATE,'1','2HA','2','2HD','M','2HC','A','2HB','C','2HB','D','2HB','E','2HB','99'),PROD.CREATE_DATE,PROD.EXPIRE_DATE,PROD.PROD_INST_ID
       ,CUST.CUST_CODE,PROD.PROD_SPEC_ID
       ,CUST.DONE_CODE,0 PRE_FLAG,0 TRANS_FEE_FLAG,NULL PROMOTION_ID,NULL INSTANCE_NUM,NULL PROMOTION_FLAG
       ,NULL GROUP_SERV_CODE,NULL GROUP_PRODUCT_CODE,DECODE(PROD.PROD_SPEC_ID,800200000002,2,800200000003,4,800200000001,1,99),NULL MOB_MENU_LEVEL,NULL CREDIT_LEVEL,ADDR.REGION_ID
       ,0 EXCHANGE_ID,NULL C6,0 AREA_ID,CUST.DONE_CODE,PROD.BILL_ID ACC_NBR,2 BILL_TYPE,PROD.ACCT_ID,NULL WRITEOFF_PROPERTY,0 BRAND
       ,NULL GROUP_FLAG,PROD.OWN_CORP_ORG_ID,PROD.OWN_ORG_ID,PROD.SUB_BILL_ID,NULL RES_EQU_NO,ADDR.CUST_ADDR_ID,NVL(PROD.MAIN_PROD_INST_ID,0)
FROM SO1.INS_PROD PROD
JOIN SO1.CM_CUSTOMER CUST ON PROD.CUST_ID=CUST.CUST_ID
JOIN SO1.ACCT ACCT ON ACCT.ACCT_ID=PROD.ACCT_ID AND CUST.CUST_ID=ACCT.CUST_ID
JOIN SO1.INS_ADDRESS ADDR ON ADDR.CUST_ID=CUST.CUST_ID
Join gj.tmp_wf_list_2015092501 u On u.prod_inst_id=prod.prod_inst_id
Where Not Exists (Select 1 From ZG.SERV serv Where serv.serv_id=prod.prod_inst_id);

-----
insert into zg.cc_plan_instance_relation
select zg.seq_cc_plan_relation_id.nextval,20 cc_plan_id,1 instance_type,prod_inst_id,acct_id,1 priority,valid_date,expire_date
from so1.ins_prod a
where prod_inst_id in (select wf.prod_inst_id from gj.tmp_wf_list_2015092501 wf)
AND NOT EXISTS(SELECT 1 FROM zg.cc_plan_instance_relation b WHERE a.prod_inst_id=b.instance_id);

---用户和帐户关系表
INSERT INTO ZG.SERV_ACCT(ACCT_ID,SERV_ID,BILLING_CYCLE_TYPE_ID,ACCT_ITEM_GROUP_ID,PRIORITY,PAYMENT_RULE_ID
                          ,PAYMENT_LIMIT_TYPE,PAYMENT_LIMIT,STATE,EFF_DATE,EXP_DATE,IS_DEFAULT_ACCT_ID
                          ,SO_NBR,STATE_DATE,ACCT_ITEM_TYPE_ID)
SELECT SERV.ACCT_ID,SERV.SERV_ID,0 BILLING_CYCLE_TYPE_ID,0 ACCT_ITEM_GROUP_ID,1 PRIORITY,0 PAYMENT_RULE_ID
       ,'5XA' PAYMENT_RULE_ID,'9999999' PAYMENT_LIMIT,'00A' STATE,SERV.EFF_DATE,SERV.EXP_DATE,'T' IS_DEFAULT_ACCT_ID
       ,SERV.SO_NBR,SERV.CREATE_DATE,'82000001'
FROM ZG.SERV SERV where serv.serv_id in (select prod_inst_id  from gj.tmp_wf_list_2015092501 )
AND NOT EXISTS(SELECT 1 FROM zg.SERV_ACCT b WHERE SERV.SERV_ID=b.SERV_ID);


INSERT /*+ APPEND */ INTO zg.serv_state_attr NOLOGGING(serv_id,billing_cycle_type_id,owe_business_type_id,state,eff_date,exp_date,so_nbr,os_sts)
SELECT prod.prod_inst_id,2,0,1,prod.create_date,prod.expire_date,0
       ,decode(prod.state,'M','00010000000000000000000000000000000000000000000000','00000000000000000000000000000000000000000000000000')
FROM so1.ins_prod prod,gj.tmp_wf_list_2015092501 b
WHERE prod.prod_inst_id=b.prod_inst_id
AND NOT EXISTS(SELECT 1 FROM zg.serv_state_attr c WHERE c.SERV_ID=b.prod_inst_id);


INSERT /*+ append */INTO zg.i_user_plan nologging(SERV_ID,PLAN_ID,REGION_CODE,VALID_DATE,EXPIRE_DATE,DONE_CODE,SO_NBR,REMARK)
SELECT PROD.prod_inst_id,10001 PLAN_ID,nvl(PROD.REGION_ID,514),PROD.VALID_DATE,PROD.EXPIRE_DATE,0
       ,0,NULL REMARK
FROM SO1.INS_PROD PROD,gj.tmp_wf_list_2015092501 b
Where  prod.prod_inst_id=b.prod_inst_id
AND NOT EXISTS(SELECT 1 FROM zg.i_user_plan c WHERE c.SERV_ID=b.prod_inst_id);

          dbms_output.put_line('客户证号为:'||in_cust_code||'zg侧完成更新!');

Insert Into zg.i_sale_oper
Select ip.prod_inst_id,0,0,0,'11111111111111111111111111111111',ip.region_id,Sysdate,Sysdate,0,0,0,1
FROM so1.ins_prod ip
         where ip.cust_id in (select cust_id from so1.cm_customer where cust_code = in_cust_code)
         and ip.prod_inst_id in (select t.prod_inst_id FROM gj.tmp_wf_list_2015092501 t);


INSERT INTO zg.cust_info_chg_notify(notify_id,serv_id,service_id,acct_id,cust_id,chg_type,region_id,corp_org_id,so_nbr,state,create_date)
SELECT zg.cust_info_chg_notify$seq.nextval,a.prod_inst_id,0,a.acct_id,a.cust_id,0,region_id region_id,corp_org_id own_corp_org_id,0,1,SYSDATE
FROM
(SELECT DISTINCT prod.own_corp_org_id corp_org_id,prod.prod_inst_id,prod.acct_id,prod.cust_id,prod.region_id
FROM SO1.INS_PROD PROD,gj.tmp_wf_list_2015092501 b
         where PROD.cust_id in (select cust_id from so1.cm_customer where cust_code = in_cust_code)
         and PROD.prod_inst_id in (select t.prod_inst_id FROM gj.tmp_wf_list_2015092501 t)) a;

         dbms_output.put_line('客户证号为:'||in_cust_code||'99客户状态更新完成!');
commit;

end;


/

