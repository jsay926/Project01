create PROCEDURE     p_del_vir_105sub (in_prod_inst_id IN VARCHAR2 )
AS

BEGIN

--SELECT cust_id INTO v_cust_id FROM so1.cm_customer WHERE cust_code= in_cust_code;

insert into so1.h_ins_offer_2017
select so1.h_ins_offer$seq.nextval,t.*
from so1.ins_offer t
WHERE t.offer_inst_id IN (SELECT offer_inst_id FROM so1.ins_prod WHERE prod_inst_id=in_prod_inst_id ) ;

DELETE from so1.ins_offer t WHERE t.offer_inst_id IN (SELECT offer_inst_id FROM so1.ins_prod WHERE prod_inst_id=in_prod_inst_id ) ;

insert into so1.h_ins_off_ins_prod_rel_2017
select so1.h_ins_off_ins_prod$seq.nextval,t.*
from so1.ins_off_ins_prod_rel t
WHERE t.prod_inst_id = in_prod_inst_id ;

delete from so1.ins_off_ins_prod_rel t WHERE t.prod_inst_id =in_prod_inst_id ;

insert into so1.h_ins_srvpkg_2017
select so1.h_ins_srvpkg$seq.nextval,t.*
from so1.ins_srvpkg t
WHERE t.prod_inst_id =in_prod_inst_id ;

delete from so1.ins_srvpkg t WHERE t.prod_inst_id =in_prod_inst_id ;

insert into so1.h_ins_srvpkg_ins_srv_rel_2017
select so1.h_ins_srvpkg_ins_srv$seq.nextval,t.*
from so1.ins_srvpkg_ins_srv_rel t
WHERE t.prod_inst_id =in_prod_inst_id ;

delete from so1.ins_srvpkg_ins_srv_rel t WHERE t.prod_inst_id =in_prod_inst_id ;

insert into so1.h_ins_srv_2017
select so1.h_ins_srv$seq.nextval,t.*
from so1.ins_srv t
WHERE t.prod_inst_id =in_prod_inst_id ;

delete from so1.ins_srv t WHERE t.prod_inst_id =in_prod_inst_id ;

insert into so1.h_ins_srv_attr_2017
select so1.h_ins_srv$seq.nextval,
       ATTR_INST_ID, ATTR_ID, SRV_INST_ID, ATTR_VALUE, PROD_INST_ID, VALID_TYPE, OPER_STATE, STATE, REGION_ID, DONE_CODE,
       CREATE_DATE, DONE_DATE, VALID_DATE, EXPIRE_DATE, OP_ID, ORG_ID, REMARK, SRC_SYSTEM_ID, SRC_SYSTEM_EXT_CODE, ATTR_TYPE_CODE
from so1.ins_srv_attr t
WHERE t.prod_inst_id =in_prod_inst_id ;

delete from so1.ins_srv_attr t WHERE t.prod_inst_id =in_prod_inst_id ;

delete from so1.ins_srvpkg_so_id_rel t WHERE t.ins_prod_id =in_prod_inst_id ;

----------------------------------------------------------------------------------------------------------------------------


UPDATE zg.i_user t
SET t.expire_date=SYSDATE
WHERE t.serv_id =in_prod_inst_id ;

UPDATE zg.i_user_status t
SET t.expire_date=SYSDATE
WHERE t.serv_id =in_prod_inst_id ;

UPDATE zg.i_user_msc t
SET t.expire_date=SYSDATE
WHERE t.serv_id =in_prod_inst_id ;

UPDATE zg.i_user_prod_sts t
SET t.expire_date=SYSDATE
WHERE t.serv_id =in_prod_inst_id
AND t.expire_date >SYSDATE ;

UPDATE zg.i_user_pay_relation t
SET t.expire_date=SYSDATE
WHERE t.serv_id =in_prod_inst_id ;

UPDATE zg.i_user_plan t
SET t.expire_date=SYSDATE
WHERE t.serv_id =in_prod_inst_id ;


COMMIT ;

----------------------------------------------------------------------------------------------------------------------------



insert into zg.serv_other
            (SERV_ID, CUST_ID, PRODUCT_ID, BILLING_CYCLE_TYPE_ID, PRODUCT_FAMILY_ID,
            CREATE_DATE, RENT_DATE,
            COMPLETED_DATE, STATE, EFF_DATE,
            EXP_DATE, SERV_CODE, CUST_CODE, PRODUCT_CODE, ORDER_NUMBER, PRE_FLAG, TRANS_FEE_FLAG,PROMOTION_ID,
            INSTANCE_NUM, PROMOTION_FLAG, GROUP_SERV_CODE, GROUP_PRODUCT_CODE, USER_TYPE, MOB_MENU_LEVEL,
            CREDIT_LEVEL, REGION_ID, EXCHANGE_ID, C6, AREA_ID, SO_NBR,
            ACC_NBR, BILL_TYPE, ACCT_ID, WRITEOFF_PROPERTY, BRAND,
            GROUP_FLAG, PSO_NBR, CORP_ORG_ID, DATA_ORG_ID, SUB_BILL_ID, RES_EQU_NO, CUST_ADDR_ID)
select     SERV_ID, CUST_ID, PRODUCT_ID, BILLING_CYCLE_TYPE_ID, PRODUCT_FAMILY_ID,
           CREATE_DATE, RENT_DATE,
           COMPLETED_DATE,STATE, EFF_DATE,
           EXP_DATE, SERV_CODE, CUST_CODE, PRODUCT_CODE, ORDER_NUMBER, PRE_FLAG, TRANS_FEE_FLAG, PROMOTION_ID,
           INSTANCE_NUM, PROMOTION_FLAG, GROUP_SERV_CODE, GROUP_PRODUCT_CODE, USER_TYPE, MOB_MENU_LEVEL,
           CREDIT_LEVEL, REGION_ID, EXCHANGE_ID, C6, AREA_ID, SO_NBR,
           ACC_NBR, BILL_TYPE, ACCT_ID, WRITEOFF_PROPERTY, BRAND,
           GROUP_FLAG,0 PSO_NBR, CORP_ORG_ID, DATA_ORG_ID, SUB_BILL_ID, RES_EQU_NO, CUST_ADDR_ID
from zg.serv t
where t.serv_id =in_prod_inst_id ;

delete from zg.serv t
where t.serv_id =in_prod_inst_id ;

update zg.serv_acct t
set state='00X'
where t.serv_id=in_prod_inst_id ;

UPDATE zg.user_service_sts t
SET t.state=0,t.exp_date=SYSDATE
where t.serv_id =in_prod_inst_id ;

UPDATE zg.serv_state_attr t
SET t.state=0,t.exp_date=SYSDATE
where t.serv_id =in_prod_inst_id ;

UPDATE zg.cc_plan_instance_relation t
SET t.exp_date=SYSDATE
where t.instance_id =in_prod_inst_id ;

COMMIT ;

----------------------------------------------------------------------------------------------------------------------------


Insert Into zg.I_SALE_OPER
Select p.prod_inst_id,0,0,0,'11111111111111111111111111111111',p.region_id,Sysdate,Sysdate,0,0,0,1
From so1.ins_prod p
where p.prod_inst_id=in_prod_inst_id ;

COMMIT ;

----------------------------------------------------------------------------------------------------------------------------

insert into so1.h_ins_prod_2017
select so1.h_ins_prod$seq.nextval,t.*
from so1.ins_prod t
where t.prod_inst_id=in_prod_inst_id ;

delete from so1.ins_prod t WHERE t.prod_inst_id=in_prod_inst_id ;

COMMIT ;

END ;
/

