create PROCEDURE Sycn_Addr_Name is
  v_Today  date; --今天
  v_Sql    varchar2(4096); --待执行SQL
  v_Update varchar2(4096); --待执行SQL
  type Mycursor is ref cursor;
  Tlist      Mycursor; --游标，存储待循环数据集合
  Cust_Id    NUMBER;
  Std_Addr_Name VARCHAR2(200);
begin

  v_Today := Trunc(sysdate);

  v_Sql := ' Select Distinct  ad.cust_id,ad.Std_Addr_Name From so1.ord_cust_f_' ||
           To_Char(v_Today, 'yyyy') || ' ord, So1.Ins_Address Ad,So1.Cm_Cust_Contact_Info Io
  Where ord.business_id=800001000052
  And ord.DONE_DATE>Sysdate -2
  And replace(Io.Cont_Addr,'||Chr(39)||' '||Chr(39)||')<>replace(ad.Std_Addr_Name,'||Chr(39)||' '||Chr(39)||')
  and  Ad.Cust_Id = Io.Cust_Id
  And ord.cust_id=ad.cust_id';

  Dbms_Output.Put_Line(v_Sql);

  --查询昨天的发票打印记录并到同步表里
  open Tlist for v_Sql;
  loop
    fetch Tlist
      into Cust_Id, Std_Addr_Name;

    exit when Tlist%NOTFOUND;

    v_Update := 'Update So1.Cm_Cust_Contact_Info Io Set io.Cont_Addr=' ||
               Chr(39)||Std_Addr_Name||Chr(39)|| '  where io.cust_id=' || Cust_Id;

    execute immediate v_Update;
    --Dbms_Output.Put_Line(v_Update);
    --Dbms_Output.Put_Line('---------');
  end loop;
  commit;
  close Tlist;
end;


/

