create procedure batch_rape_cust 
as
ls_errmsg varchar2(1000);
cursor cur is  (SELECT a.cust_order_id
FROM
(
SELECT substr(t.vars,INSTR(vars,'customerOrderId">',1,1)+17,12) cust_order_id,t.queue_id,t.error_message,t.create_date,t.state_date
FROM so1.vm_work_flow t WHERE  t.state=99 AND t.vars LIKE '%customerOrderId">%' 
UNION
SELECT substr(t.vars,INSTR(vars,'lOrdCustId">',1,1)+12,12) cust_order_id,t.queue_id,t.error_message,t.create_date,t.state_date
FROM so1.vm_work_flow t 
WHERE  t.state=99 AND t.vars LIKE '%lOrdCustId">%' 
) a ) ;        
Begin
       for ord in cur  loop

       so1.p_rape_order(ord.cust_order_id);

      end loop;
       exception

          when others then
          ls_errmsg := substr(sqlerrm,1,1024);
          INSERT INTO DR_EXCEPTION_LOG VALUES ('DR','ERROR',ls_errmsg,SYSDATE);
          commit; 
End;





/

