create procedure p_chg_stb_cmmac(stbno in varchar2 default null,cmmac in varchar2 default null ,v_msg out varchar2) is
v_stbno varchar2(20) :=upper(trim(stbno));
v_cmmac varchar2(15) :=upper(trim(cmmac));
v_cunt number(2) :=0;---计数器
v_exists_stbno varchar2(20) := '';---占用输入MAC的机顶盒
v_old_cmmac varchar2(20) := ''; ---原CMMAC
v_state number(2) := 0;
/**v_res_code number(10) :=0;
v_org_id number(10) :=0;
**/
begin
--首先判断机顶盒是否存在
select count(1)  into v_cunt from res.res_terminal rt where rt.serial_no=v_stbno;
if v_cunt =0 then
   v_msg := '该机顶盒序列号不存在';
   goto update_result;
elsif v_cunt > 1 then
   v_msg := '系统存在重复机顶盒序列号，请核实.';
   goto update_result;
end if;
--判断机顶盒是否为高清机顶盒
/**
Select al.Res_Code,t.org_id
  into v_Res_Code,v_org_id
  From Res.Res_Terminal Al, Res.Res_Repository t
 Where Al.Rep_Id = t.Rep_Id
   And Al.Serial_No = v_stbno;
**/
/*select res_code into v_res_code from res.res_terminal where serial_no=v_stbno;*/
/**if ((v_res_code = 101100322  OR v_res_code = 1145566 OR v_res_code = 2003) And v_org_id=1001) Or  v_org_id<>1001  then null;
dbms_output.put_line(v_res_code);
Else
   v_msg :='该机顶盒不是高清机顶盒，不可添加CMMAC';
   goto update_result;
end if;
  **/ 
--判断cmmac是否被占用
v_cunt := 0;
select count(1) into v_cunt from res.res_terminal t where t.cmmac=v_cmmac;
if v_cunt>0 then
   select r.serial_no into v_exists_stbno from  res.res_terminal r where r.cmmac=v_cmmac;
   v_msg := '该CMMAC已被其他机顶盒占用，机顶盒号码为'||v_exists_stbno||'.';
   goto update_result;
end if;

--判断CMMAC是否为12位
v_cunt :=0;
select length(v_cmmac) into v_cunt from dual;
if v_cunt = 12 then null;
else 
   v_msg := '输入的CMMAC不足或者超过12位，请确认并重新输入';
   goto update_result;
end if;

--更新CMMAC
v_cunt := 0;
select cmmac ,state into v_old_cmmac,v_state  from res.res_terminal tt where tt.serial_no=v_stbno;
update res.res_terminal set cmmac=v_cmmac where serial_no=v_stbno;

if v_state=3 then
   select count(1) into v_cunt from so1.ins_prod_res where res_equ_no=v_stbno;
   if v_cunt = 0 then
      select count(1) into v_cunt from so1.ord_prod_res where res_equ_no=v_stbno;
      if v_cunt = 0 then
         v_msg :='机顶盒CMMAC已更新，但机顶盒状态与实际数据不符，请核实';
         goto update_result;
      else
         update so1.ord_prod_res opr set opr.res_equ_no2=v_cmmac where opr.res_equ_no=v_stbno;
      end if;
   else
      update so1.ins_prod_res pr set pr.res_equ_no2=v_cmmac where pr.res_equ_no=v_stbno;
      insert into so1.BAT_AUTHOR_TMP
      select  so1.bat_author_tmp$seq.nextval,null,null,p.cust_id,null,0,0,p.prod_inst_id,sysdate ,2,222,2001,0,null,null
      from so1.ins_prod p where p.bill_id=v_stbno;
      v_msg := '机顶盒CMMAC和LDAP更新成功';
      goto update_result;
   end if;
else
   v_msg := '机顶盒CMMAC更新成功';
   goto update_result;
end if;


<<update_result>>
insert into so1.stb_change_cmmac_result(stb_id ,cmmac ,old_cmmac,update_date,v_message )
select v_stbno,v_cmmac,v_old_cmmac,sysdate,v_msg from dual;
commit;

exception
when others then
return;



end;





/

