create PROCEDURE DANG_BALANCE
IS
v_acct_id  number(16);
v_count    number(16);
v_charge   number;
v_payment_id  number;
ls_errmsg varchar2(1000);
begin
  for rec in (select * from gj4.cm_0401 where user_id<>11492763 )
  loop
  begin
    v_charge:=rec.chagre*100;
    select acct_id into v_acct_id from so1.ins_prod
    where prod_inst_id =rec.user_id and expire_date>sysdate;
    select count(*) into v_count from zg.acct_balance
    where acct_id=v_acct_id and balance_type_id=11 and exp_date>sysdate;
    --
    select zg.payment_id$seq.nextval into v_payment_id from dual;
    insert into  zg.payment_201306 (PAYMENT_ID,OPERATION_TYPE,PAYMENT_METHOD,
    PAYED_METHOD,CERTIFIED_CODE,CERTIFIED_TYPE,RELATED_PAYMENT_ID,
    OPERATED_PAYMENT_SERIAL_NBR,STAFF_ID,AMOUNT,BILL_AMOUNT,LATE_FEE,LAST_CHANGE,
    CUR_CHANGE,BALANCE_SOURCE,BALANCE_PAYOUT,PAYMENT_DATE,STATE,STATE_DATE,CREATED_DATE,
    PRE_AMOUNT,CUR_AMOUNT,PRE_BALANCE,CUR_BALANCE,BANK_ID,STAFF_REGION_ID,REGION_ID,ACCT_ID,
    ACC_NBR,DISCOUNT_ID,INVOICE_FLAG,IS_BAD_DEBT,REMARK,ORG_ID,CORP_ORG_ID,STAFF_CORP_ORG_ID,
    DATA_ORG_ID,CARD_NO,OPEN_FLAG,NEXT_OPEN_DATE,PRICE_KIND_ID,PRICE_KIND_NAME)
    values(v_payment_id,110000,0,1,null,100113,0,null,9990570,v_charge,0,0,0,0,v_charge,0,
    sysdate,1,sysdate,sysdate,0,0,0,0,0,512,512,v_acct_id,null,0,0,0,null,99,1001,0,0,
    null,0,null,0,null);
    --
    if v_count=0 then
      insert into  zg.acct_balance (ACCT_BALANCE_ID,BALANCE_TYPE_ID,ACCT_ID,
      EFF_DATE,EXP_DATE,BALANCE,RESERVE_BALANCE,CYCLE_UPPER,CYCLE_LOWER,CYCLE_UPPER_TYPE,
      CYCLE_LOWER_TYPE,STATE,STATE_DATE,SERV_ID,REGION_CODE,CORP_ORG_ID,CREATE_DATE)values
      (zg.acct_balance$seq.nextval,11,v_acct_id,date'2013-6-1',date'2099-12-31',0,0,0,0,0,0,1,sysdate,0,512,1001,null);
    end if;
    update zg.acct_balance set balance=balance+v_charge,state_date=sysdate
    where acct_id=v_acct_id and balance_type_id=11
    and state=1 and exp_date>sysdate and rownum=1;
    --
    insert into zg.acct_blc_back_rec(BLC_BACK_ID,ACCT_ID,BALANCE_TYPE_ID,OPERATION_TYPE,
    ACCT_ITEM_ID,ACCT_ITEM_NAME,BILLING_CYCLE_ID,AMOUNT,DEAL_TIME,STAFF_ID,REGION_ID,
    CORP_ORG_ID,ORG_ID,BACK_REASON,IS_PRINT,CRM_INVOICE_ID,PAYMENT_ID,STATE,STATE_TIME,
    REMARKS,TARGET_STAFF_ID,BATCH_CODE)values
    (dang_tmp.nextval,v_acct_id,11,118000,0,'互动点播计费科目',201306,v_charge,sysdate,9990570,512,
    1001,3078,'6.1点播免费',1,0,v_payment_id,0,sysdate,null,null,0);
    commit;
    exception
   when others then
          ls_errmsg := substr(sqlerrm,1,1024);
          INSERT INTO DR_EXCEPTION_LOG VALUES ('DR','ERROR',rec.user_id||ls_errmsg,SYSDATE);
          commit; 
    end;       
  end loop;
end;




/

