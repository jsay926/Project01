create PROCEDURE sync_invoice_data_crm is
v_today date; --今天
v_yesterday date; --昨天
v_sql varchar2(4096); --待执行SQL
v_insert varchar2(4096); --待执行SQL
type mycursor is ref cursor;
tlist       mycursor; --游标，存储待循环数据集合
v_count NUMBER; --循环计数器

INVOICE_ID           NUMBER;
CUST_ORDER_ID        NUMBER;
INVOICE_AMOUNT       NUMBER;
PRINT_COUNT          NUMBER;
INVOICE_CODT         VARCHAR2(20);
IMAGE                VARCHAR2(2408);
STAFF_CODE           VARCHAR2(50);
INVOICE_STATE        CHAR(1);
PRINT_DATE           DATE;
CREATE_DATE          DATE;
REGION_ID            VARCHAR2(6);
REMARK               VARCHAR2(255);
DONE_CODE            NUMBER;
DONE_DATE            DATE;
VALID_DATE           DATE;
EXPIRE_DATE          DATE;
OP_ID                NUMBER;
ORG_ID               NUMBER;
ORDER_CODE           VARCHAR2(40);
BILL_ID              VARCHAR2(120);
CUST_NAME            VARCHAR2(80);
ORG_CODE             VARCHAR2(80);
CUST_ID              NUMBER;
BALANCE              NUMBER;
INVOICE_TYPE         NUMBER;
INVOICE_NUM          VARCHAR2(40);
SELL_ORG_D           NUMBER;
SELL_ORG_NAME        VARCHAR2(128);
TEMPLATE_ID          NUMBER;
TEMPLATE_VERSION     NUMBER;
STATE                NUMBER;
ORDER_STATE          NUMBER;
CUST_CODE            VARCHAR2(40);
INVOICE_LIST_NO      VARCHAR2(20);
BUSINESS_ID          NUMBER;
REVERSE_INVOICE_ID   NUMBER;
REVERSE_INVOICE_CODE VARCHAR2(40);
REVERSE_LIST_NO      VARCHAR2(40);
UP_RUNNING_NO        VARCHAR2(50);
UP_RETURN_CODE       NUMBER;
UP_STATE             NUMBER;
SRC_SYSTEM_ID        NUMBER;
UP_MESSAGE           VARCHAR2(2408);
MERGEINVOICEID       NUMBER;
begin

    v_count := 0;
    v_today := trunc(sysdate);


    --昨天日期
    select trunc(v_today - 1) into v_yesterday from dual;

    v_sql := /* 'select '
    ||'inv.INVOICE_ID      as INVOICE_ID,'
    ||'null                as CUST_ORDER_ID,' --客户订单编号
    ||'inv.INVOICE_AMOUNT  as INVOICE_AMOUNT,'
    ||'inv.PRINT_COUNT     as PRINT_COUNT,'
    ||'''发票——国税''      as INVOICE_CODT,'
    ||'inv.IMAGE           as IMAGE,'
    ||'inv.STAFF_CODE      as STAFF_CODE,' --开票人工号
    ||'inv.STATE           as INVOICE_STATE,' --发票状态
    ||'invl.PRINT_DATE     as PRINT_DATE,' --打印日期
    ||'inv.CREATED_DATE    as CREATE_DATE,' --创建日期
    ||'inv.REGION_ID       as REGION_ID,'
    ||'null                as REMARK,' --备注
    ||'inv.PAYMENT_ID      as DONE_CODE,' --受理编号?
    ||'inv.PAY_DATE        as DONE_DATE,' --受理日期
    ||'null                as VALID_DATE,' --生效日期
    ||'null                as EXPIRE_DATE,' --失效日期
    ||'inv.STAFF_ID        as OP_ID,' --操作员ID
    ||'pay.ORG_ID          as ORG_ID,' --受理组织ID
    ||'null                as ORDER_CODE,' --订单编号
    ||'inv.ACC_NBR         as BILL_ID,' --计费号
    ||'cust.CUST_NAME      as CUST_NAME,' --客户名称
    ||'null                as ORG_CODE,' --受理组织编号
    ||'cust.CUST_ID        as CUST_ID,' --客户ID
    ||'''0''               as BALANCE,' --余额，无用属性
    ||'''1''               as INVOICE_TYPE,'
    ||'inv.INVOICE_CODE    as INVOICE_NUM,'
    ||'inv.CORP_ORG_ID     as SELL_ORG_D,'
    ||'inv.CORP_ORG_ID     as SELL_ORG_NAME,'
    ||'''0''               as TEMPLATE_ID,' --模板编号
    ||'''0''               as TEMPLATE_VERSION,' --模板版本号
    ||'''1''               as STATE,' --状态
    ||'null                as ORDER_STATE,' --订购状态
    ||'cust.CUST_CODE      as CUST_CODE,' --客户证号
    ||'inv.LIST_NO         as INVOICE_LIST_NO,' --发票册号
    ||'null                as BUSINESS_ID,' --业务类型
    ||'inv.reverse_invoice_id                as REVERSE_INVOICE_ID,' --作废发票ID
    ||'inv.reverse_invoice_code                as REVERSE_INVOICE_CODE,' --作废发票号
    ||'inv.reverse_list_no                as REVERSE_LIST_NO,' --作废册号
    ||'null                as UP_RUNNING_NO,' --税控报文流水号
    ||'null                as UP_RETURN_CODE,' --税控报文响应状态码
    ||'null                as UP_STATE,' --税控处理线程处理状态
    ||'''2''               as SRC_SYSTEM_ID,' --发票来源1或空CRM，2帐管，默认为CRM
    ||'null                as UP_MESSAGE,' --税控处理线程处理信息：如异常信息
    ||'null                as MERGEINVOICEID'              --合并后的发票id如果不为空则说明该条记录被合并
    ||' from zg.invoice_'||to_char(v_yesterday, 'yyyymm')
    ||' inv, res.res_invoice ic,(select invlog.invoice_id, max(invlog.print_date) print_date from zg.invoice_log_'
    ||to_char(v_yesterday, 'yyyymm')
    ||'  invlog group by invlog.invoice_id)' --invoice_log按invoice_id取最近一条记录，避免出现多条发票记录
    ||' invl,zg.payment_'||to_char(v_yesterday, 'yyyymm')
    ||' pay,zg.acct  acct, zg.cust '
    ||' where inv.invoice_id= invl.invoice_id'
    ||' and inv.payment_id=pay.payment_id'
    ||' and inv.acct_id=acct.acct_id'
    ||' and acct.cust_id=cust.cust_id'
    ||' and inv.invoice_code=ic.invoice_code'
    ||' and ic.res_code=to_char(1200001)'
    ||' and inv.CREATED_DATE between '||so1.to_date_expr(v_yesterday)
    ||' and '||so1.to_date_expr(v_today)
    ||' union all  '  */
    ' SELECT Inv.INVOICE_ID, Inv.CUST_ORDER_ID, Inv.INVOICE_AMOUNT, Inv.PRINT_COUNT, Inv.INVOICE_CODT, Inv.IMAGE, Inv.STAFF_CODE,
                     Inv.INVOICE_STATE, Inv.PRINT_DATE, Inv.CREATE_DATE, Inv.REGION_ID, Inv.REMARK, Inv.DONE_CODE, Inv.DONE_DATE, Inv.VALID_DATE, Inv.EXPIRE_DATE,
                     Inv.OP_ID, Inv.ORG_ID, Inv.ORDER_CODE, Inv.BILL_ID, Inv.CUST_NAME, Inv.ORG_CODE, Inv.CUST_ID, Inv.BALANCE, Inv.INVOICE_TYPE, Inv.INVOICE_NUM,
                     Case When ic.invoice_no between TO_CHAR(49650001) And TO_CHAR(49950000) And Ic.INVOICE_CODE = to_char(232001208112)  Then 5141 Else Inv.Sell_Org_D End, 
                     Inv.SELL_ORG_NAME, Inv.TEMPLATE_ID, Inv.TEMPLATE_VERSION, Inv.STATE, Inv.ORDER_STATE, Inv.CUST_CODE, Ic.INVOICE_CODE,
                     Inv.BUSINESS_ID, Inv.REVERSE_INVOICE_ID, Inv.REVERSE_INVOICE_CODE, Inv.REVERSE_LIST_NO, Inv.UP_RUNNING_NO, Inv.UP_RETURN_CODE,
                     Inv.UP_STATE, Inv.SRC_SYSTEM_ID, Inv.UP_MESSAGE, Inv.MERGEINVOICEID FROM so1.ord_invoice_'||to_char(v_today, 'yyyy')
    ||' inv, res.res_invoice ic '
    ||' where inv.invoice_num=ic.invoice_no '
    ||' And  Inv.Invoice_list_no = ic.list_no '
    ||' and ic.res_code=to_char(1200001)'
    --||' and inv.sell_org_d In (1001,3303,3329,3106)'
    ||' and inv.CREATE_DATE between '||so1.to_date_expr(v_yesterday)
    ||' and '||so1.to_date_expr(v_today);

    dbms_output.put_line(v_sql);

    --查询昨天的发票打印记录并到同步表里
    open tlist for v_sql;
    loop
        fetch tlist into INVOICE_ID, CUST_ORDER_ID, INVOICE_AMOUNT, PRINT_COUNT,
            INVOICE_CODT, IMAGE, STAFF_CODE, INVOICE_STATE, PRINT_DATE, CREATE_DATE,
            REGION_ID, REMARK, DONE_CODE, DONE_DATE, VALID_DATE, EXPIRE_DATE, OP_ID,
            ORG_ID, ORDER_CODE, BILL_ID, CUST_NAME, ORG_CODE, CUST_ID, BALANCE, INVOICE_TYPE,
            INVOICE_NUM, SELL_ORG_D, SELL_ORG_NAME, TEMPLATE_ID, TEMPLATE_VERSION,
            STATE, ORDER_STATE, CUST_CODE, INVOICE_LIST_NO, BUSINESS_ID, REVERSE_INVOICE_ID,
            REVERSE_INVOICE_CODE, REVERSE_LIST_NO, UP_RUNNING_NO, UP_RETURN_CODE, UP_STATE,
            SRC_SYSTEM_ID, UP_MESSAGE, MERGEINVOICEID;

        exit when tlist%NOTFOUND;

        v_insert := 'insert into so1.ORD_INVOICE_SYN_'||to_char(v_today, 'yyyy')
            ||'@NJCRM1 '
            || ' values('
            ||''''||INVOICE_ID||''','
            ||''''||CUST_ORDER_ID||''','
            ||''''||INVOICE_AMOUNT||''','
            ||''''||PRINT_COUNT||''','
            ||''''||INVOICE_CODT||''','
            ||''''||IMAGE||''','
            ||''''||STAFF_CODE||''','
            ||''''||INVOICE_STATE||''','
            ||to_date_expr(PRINT_DATE)||','
            ||to_date_expr(CREATE_DATE)||','
            ||''''||REGION_ID||''','
            ||''''||REMARK||''','
            ||''''||DONE_CODE||''','
            ||to_date_expr(DONE_DATE)||','
            ||''''||''','
            ||to_date_expr(EXPIRE_DATE)||','
            ||''''||OP_ID||''','
            ||''''||ORG_ID||''','
            ||''''||ORDER_CODE||''','
            ||''''||BILL_ID||''','
            ||''''||CUST_NAME||''','
            ||''''||ORG_CODE||''','
            ||''''||CUST_ID||''','
            ||''''||BALANCE||''','
            ||''''||INVOICE_TYPE||''','
            ||''''||INVOICE_NUM||''','
            ||''''||SELL_ORG_D||''','
            ||''''||SELL_ORG_NAME||''','
            ||''''||TEMPLATE_ID||''','
            ||''''||TEMPLATE_VERSION||''','
            ||''''||STATE||''','
            ||''''||ORDER_STATE||''','
            ||''''||CUST_CODE||''','
            ||''''||INVOICE_LIST_NO||''','
            ||''''||BUSINESS_ID||''','
            ||''''||REVERSE_INVOICE_ID||''','
            ||''''||REVERSE_INVOICE_CODE||''','
            ||''''||REVERSE_LIST_NO||''','
            ||''''||UP_RUNNING_NO||''','
            ||''''||UP_RETURN_CODE||''','
            ||''''||UP_STATE||''','
            ||''''||SRC_SYSTEM_ID||''','
            ||''''||UP_MESSAGE||''','
            ||''''||MERGEINVOICEID||''')';

        execute immediate v_insert;
        v_count := v_count + 1;

        --每1000条提交一次
        if v_count = 1000 then
            commit;
            v_count := 0;
        end if;
    end loop;
    commit;
    close tlist;
end;


/*
CREATE OR REPLACE FUNCTION to_date_expr (date date) return varchar is
begin
  return 'to_date('''||to_char(date,'yyyy-mm-dd hh24:mi:ss')||''', ''yyyy-mm-dd hh24:mi:ss'')';
end;*/

 

