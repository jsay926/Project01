create view BM_V_INVOICE_PRINT as
  SELECT inv.invoice_id invoice_id,
          inv.invoice_list_no invoice_code,
          inv.invoice_num invoice_no,
          inv.invoice_amount amount,
          2 AS status,
          inv.sell_org_d corp_org_id,
          inv.print_date print_date
   FROM so1.ord_invoice_2011 inv
   WHERE inv.invoice_num IS NOT NULL
   -- and inv.invoice_type = 1 ?? 2??
   UNION
   SELECT "INVOICE_ID",
          "INVOICE_CODE",
          "INVOICE_NO",
          "AMOUNT",
          "STATUS",
          "CORP_ORG_ID",
          "PRINT_DATE"
   FROM so1.bm_invoice_print_sync_data





/

