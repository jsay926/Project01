create PROCEDURE "PROC_UA_MOVE_CMD_CALL1" (
    v_busicmdcallid_str in varchar, v_necmdcallid_str in varchar) is
  v_busicmdcallid number(16) := 0;
  v_necmdcallid number(16) := 0;
  v_dealstate number(16) := 0;
begin
  begin
  v_busicmdcallid := to_number(v_busicmdcallid_str);
  v_necmdcallid := to_number(v_necmdcallid_str);
  if v_busicmdcallid <= 0 then
    --如果网元指令没有对应的业务指令，则直接将网元指令移至结束表
    insert into ua.ua_ne_command_call_over(
    ne_cmd_call_id,busi_cmd_call_id,customer_order_id,
    product_order_id,done_code,product_inst_id,ne_command_id,
    busi_cmd_code,busi_cmd_id,cmd_object,ne_id,busi_priority,
    cmd_order,org_id,command_content,extend_content,create_date,
    cmd_max_retry_count,deal_state,cmd_exec_date,cmd_state,
    cmd_status_info,cmd_retry_count,cmd_last_send_date,cmd_confirm_date,
    auth_object_no,prod_act_types,net_id,server_flag)
    select uncc.ne_cmd_call_id,uncc.busi_cmd_call_id,uncc.customer_order_id,
    uncc.product_order_id,uncc.done_code,uncc.product_inst_id,uncc.ne_command_id,
    uncc.busi_cmd_code,uncc.busi_cmd_id,uncc.cmd_object,uncc.ne_id,uncc.busi_priority,
    uncc.cmd_order,uncc.org_id,uncc.command_content,uncc.extend_content,uncc.create_date,
    uncc.cmd_max_retry_count,uncc.deal_state,uncc.cmd_exec_date,uncc.cmd_state,
    uncc.cmd_status_info,uncc.cmd_retry_count,uncc.cmd_last_send_date,uncc.cmd_confirm_date,
    uncc.auth_object_no,uncc.prod_act_types,uncc.net_id,uncc.server_flag
    from ua.ua_ne_command_call uncc
    where uncc.ne_cmd_call_id = v_necmdcallid;

    delete from ua.ua_ne_command_call uncc
    where uncc.ne_cmd_call_id = v_necmdcallid;
  else
    --如果网元指令对应的业务指令状态不为未处理或处理中，则将业务指令及网元指令移至结束表
    begin
    select ibcc.deal_state into v_dealstate
    from ua.i_busi_command_call ibcc
    where ibcc.busi_cmd_call_id = v_busicmdcallid;
    exception
          when others then
            v_dealstate := 0;
    end;

    if v_dealstate != 0 and v_dealstate != 1 then
      if v_dealstate = 3 or v_dealstate = 4 then
        --1、移网元指令
        insert into ua.ua_ne_command_call_over(
        ne_cmd_call_id,busi_cmd_call_id,customer_order_id,
        product_order_id,done_code,product_inst_id,ne_command_id,
        busi_cmd_code,busi_cmd_id,cmd_object,ne_id,busi_priority,
        cmd_order,org_id,command_content,extend_content,create_date,
        cmd_max_retry_count,deal_state,cmd_exec_date,cmd_state,
        cmd_status_info,cmd_retry_count,cmd_last_send_date,cmd_confirm_date,
        auth_object_no,prod_act_types,net_id,server_flag)
        select uncc.ne_cmd_call_id,uncc.busi_cmd_call_id,uncc.customer_order_id,
        uncc.product_order_id,uncc.done_code,uncc.product_inst_id,uncc.ne_command_id,
        uncc.busi_cmd_code,uncc.busi_cmd_id,uncc.cmd_object,uncc.ne_id,uncc.busi_priority,
        uncc.cmd_order,uncc.org_id,uncc.command_content,uncc.extend_content,uncc.create_date,
        uncc.cmd_max_retry_count,uncc.deal_state,uncc.cmd_exec_date,uncc.cmd_state,
        uncc.cmd_status_info,uncc.cmd_retry_count,uncc.cmd_last_send_date,uncc.cmd_confirm_date,
        uncc.auth_object_no,uncc.prod_act_types,uncc.net_id,uncc.server_flag
        from ua.ua_ne_command_call uncc,ua.i_busi_command_call ibcc
        where uncc.busi_cmd_call_id = ibcc.busi_cmd_call_id
        and ibcc.busi_cmd_call_id = v_busicmdcallid;

        delete from ua.ua_ne_command_call uncc
        where uncc.busi_cmd_call_id = v_busicmdcallid;
      end if;

      --2、移业务指令
      insert into ua.ua_busi_command_call_over(
      busi_cmd_call_id,org_id,customer_order_id,product_order_id,
      product_inst_id,done_code,busi_command_code,is_reverse,
      command_content,hub_info,priority,deal_state,deal_desc,
      create_date,op_id,detach_date,finish_date,rel_cmd_call_id)
      select ibcc.busi_cmd_call_id,ibcc.org_id,ibcc.customer_order_id,ibcc.product_order_id,
      ibcc.product_inst_id,ibcc.done_code,ibcc.busi_command_code,ibcc.is_reverse,
      ibcc.command_content,ibcc.hub_info,ibcc.priority,ibcc.deal_state,ibcc.deal_desc,
      ibcc.create_date,ibcc.op_id,ibcc.detach_date,ibcc.finish_date,ibcc.rel_cmd_call_id
      from ua.i_busi_command_call ibcc
      where ibcc.busi_cmd_call_id = v_busicmdcallid;

      delete from ua.i_busi_command_call ibcc
      where ibcc.busi_cmd_call_id = v_busicmdcallid;
    end if;
  end if;
  exception
     when others then
        raise;
  end;
end proc_ua_move_cmd_call1;






/

