create PROCEDURE     queryProductInfo(offerId  in number,
                                                 flag     in number,
                                                 p_CURSOR out so1.QUERY_PRODUCT_PACKAGE.query_product_cursor) IS
BEGIN
  /* 有效产品*/
  IF flag = 1 THEN
    OPEN p_CURSOR FOR
      select *
        from (select a.product_item_id       offer_id,
                     a.relat_product_item_id service_pkg_id,
                     b.name                  service_pkg_name,
                     b.use_eff_date          serv_pkg_eff_date,
                     b.use_exp_date          serv_pkg_exp_date,
                     b.description           service_pkg_description
                from product.up_plan_prod_rel a,
                     product.up_product_item b,
                     product.up_service_price c,
                     (SELECT SRVC_ID,
                             LTRIM(MAX(SYS_CONNECT_BY_PATH(svc_id, ';'))
                                   KEEP(DENSE_RANK LAST ORDER BY curr),
                                   ';') AS svc_id
                        FROM (SELECT srvc_id,
                                     svc_id,
                                     ROW_NUMBER() OVER(PARTITION BY srvc_id ORDER BY svc_id) AS curr,
                                     ROW_NUMBER() OVER(PARTITION BY srvc_id ORDER BY svc_id) - 1 AS prev
                                FROM (select A.PRODUCT_ITEM_ID       SRVC_ID,
                                             A.RELAT_PRODUCT_ITEM_ID SVC_ID
                                        from product.up_item_relat a
                                       where a.Prod_Item_Relat_Kind_Id =
                                             'SERVICE_PRICE_INCLUDE_SERVICE'
                                         AND A.DEL_FLAG = '0'))
                       GROUP BY SRVC_ID
                      CONNECT BY prev = PRIOR curr
                             AND SRVC_ID = PRIOR SRVC_ID
                       START WITH curr = 1) d
               where a.product_item_id = offerId
                 and a.relat_product_item_id = b.product_item_id
                 and b.product_item_id = c.service_price_id
                 and sysdate between b.use_eff_date and b.use_exp_date
                 and d.srvc_id(+) = c.service_price_id
                 and a.del_flag = '0'
                 and b.state = '5'
                 and b.del_flag = '0'
                 and c.del_flag = '0'
               order by a.product_item_id, b.name, a.extend_attr_b asc)
       where OFFER_ID = offerId;
  END IF;

/* 无效产品*/
  IF flag = 0 THEN
    OPEN p_CURSOR FOR
      select *
        from (select a.product_item_id       offer_id,
                     a.relat_product_item_id service_pkg_id,
                     b.name                  service_pkg_name,
                     b.use_eff_date          serv_pkg_eff_date,
                     b.use_exp_date          serv_pkg_exp_date,
                     b.description           service_pkg_description
                from product.up_plan_prod_rel a,
                     product.up_product_item b,
                     product.up_service_price c,
                     (SELECT SRVC_ID,
                             LTRIM(MAX(SYS_CONNECT_BY_PATH(svc_id, ';'))
                                   KEEP(DENSE_RANK LAST ORDER BY curr),
                                   ';') AS svc_id
                        FROM (SELECT srvc_id,
                                     svc_id,
                                     ROW_NUMBER() OVER(PARTITION BY srvc_id ORDER BY svc_id) AS curr,
                                     ROW_NUMBER() OVER(PARTITION BY srvc_id ORDER BY svc_id) - 1 AS prev
                                FROM (select A.PRODUCT_ITEM_ID       SRVC_ID,
                                             A.RELAT_PRODUCT_ITEM_ID SVC_ID
                                        from product.up_item_relat a
                                       where a.Prod_Item_Relat_Kind_Id =
                                             'SERVICE_PRICE_INCLUDE_SERVICE'
                                         AND A.DEL_FLAG = '0'))
                       GROUP BY SRVC_ID
                      CONNECT BY prev = PRIOR curr
                             AND SRVC_ID = PRIOR SRVC_ID
                       START WITH curr = 1) d
               where a.product_item_id = offerId
                 and a.relat_product_item_id = b.product_item_id
                 and b.product_item_id = c.service_price_id
                 and d.srvc_id(+) = c.service_price_id
                 and a.relat_product_item_id not in
                     (select a2.relat_product_item_id
                        from product.up_plan_prod_rel a2,
                             product.up_product_item b2,
                             product.up_service_price c2,
                             (SELECT SRVC_ID,
                                     LTRIM(MAX(SYS_CONNECT_BY_PATH(svc_id, ';'))
                                           KEEP(DENSE_RANK LAST ORDER BY curr),
                                           ';') AS svc_id
                                FROM (SELECT srvc_id,
                                             svc_id,
                                             ROW_NUMBER() OVER(PARTITION BY srvc_id ORDER BY svc_id) AS curr,
                                             ROW_NUMBER() OVER(PARTITION BY srvc_id ORDER BY svc_id) - 1 AS prev
                                        FROM (select A2.PRODUCT_ITEM_ID       SRVC_ID,
                                                     A2.RELAT_PRODUCT_ITEM_ID SVC_ID
                                                from product.up_item_relat a2
                                               where a2.Prod_Item_Relat_Kind_Id =
                                                     'SERVICE_PRICE_INCLUDE_SERVICE'
                                                 AND A2.DEL_FLAG = '0'))
                               GROUP BY SRVC_ID
                              CONNECT BY prev = PRIOR curr
                                     AND SRVC_ID = PRIOR SRVC_ID
                               START WITH curr = 1) d2
                       where a2.product_item_id = offerId
                         and a2.relat_product_item_id = b2.product_item_id
                         and b2.product_item_id = c2.service_price_id
                         and d2.srvc_id(+) = c2.service_price_id
                         and sysdate between b2.use_eff_date and
                             b2.use_exp_date
                         and a2.del_flag = '0'
                         and b2.state = '5'
                         and b2.del_flag = '0'
                         and c2.del_flag = '0')
               order by a.product_item_id, b.name, a.extend_attr_b asc)
       where OFFER_ID = offerId;
  END IF;

end queryProductInfo;


/

