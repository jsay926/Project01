create PROCEDURE wuxi_dianbo IS
v_yesterday    varchar(8);
v1_sql VARCHAR2 (2000);
v2_sql VARCHAR2 (2000);
v3_sql VARCHAR2 (2000);
v4_sql VARCHAR2 (2000);

BEGIN
  select to_char(sysdate - 1, 'yyyymmdd') into v_yesterday from dual;

  v1_sql:='
  CREATE TABLE gj.tmp_dr_ismp_' || v_yesterday || ' AS
  SELECT tmp.acc_id,SUM(tmp.charge1)/10 fee from jf.dr_ismp_' || v_yesterday || '  tmp WHERE tmp.corp_org_id=3303
  GROUP BY tmp.acc_id';

  EXECUTE IMMEDIATE v1_sql;

  v2_sql:='
  insert into zg.acct_balance
  select zg.acct_balance$seq.nextval ACCT_BALANCE_ID,
       3                             BALANCE_TYPE_ID,
       tmp.acc_id                    ACCT_ID,
       date ''2011-11-11''           EFF_DATE,
       date ''2099-12-30''           EXP_DATE,
       0                           BALANCE,
       0                           RESERVE_BALANCE,
       0                           CYCLE_UPPER,
       0                           CYCLE_LOWER,
       0                           CYCLE_UPPER_TYPE,
       0                           CYCLE_LOWER_TYPE,
       1                           STATE,
       sysdate                     STATE_DATE,
       0                           SERV_ID,
       510                         REGION_CODE,
       3303                        CORP_ORG_ID
  FROM gj.tmp_dr_ismp_' || v_yesterday || ' tmp
 WHERE not exists (select 1
          from zg.acct_balance b
         where tmp.acc_id = b.acct_id
           and b.balance_type_id = 3)';


  EXECUTE IMMEDIATE v2_sql;

  COMMIT;
  v3_sql:='
  UPDATE ZG.ACCT_BALANCE B
     SET B.BALANCE = B.BALANCE + (SELECT TMP.FEE FROM GJ.TMP_DR_ISMP_' || v_yesterday || ' TMP WHERE TMP.ACC_ID = B.ACCT_ID)
   WHERE B.BALANCE_TYPE_ID = 3
     AND EXISTS (SELECT 1
            FROM GJ.TMP_DR_ISMP_' || v_yesterday || ' TMP
           WHERE TMP.ACC_ID = B.ACCT_ID)';

  EXECUTE IMMEDIATE v3_sql;
  COMMIT;

    --上发通知表
  v4_sql := 'insert into zg.acc_book_chg_notify
      select  b.so_nbr + rownum SO_NBR,
              tmp.acc_id        acct_id,
              0                 serv_id,
              SYSDATE           create_Date,
              0                 src_done_code,
              1                 change_flag,
              1                 sts,
              510               so_region_code,
              to_char(SYSDATE,''yyyymm'')  so_month,
              1                  priority,
              1                  change_type,
              4                  monit_source,
              1                  monit_type,
              103000             busi_code,
              0                  staff_id,
              ''                 UP_DATE,
              3303               corp_org_id

      from GJ.TMP_DR_ISMP_' || v_yesterday || ' TMP,
      (select max(so_nbr) so_nbr from zg.acc_book_chg_notify_his) b';

     execute immediate v3_sql;
     commit;

    exception
    when others then
    rollback;

  END;
/

