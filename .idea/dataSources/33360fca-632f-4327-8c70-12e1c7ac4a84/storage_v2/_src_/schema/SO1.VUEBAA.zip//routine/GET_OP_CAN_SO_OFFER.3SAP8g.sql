create PROCEDURE GET_op_can_so_offer
(
in_op_id  in number,
in_so_org_id  in number
) 
IS


CURSOR cur_offer IS
SELECT b.*
FROM product.up_offer  a, product.up_product_item b 
where b.state = '5'
and a.del_flag = '0'
and b.del_flag = '0'
and a.offer_id=b.product_item_id;


CURSOR cur_offer_maket(in_offer_id in number) IS
SELECT *
FROM product.up_item_market
where 
del_flag = '0'
and product_item_id=in_offer_id;


lr_product_item_id    product.up_product_item%rowtype;
lr_offer_maket        product.up_item_market%rowtype;


ln_count    number;
ln_count1    number;
ln_own_org_id         number;
ln_staff_level        number;
ln_OPER_HAVE_OWN_PRI  number;
ln_OPER_HAVE_on_PRI  number;
ln_op_own_org_id			number;
ln_op_on_org_id				number;
ln_pass               number;


ls_temp varchar2(1000);
ls_code_rules varchar2(3000);

begin
--创建操作员临时信息

dbms_output.enable(10000000000);

execute immediate 'truncate  table   qa.why_op_so_orgs';

qa.product_domain_change;

  select  b.organize_id into ln_own_org_id
  from sec.sec_operator a,sec.sec_staff b
  where a.staff_id=b.staff_id
  and  a.operator_id=in_op_id; 


--获取操作员归属组织的权限
ls_temp:='';
select   sys_connect_by_path(organize_id,',') into ls_temp
from sec.sec_organize
where organize_id=ln_own_org_id
start with org_role_type_id in (select code_value from base.cfg_static_data  where code_type='OWN_ORG_ORGTYPE')
connect by prior organize_id = parent_organize_id;


select substr(ls_temp,2) into ls_temp
from dual;

ln_op_own_org_id:='';
select  to_number(substr(ls_temp,1,instr(ls_temp,',')-1)) into ln_op_own_org_id
from dual;

if(ln_op_own_org_id=0) then
	goto error_step;
end if;

select  code_value into ln_OPER_HAVE_OWN_PRI
from base.cfg_static_data
 where code_type='OPER_HAVE_OWN_PRI'
 and state=1;


if(ln_OPER_HAVE_OWN_PRi=1) then
    if(ln_op_own_org_id<>-1) then
    	insert into qa.why_op_so_orgs values (in_op_id,ln_op_own_org_id,ln_op_own_org_id,in_so_org_id,0);    	
    	    	
    	 insert into qa.why_op_so_orgs 
    	 select   in_op_id,ln_op_own_org_id,organize_id,in_so_org_id,0
       from sec.sec_organize A
       where org_role_type_id in (select code_value from base.cfg_static_data  where code_type='OWN_ORG_ORGTYPE')
       start with   organize_id=ln_op_own_org_id  
       connect by prior organize_id = parent_organize_id;
      commit;  	
    end if;           
end if;
 


      
--获取操作员上岗组织的权限

ls_temp:='';
select   sys_connect_by_path(organize_id,',') into ls_temp
from sec.sec_organize
where organize_id=in_so_org_id
start with org_role_type_id in (select code_value from base.cfg_static_data  where code_type='OWN_ORG_ORGTYPE')
connect by prior organize_id = parent_organize_id;


select substr(ls_temp,2) into ls_temp
from dual;

ln_op_on_org_id:='';
select  to_number(substr(ls_temp,1,instr(ls_temp,',')-1)) into ln_op_on_org_id
from dual;

if(ln_op_on_org_id=0) then
	goto error_step;
end if;


select  code_value into ln_OPER_HAVE_ON_PRI
from base.cfg_static_data
 where code_type='OPER_HAVE_ON_PRI'
 and state=1;


if(ln_OPER_HAVE_ON_PRI=1) then
    if(ln_op_own_org_id<>-1) then
    	insert into qa.why_op_so_orgs values (in_op_id,ln_op_own_org_id,ln_op_on_org_id,in_so_org_id,0);    	
    	    	
    	 insert into qa.why_op_so_orgs 
    	 select   in_op_id,ln_op_own_org_id,organize_id,in_so_org_id,0
       from sec.sec_organize A
       where org_role_type_id in (select code_value from base.cfg_static_data  where code_type='OWN_ORG_ORGTYPE')
       start with   organize_id=ln_op_on_org_id  
       connect by prior organize_id = parent_organize_id;
      commit;  	
    end if;           
end if;

--获取在通过权限管理付给操作员可受理的组织权限

insert into qa.why_op_so_orgs 
select   in_op_id,ln_op_own_org_id, substr(substr(orgs,2),1,instr(substr(orgs,2),',')-1 ),in_so_org_id,0 from (
select   sys_connect_by_path(organize_id,',')  orgs
from sec.sec_organize
where organize_id  IN (
              select   z.org_id
              from sec.sec_role_grant W,SEC.ORG_ENTITY_REL z
              where ent_type = 'D' 
              and state = 1  
              and w.ent_id=z.entity_id
              and priv_id = 122 
                  and role_id in 
                  (
                    select role_id 
                    from sec.sec_author a, sec.sec_op_station b 
                    where a.op_station_id = b.op_station_id 
                    and b.operator_id = 201 
                      and b.station_id = 0  
                      and a.state=1 and b.state=1   
                      and a.author_type in ('A','C') 
                      and a.author_valid_date < sysdate 
                      and a.author_expire_date > sysdate 
                      union  
                      SELECT distinct relat_role_id 
                      FROM sec.SEC_ROLE_ROLE_RELAT  
                      where role_relat_type = 2 
                      and state=1  
                      AND ROLE_ID in 
                      (
                        select b.role_id  
                        from sec.sec_op_station a, sec.sec_author b  
                        where a.op_station_id = b.op_station_id 
                        and b.author_type in ('A','C')  
                        and a.station_id = 0 
                        and b.author_valid_date < sysdate 
                        and b.author_expire_date > sysdate 
                        and a.state =1 and b.state =1 
                        and a.operator_id = 201 
                      )
                    )
)
start with org_role_type_id in (select code_value from base.cfg_static_data  where code_type='OWN_ORG_ORGTYPE')
connect by prior organize_id = parent_organize_id
);
commit;



  OPEN cur_offer;
  LOOP
  fetch cur_offer into  lr_product_item_id;
  exit when cur_offer%notfound;
      
       IF (lr_product_item_id.product_item_id=211000209533) THEN 
          NULL;
       END IF;
  
  
      if(nvl(lr_product_item_id.ent_id,0)<>0) then                
              ln_count:=0;
              select count(*) into ln_count  
              from sec.sec_role_grant 
              where ent_type = 'D' 
              and state = 1 
              and ent_id = lr_product_item_id.ent_id 
                and priv_id = 121 
                  and role_id in 
                  (
                    select role_id 
                    from sec.sec_author a, sec.sec_op_station b 
                    where a.op_station_id = b.op_station_id 
                    and b.operator_id = in_op_id 
                      and b.station_id = 0  
                      and a.state=1 and b.state=1   
                      and a.author_type in ('A','C') 
                      and a.author_valid_date < sysdate 
                      and a.author_expire_date > sysdate 
                      union  
                      SELECT distinct relat_role_id 
                      FROM sec.SEC_ROLE_ROLE_RELAT  
                      where role_relat_type = 2 
                      and state=1  
                      AND ROLE_ID in 
                      (
                        select b.role_id  
                        from sec.sec_op_station a, sec.sec_author b  
                        where a.op_station_id = b.op_station_id 
                        and b.author_type in ('A','C')  
                        and a.station_id = 0 
                        and b.author_valid_date < sysdate 
                        and b.author_expire_date > sysdate 
                        and a.state =1 and b.state =1 
                        and a.operator_id = in_op_id 
                      )
                    );
        
                if(ln_count<=0) then
                  goto end_loop;
                end if; 
      end if;
           
      OPEN cur_offer_maket(lr_product_item_id.product_item_id);
      LOOP
      fetch cur_offer_maket into  lr_offer_maket;
      exit when cur_offer_maket%notfound;  
        ln_pass:=-1;  
      
        IF (lr_offer_maket.Org_Id<=0) THEN
            ln_pass:=1;
            goto go_pass;
        end if;
      
        ln_own_org_id:=0;
        select  b.organize_id into ln_own_org_id
         from sec.sec_operator a,sec.sec_staff b
         where a.staff_id=b.staff_id
         and  a.operator_id=in_op_id; 
         
         ln_own_org_id:=0;
        select  b.organize_id into ln_own_org_id
         from sec.sec_operator a,sec.sec_staff b
         where a.staff_id=b.staff_id
         and  a.operator_id=in_op_id; 
         
         if(ln_own_org_id=lr_offer_maket.org_id or in_so_org_id=lr_offer_maket.org_id ) then
             ln_pass:=1;
             goto go_pass;
         end if;
         
         ln_count:=0;
        select   instr( sys_connect_by_path(organize_id,','),','||lr_offer_maket.org_id) into ln_count
        from sec.sec_organize
        where organize_id=in_so_org_id
        start with parent_organize_id=-1
        connect by prior organize_id = parent_organize_id;
        
        if(ln_count>0 ) then
             ln_pass:=1;
             goto go_pass;
         end if;
           
         ln_count:=0;
        select   instr( sys_connect_by_path(organize_id,','),','||lr_offer_maket.org_id) into ln_count
        from sec.sec_organize
        where organize_id=ln_own_org_id
        start with parent_organize_id=-1
        connect by prior organize_id = parent_organize_id;
        
        if(ln_count>0 ) then
             ln_pass:=1;
             goto go_pass;
         end if;
           
         --判断组织类型
        
                
         ln_count:=0;
        select   instr( sys_connect_by_path(org_role_type_id,','),','||lr_offer_maket.channel_type) into ln_count
        from sec.sec_organize
        where organize_id=in_so_org_id
        start with parent_organize_id=-1
        connect by prior organize_id = parent_organize_id;
        
        if(ln_count>0 ) then
             ln_pass:=1;
             goto go_pass;
         end if;
           
         ln_count:=0;
        select   instr( sys_connect_by_path(org_role_type_id,','),','||lr_offer_maket.channel_type) into ln_count
        from sec.sec_organize
        where organize_id=ln_own_org_id
        start with parent_organize_id=-1
        connect by prior organize_id = parent_organize_id;
        
        if(ln_count>0 ) then
             ln_pass:=1;
             goto go_pass;
         end if;
         <<go_pass>>
         
         if (ln_pass<=0) then
            close cur_offer_maket;
            goto end_loop;
         end if;
         
         select  nvl(b.staff_level,0) into ln_staff_level
         from sec.sec_operator a,sec.sec_staff b
         where a.staff_id=b.staff_id
         and  a.operator_id=in_op_id; 
         
         if (ln_staff_level>lr_offer_maket.oper_level) then
              close cur_offer_maket;
              goto end_loop;   
         end if;
                          
           
         ln_count:=0;
         select count(*) into ln_count 
         from qa.product_domaIn
         where  product_item_id=lr_product_item_id.product_item_id
         and OWN_ORG_ID in (
         select so_org_id from qa.why_op_so_orgs 
         where op_id = in_op_id
         );                            
               
          if (ln_count>0) then
                ln_count1:=0;
                select   count(*) into ln_count1
                from PRODUCT.UP_PLAN_PROD_REL  a, product.up_item_relat  b,product.up_product_item c
                where  A.RELAT_PRODUCT_ITEM_ID=B.PRODUCT_ITEM_ID
                 and  a.product_item_id=lr_product_item_id.product_item_id
                 and B.RELAT_PRODUCT_ITEM_ID=c.product_item_id
                 and b.prod_item_relat_kind_id='SERVICE_PRICE_GENERAL_PRICE_PLAN_KIND'
                 order by B.RELAT_PRODUCT_ITEM_ID;
         
                 if (ln_count1 >0 ) then
                    select  so1.zh_concat( chr(9) ||chr(9) || RELAT_PRODUCT_ITEM_ID||'--'||code_rule_name||chr(10))  into ls_code_rules
                    from (
                        select distinct B.RELAT_PRODUCT_ITEM_ID  RELAT_PRODUCT_ITEM_ID,c.name code_rule_name
                            from PRODUCT.UP_PLAN_PROD_REL  a, product.up_item_relat  b,product.up_product_item c
                            where  A.RELAT_PRODUCT_ITEM_ID=B.PRODUCT_ITEM_ID
                            and  a.product_item_id=lr_product_item_id.product_item_id
                            and B.RELAT_PRODUCT_ITEM_ID=c.product_item_id
                            and b.prod_item_relat_kind_id='SERVICE_PRICE_GENERAL_PRICE_PLAN_KIND'
                            order by B.RELAT_PRODUCT_ITEM_ID
                    ); 
                    
                    DBMS_OUTPUT.put_line(lr_product_item_id.product_item_id||'--'||lr_product_item_id.item_type);
                    DBMS_OUTPUT.put_line(ls_code_rules); 
                    close cur_offer_maket;
                    goto end_loop;                                  
                end if;                  
         end if; 
                                        
      end LOOP;
      close cur_offer_maket;
   <<end_loop>>
   commit;
  end loop;
  close cur_offer;
  <<error_step>>
   DBMS_OUTPUT.put_line('执行完成！！！');
end;




/

