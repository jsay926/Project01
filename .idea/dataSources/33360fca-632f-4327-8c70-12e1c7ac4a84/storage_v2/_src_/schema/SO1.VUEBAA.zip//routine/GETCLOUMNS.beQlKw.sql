create FUNCTION       "GETCLOUMNS" (index_owner1 in varchar2,
                                      index_name1  in varchar2,
                                      column_nums1 in number)
  return varchar2 is
  all_columns varchar2(512);
  total_num   number;
  i           number;
  cursor c1 is
    select column_name
      from dba_ind_columns
     where index_owner = index_owner1
       and index_name = index_name1
     order by column_position;
  dummy c1%rowtype;
begin
  total_num := column_nums1;
  open c1;
  fetch c1
    into dummy;
  i := 0;
  while c1%found loop
    i := i + 1;
    if (i = total_num) then
      all_columns := all_columns || dummy.column_name;
    else
      all_columns := all_columns || dummy.column_name || ',';
    end if;
    fetch c1
      into dummy;
  end loop;
  close c1;
  return all_columns;
exception
  when no_data_found then
    return all_columns;
end;





/

