create PROCEDURE "CHG_SERV_STS" (v_serv_id In Number,v_serv_status In Number)
      Is
       v_count Number;
       v_count1 Number(2);
       v_count2 Number(2);
       v_result Varchar2(50);
       v_so_id Number;
       v_begin_date Date;
       v_region_code Number;
       v_expire_date Date;
       Type t_service_rec Is Record(
            service_id Number,
            Expire_date Date
       );
       Type t_service_exp Is Table Of t_service_rec Index By Binary_Integer;
       v_service_exp t_service_exp;
Begin
----------??????????????
      Select Count(1) Into v_count From zg.serv@zg serv
      Where serv_id=v_serv_id;
      If v_count !=0 Then
       v_result:='??ID: '||v_serv_id||'????';
        Update zg.i_user_status@zg t Set t.user_sts=v_serv_status
        Where t.serv_id=v_serv_id;
        Select count(1) Into v_count1 From zg.i_user_prod_sts@zg t
        Where t.serv_id=v_serv_id;
        If v_count1>=1 Then
---------????????????????????expire_date???????????????1
           Select t.service_id,max(t.expire_date) Bulk Collect Into v_service_exp From zg.i_user_prod_sts@zg t
           Where t.serv_id=v_serv_id
           Group By t.service_id;
            For i In v_service_exp.First ..v_service_exp.Last Loop
                Select t.so_id,t.begin_date,t.region_code Into v_so_id,v_begin_date,v_region_code From zg.i_user_prod_sts@zg t
                Where t.serv_id=v_serv_id And v_service_exp(i).Expire_date=t.expire_date
                And  t.service_id=v_service_exp(i).service_id And Rownum<=1;
                Select Sysdate Into v_expire_date From dual;
                Update zg.i_user_prod_sts@zg t Set t.expire_date=v_expire_date
                Where t.serv_id=v_serv_id And v_service_exp(i).Expire_date=t.expire_date
                And  t.service_id=v_service_exp(i).service_id;
                Commit;
                Insert Into zg.i_user_prod_sts@zg(so_id,serv_id,region_code,service_id,prod_sts
                ,begin_date,valid_date,expire_date,so_nbr,done_code,remark)
                Select v_so_id,v_serv_id,v_region_code,v_service_exp(i).service_id,v_serv_status,v_begin_date,v_expire_date,date'2099-12-31',0,0,'??????'
                From dual;
                Commit;
            End Loop;
        End If;
        Select count(1) Into v_count1 From zg.serv@zg t
        Where t.serv_id=v_serv_id;
        If v_count2>=1 Then
           Update zg.serv@zg t Set t.state='2HA'
           Where t.serv_id =v_serv_id;
        End If;

    Insert Into zg.i_sale_oper@zg
    Select v_serv_id,0,0,0,'11111111111111111111111111111111',25,Sysdate,Sysdate,0,0,0,1 From dual;
     v_result:=v_result||'??';
  Else
     v_result:=v_result||'??(2)';
  End If;
  Insert Into so1.pro_log Values(so1.pro_log_seq.nextval,v_result,Sysdate);
Exception
          When Others Then
                v_result :=v_result||'??(3)';
          Insert Into so1.pro_log Values(so1.pro_log_seq.nextval,v_result,Sysdate);
End;






/

