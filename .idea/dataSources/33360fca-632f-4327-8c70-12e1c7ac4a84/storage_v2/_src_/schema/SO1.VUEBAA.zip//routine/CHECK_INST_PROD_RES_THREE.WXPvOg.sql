create procedure CHECK_INST_PROD_RES_THREE(res_equ_no in varchar2, p_rtn_code out number) as

v_res_equ_no varchar2(60);
sqlstr1 varchar2(2000);

begin

  p_rtn_code := 0;
  v_res_equ_no := res_equ_no;

  sqlstr1:='select count(*) from (select distinct sp.prod_inst_id,sp.state
            from (select f.res_equ_no2,f.cust_id from  so1.ins_prod_res f union select  c.res_equ_no2,d.cust_id from  so1.ord_prod_res c,so1.ord_cust d where c.cust_order_id=d.cust_order_id ) t
            left join (select a.cust_id,a.res_equ_no2,a.res_code,a.prod_inst_id,a.res_type from so1.ins_prod_res a union select op.cust_id,b.res_equ_no2 ,b.res_code,op.prod_inst_id,b.res_type from so1.ord_prod_res b,so1.ord_prod op where op.cust_order_id=b.cust_order_id and op.prod_order_id=b.prod_order_id) t2 on t2.cust_id = t.cust_id and t2.res_equ_no2 = t.res_equ_no2
            left join res.res_code_definition de on de.res_sub_type = t2.res_type and t2.res_code = de.res_code
            left join (select sp1.prod_inst_id,sp1.prod_service_id,sp1.state from  so1.ins_srvpkg sp1 union select ff.prod_inst_id,dd.prod_service_id,dd.state from so1.ord_srvpkg dd,so1.ord_prod ff where dd.cust_order_id=ff.cust_order_id and dd.prod_order_id=ff.prod_order_id) sp on sp.prod_inst_id=t2.prod_inst_id and sp.prod_service_id=1003
            where t.res_equ_no2 = '''||v_res_equ_no||'''
            and de.res_type=2)';

  dbms_output.put_line(sqlstr1);
  execute immediate sqlstr1
  into p_rtn_code;
end CHECK_INST_PROD_RES_THREE;


/

