create function FUN_INS_PROD_ROLL (v_srvpkg_id in number,v_serv_id in number )--用户不小心取消某产品
/*2013.7.12 by dr*/
    RETURN varchar2 is
    v_relat_item_id  number(14);
    v_extend_id      number(14);
    v_count          number(14);
    v_expdate        date;
    v_year           varchar2(4);
    v_srvpkg_inst_id number(14);
    v_offer_inst_id  number(14);
    v_so_id          number(20);
    v_sql            varchar2(1500);
    v_error          varchar2(500);
begin
  ----回退产品订购
  v_expdate := date'2033-2-1';
  v_year := to_char(sysdate,'yyyy');--得到年份
  v_sql :='insert into so1.ins_srvpkg(SRVPKG_INST_ID,OFFER_INST_ID,SRVPKG_ID,PROD_INST_ID,
  VALID_TYPE,OPER_STATE,STATE,REGION_ID,CREATE_DATE,DONE_CODE,DONE_DATE,VALID_DATE,
  EXPIRE_DATE,OP_ID,ORG_ID,SRC_SYSTEM_ID,SRC_SYSTEM_EXT_CODE,PROD_SERVICE_ID,OS_STATUS,
  CUST_ORDER_ID)
  select SRVPKG_INST_ID,OFFER_INST_ID,SRVPKG_ID,PROD_INST_ID,
  VALID_TYPE,OPER_STATE,STATE,REGION_ID,CREATE_DATE,DONE_CODE,DONE_DATE,VALID_DATE,
  EXPIRE_DATE,OP_ID,ORG_ID,SRC_SYSTEM_ID,SRC_SYSTEM_EXT_CODE,PROD_SERVICE_ID,OS_STATUS,
  CUST_ORDER_ID from  so1.h_ins_srvpkg_'||v_year||'
  where h_id=(select max(h_id) from so1.h_ins_srvpkg_'||v_year||'
  where srvpkg_id = '||v_srvpkg_id||' and prod_inst_id = '||v_serv_id||')';
  execute immediate v_sql;
  v_count := sql%rowcount;
  if v_count <> 1 then
    return 'ins_srvpkg历史表资料错';
  end if;

  select min(srvpkg_inst_id),min(offer_inst_id) into v_srvpkg_inst_id,v_offer_inst_id
  from so1.ins_srvpkg t where srvpkg_id = v_srvpkg_id and prod_inst_id = v_serv_id ;

  --产品与服务的关系
  v_sql :='insert into so1.ins_srvpkg_ins_srv_rel(SRVPKG_SRV_INST_ID,SRVPKG_INST_ID,INS_VALID_DATE,
  INS_EXPIRE_DATE,SRV_INST_ID,OFFER_INST_ID,PROD_INST_ID,VALID_TYPE,OPER_STATE,STATE,DONE_CODE,
  CREATE_DATE,DONE_DATE,VALID_DATE,EXPIRE_DATE,OP_ID,ORG_ID,REGION_ID,CUST_ORDER_ID)
  select SRVPKG_SRV_INST_ID,SRVPKG_INST_ID,INS_VALID_DATE,
  INS_EXPIRE_DATE,SRV_INST_ID,OFFER_INST_ID,PROD_INST_ID,VALID_TYPE,OPER_STATE,STATE,DONE_CODE,
  CREATE_DATE,DONE_DATE,VALID_DATE,EXPIRE_DATE,OP_ID,ORG_ID,REGION_ID,CUST_ORDER_ID
   from so1.h_ins_srvpkg_ins_srv_rel_'||v_year||'
   where h_id=(select max(h_id) from so1.h_ins_srvpkg_ins_srv_rel_'||v_year||' a
  where a.srvpkg_inst_id = '||v_srvpkg_inst_id||')';
  execute immediate v_sql;
  v_count := sql%rowcount;
  if v_count <> 1 then
    return 'ins_srvpkg_ins_srv_rel历史表资料错';
  end if;
  ---更新服务
  select relat_product_item_id into v_relat_item_id
  from product.up_item_relat t where t.product_item_id=v_srvpkg_id and
  prod_item_relat_kind_id='SERVICE_PRICE_INCLUDE_SERVICE';

  v_sql :='insert into so1.ins_srv t(SRV_INST_ID,PROD_INST_ID,SERVICE_ID,OPER_COUNT,VALID_TYPE,
  OPER_STATE,STATE,REGION_ID,DONE_CODE,CREATE_DATE,DONE_DATE,VALID_DATE,EXPIRE_DATE,OP_ID,
  ORG_ID,EXT1,EXT2,EXT3,EXT4,EXT5,EXT6,SRC_SYSTEM_ID,SRC_SYSTEM_EXT_CODE,CUST_ORDER_ID,CAP_VALUE)
  select SRV_INST_ID,PROD_INST_ID,SERVICE_ID,OPER_COUNT,VALID_TYPE,
  OPER_STATE,STATE,REGION_ID,DONE_CODE,CREATE_DATE,DONE_DATE,VALID_DATE,EXPIRE_DATE,OP_ID,
  ORG_ID,EXT1,EXT2,EXT3,EXT4,EXT5,EXT6,SRC_SYSTEM_ID,SRC_SYSTEM_EXT_CODE,CUST_ORDER_ID,CAP_VALUE
  from so1.h_ins_srv_'||v_year||' t
  where prod_inst_id='||v_serv_id||' and service_id='||v_relat_item_id||' and rownum=1';
  execute immediate v_sql;
  v_count := sql%rowcount;
  if v_count <> 1 then
    return 'ins_srv历史表资料错';
  end if;

  --查看套餐是否存在，不存在回退套餐
  select count(*) into v_count from so1.ins_offer where offer_inst_id = v_offer_inst_id;
  if v_count=0 then
    v_sql :='insert into so1.ins_offer(OFFER_INST_ID,OFFER_ID,OFFER_TYPE,MAIN_ROLE_PROD_ID,
    CUST_ID,ORDER_NAME,CONTRACT_ID,VALID_TYPE,OPER_STATE,STATE,CANCEL_REASON,VALID_DATE,
    EXPIRE_DATE,REGION_ID,CREATE_DATE,CREATE_ORG_ID,CREATE_OP_ID,OWN_ORG_ID,SALE_TYPE,
    SALE_OP_ID,SALE_ORG_ID,OWN_CORP_ORG_ID,DONE_CODE,DONE_DATE,OP_ID,ORG_ID,SRC_SYSTEM_ID,
    SRC_SYSTEM_EXT_CODE,EXT1,EXT2,EXT3,EXT4,CUST_ORDER_ID,CUST_ADDR_ID,EXPIRE_FOLLOW_STATE,
    OS_STATUS,PROD_SERVICE_ID)
    select OFFER_INST_ID,OFFER_ID,OFFER_TYPE,MAIN_ROLE_PROD_ID,
    CUST_ID,ORDER_NAME,CONTRACT_ID,VALID_TYPE,OPER_STATE,STATE,CANCEL_REASON,VALID_DATE,
    EXPIRE_DATE,REGION_ID,CREATE_DATE,CREATE_ORG_ID,CREATE_OP_ID,OWN_ORG_ID,SALE_TYPE,
    SALE_OP_ID,SALE_ORG_ID,OWN_CORP_ORG_ID,DONE_CODE,DONE_DATE,OP_ID,ORG_ID,SRC_SYSTEM_ID,
    SRC_SYSTEM_EXT_CODE,EXT1,EXT2,EXT3,EXT4,CUST_ORDER_ID,CUST_ADDR_ID,EXPIRE_FOLLOW_STATE,
    OS_STATUS,PROD_SERVICE_ID from so1.h_ins_offer_'||v_year||'
    where offer_inst_id = '||v_offer_inst_id ||' and rownum=1' ;
    execute immediate v_sql;
    update so1.ins_offer set expire_date=v_expdate where offer_inst_id = v_offer_inst_id ;
    --套餐与产品的关联
    v_sql :='insert into so1.ins_off_ins_prod_rel
    select OFFER_INST_PROD_INST_ID,OFFER_INST_ID,PROD_INST_ID,
    PROD_SPEC_ID,OFFER_ID,PROD_INST_ROLE_ID,IS_MAIN_OFFER,CUST_ID,
    VALID_TYPE,STATE,OPER_STATE,REGION_ID,GROUP_REGION_ID,USER_REGION_ID,
    DONE_CODE,CREATE_DATE,DONE_DATE,VALID_DATE,EXPIRE_DATE,OP_ID,
    ORG_ID,EXT1,EXT2,EXT3,EXT4,CUST_ORDER_ID
    from so1.h_ins_off_ins_prod_rel_'||v_year||' where offer_inst_id='||v_offer_inst_id ||' and rownum=1' ;
    execute immediate v_sql;
    update so1.ins_off_ins_prod_rel set expire_date=v_expdate where offer_inst_id = v_offer_inst_id ;
  end if;

  ---更新账务侧数据
  select b.extend_id into v_extend_id
  from product.up_item_relat t,product.up_product_item b
  where t.product_item_id=v_srvpkg_id
  and t.relat_product_item_id = b.product_item_id
  and prod_item_relat_kind_id='SERVICE_PRICE_GENERAL_PRICE_PLAN_PKG_BOSS';

  select max(so_id) into v_so_id from zg.i_user_msc b
  where b.serv_id= v_serv_id and b.prod_id=v_extend_id
  and expire_date between sysdate - 15 and sysdate;/*只处理10天内退订的*/
  /*select so_id into v_so_id from so1.ins_srvpkg_so_id_rel t
  where ins_prod_id = v_extend_id and ins_srvpkg_id = v_srvpkg_inst_id;*/

  insert into  so1.ins_srvpkg_so_id_rel(INS_OFF_ID,INS_SRVPKG_ID,INS_PROD_ID,PROD_ID,SO_ID)values
  (v_offer_inst_id,v_srvpkg_inst_id,v_serv_id,v_extend_id,v_so_id);

  update so1.ins_srvpkg set expire_date=v_expdate where srvpkg_inst_id=v_srvpkg_inst_id;
  update so1.ins_srvpkg_ins_srv_rel set expire_date=v_expdate where srvpkg_inst_id=v_srvpkg_inst_id;
  update so1.ins_srv set expire_date=v_expdate where prod_inst_id=v_serv_id and service_id=v_relat_item_id;

  --上发
  insert into zg.i_sale_oper
  select v_serv_id,0,0,0,'11111111111111111111111111111111',512,sysdate,null,0 ,null,0 ,1
  from dual t ;
  insert into so1.DR_PROD_ROLL_LOG(pro_name,ERROR_NOTE,serv_id,errordate)values
  ('FUN_INS_PROD_ROLL','srvpkg_id'||v_srvpkg_inst_id,v_serv_id,sysdate);
    commit;
  return '处理成功';
exception
    when others then
    rollback;

    v_error := SUBSTR(SQLERRM, 1, 500);
    return v_error;
end FUN_INS_PROD_ROLL;





/

