create PROCEDURE     p_ei_trans2his (in_einvoice_id IN NUMBER )
AS
  v_yyyymm varchar(6) ;
BEGIN
--   created by ly 20180212

   SELECT to_char(SYSDATE,'yyyymm') INTO v_yyyymm FROM dual ;

   --einvoice
   EXECUTE IMMEDIATE 'INSERT INTO so1.einvoice_'||v_yyyymm||' SELECT t.* FROM so1.einvoice t WHERE einvoice_id='||in_einvoice_id ;
   EXECUTE IMMEDIATE 'DELETE FROM so1.einvoice WHERE einvoice_id='||in_einvoice_id ;
   --einvoice_detail
   EXECUTE IMMEDIATE 'INSERT INTO so1.einvoice_detail_'||v_yyyymm||' SELECT t.* FROM so1.einvoice_detail t WHERE einvoice_id='||in_einvoice_id ;
   EXECUTE IMMEDIATE 'DELETE FROM so1.einvoice_detail WHERE einvoice_id='||in_einvoice_id ;
   --einvoice_split_detail
   EXECUTE IMMEDIATE 'INSERT INTO so1.einvoice_split_detail_'||v_yyyymm||' SELECT t.* FROM so1.einvoice_split_detail t WHERE einvoice_id='||in_einvoice_id ;
   EXECUTE IMMEDIATE 'DELETE FROM so1.einvoice_split_detail WHERE einvoice_id='||in_einvoice_id ;
   --einvoice_result
   EXECUTE IMMEDIATE 'INSERT INTO so1.einvoice_result_'||v_yyyymm||' SELECT t.* FROM so1.einvoice_result t WHERE einvoice_id='||in_einvoice_id ;
   EXECUTE IMMEDIATE 'DELETE FROM so1.einvoice_result WHERE einvoice_id='||in_einvoice_id ;
   --einvoice_log
   EXECUTE IMMEDIATE 'INSERT INTO so1.einvoice_log_'||v_yyyymm||' SELECT t.* FROM so1.einvoice_log t WHERE einvoice_id='||in_einvoice_id ;
   EXECUTE IMMEDIATE 'DELETE FROM so1.einvoice_log WHERE einvoice_id='||in_einvoice_id ;


DELETE FROM so1.vm_schedule t WHERE t.workflow_id IN (SELECT task_id FROM so1.vm_work_flow WHERE queue_id='QH_EINVOICE' AND vars LIKE '%'||in_einvoice_id||'%');

INSERT INTO so1.his_vm_task
SELECT * FROM so1.vm_task t WHERE t.workflow_id IN (SELECT task_id FROM so1.vm_work_flow WHERE queue_id='QH_EINVOICE' AND vars LIKE '%'||in_einvoice_id||'%');

DELETE FROM so1.vm_task t WHERE t.workflow_id IN (SELECT task_id FROM so1.vm_work_flow WHERE queue_id='QH_EINVOICE' AND vars LIKE '%'||in_einvoice_id||'%');

INSERT INTO so1.his_vm_work_flow
SELECT * FROM so1.vm_work_flow t WHERE queue_id='QH_EINVOICE' AND t.vars LIKE '%'||in_einvoice_id||'%' ;

DELETE FROM so1.vm_work_flow t WHERE queue_id='QH_EINVOICE' AND t.vars LIKE '%'||in_einvoice_id||'%' ;


COMMIT ;

END p_ei_trans2his ;
/

