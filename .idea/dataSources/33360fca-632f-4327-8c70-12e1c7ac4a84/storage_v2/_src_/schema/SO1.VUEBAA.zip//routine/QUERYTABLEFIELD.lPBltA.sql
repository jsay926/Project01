create PROCEDURE     queryTableField( tableName  in varchar2,  ower  in varchar2,p_CURSOR out so1.QUERY_TABLE_FIELD_PACKAGE.query_table_field_cursor) IS
BEGIN
  OPEN p_CURSOR FOR
    select t.column_name, c.DATA_TYPE, t.comments
   from  ALL_COL_COMMENTS t ,  ALL_TAB_COLUMNS c
  where c.column_name = t.column_name
    and c.TABLE_NAME = upper (tableName)
    and c.TABLE_NAME = t.TABLE_NAME
    and c.OWNER=upper(ower)
    and t.OWNER=upper(ower);
end queryTableField;


/

