create procedure     BAND_PASSWORD_CHANG_SO1(p_login_name in varchar2,
  p_password in varchar2,p_org_code in varchar2,
  p_return_code out number ,p_return_message out varchar2)
as

  l_url       VARCHAR2(32767);
  l_return_code number(4);
  l_return_message varchar2(256);

BEGIN
  IPCC.BAND_PASSWORD_CHANG(p_login_name,p_password,p_org_code,p_return_code,p_return_message);

end;




/

