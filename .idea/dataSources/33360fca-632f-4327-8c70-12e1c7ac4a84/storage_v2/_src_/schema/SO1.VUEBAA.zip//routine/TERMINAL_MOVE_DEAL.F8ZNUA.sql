create procedure terminal_move_deal
as
begin
update so1.vm_schedule vs
   set vs.state = 'W'
 where vs.workflow_id in
       (select vm.task_id
          from so1.vm_work_flow vm
         where vm.workflow_object_id in
               (select t.order_id
                  from pboss.sf_order t
                 where t.so_serial_code in
                       (select distinct p.cust_order_id
                          from so1.ord_busi p
                         where p.business_id = 800001000036))) and vs.state='F';
                         commit;
                         end;




/

