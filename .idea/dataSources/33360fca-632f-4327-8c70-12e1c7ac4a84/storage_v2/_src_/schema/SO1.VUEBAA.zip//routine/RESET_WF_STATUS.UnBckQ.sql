create procedure reset_wf_status(v_cust_ord_id in number)
as
v_like varchar2(20);
begin
  
  v_like := '%'||v_cust_ord_id||'%';
  --state修改为2
  update so1.vm_work_flow wf set wf.state=2 where wf.vars like v_like
         and wf.state='99';

  update so1.vm_schedule vs set vs.state='W' where vs.workflow_id in (
  select wf.task_id from so1.vm_work_flow wf where wf.vars like v_like
  ) and vs.state='F';
  commit;
end;




/

