create PROCEDURE p_rape_order_all
is
in_order_id  number(16);
BEGIN
  --dbms_output.put_line('需要处理的订单编号为:'||in_order_id);
for v_order in (select cust_order_id from so1.ord_cust where cust_id=127004697 ) loop
  in_order_id := v_order.cust_order_id;
  -----订单移入历史
  insert into so1.ord_address_f_2015 select * from so1.ord_address t where t.cust_order_id = in_order_id;
  insert into so1.ord_cust_f_2015 select * from so1.ord_cust t where t.cust_order_id = in_order_id;
  insert into so1.ord_custinfo_f_2015 select * from so1.ord_custinfo t where t.cust_order_id = in_order_id;
  insert into so1.ord_busi_f_2015 select * from so1.ord_busi t where t.cust_order_id = in_order_id;
  insert into so1.ord_offer_f_2015 select * from so1.ord_offer t where t.cust_order_id = in_order_id;
  insert into so1.ord_price_f_2015 select * from so1.ord_price t where t.cust_order_id = in_order_id;
  insert into so1.ord_prod_f_2015 select * from so1.ord_prod t where t.cust_order_id = in_order_id;
  insert into so1.ord_srvpkg_f_2015 select * from so1.ord_srvpkg t where t.cust_order_id = in_order_id;
  insert into so1.ord_srv_f_2015 select * from so1.ord_srv t where t.cust_order_id = in_order_id;
  insert into so1.ord_srvpkg_ord_srv_f_2015 select * from so1.ord_srvpkg_ord_srv t where t.cust_order_id = in_order_id;
  insert into so1.ord_srv_attr_f_2015 select * from so1.ord_srv_attr t where t.cust_order_id = in_order_id;
  insert into so1.ord_prod_res_f_2015 SELECT * from   so1.ord_prod_res t where t.cust_order_id = in_order_id;

     dbms_output.put_line('订单编号为:'||in_order_id||'已经被移入历史!');

  ---------------删除订单

  delete from so1.ord_address t where t.cust_order_id = in_order_id;
  delete from so1.ord_cust t where t.cust_order_id = in_order_id;
  DELETE from so1.ord_custinfo t where t.cust_order_id = in_order_id;
  delete from so1.ord_busi t where t.cust_order_id = in_order_id;
  delete from so1.ord_offer t where t.cust_order_id = in_order_id;
  delete from so1.ord_price t where t.cust_order_id = in_order_id;
  delete from so1.ord_prod t where t.cust_order_id = in_order_id;
  delete from so1.ord_srvpkg t where t.cust_order_id = in_order_id;
  delete from so1.ord_srv t where t.cust_order_id = in_order_id;
  delete from so1.ord_srvpkg_ord_srv t where t.cust_order_id = in_order_id;
  delete from so1.ord_prod_res t where t.cust_order_id = in_order_id;
  delete from so1.ord_srv_attr t where t.cust_order_id = in_order_id;

     dbms_output.put_line('订单编号为:'||in_order_id||'已经被删除!');

  --------工作流挪历史


  insert into so1.his_vm_work_flow
  select * from so1.vm_work_flow t WHERE t.vars LIKE '%'||in_order_id||'%';

  insert into so1.his_vm_task
  select * from so1.vm_task
  where workflow_id in (select task_id FROM so1.vm_work_flow t WHERE t.vars LIKE '%'||in_order_id||'%');

  delete FROM so1.vm_task
  where workflow_id  IN (select task_id FROM so1.vm_work_flow t WHERE t.vars LIKE '%'||in_order_id||'%');

  delete FROM so1.vm_work_flow t WHERE t.vars LIKE '%'||in_order_id||'%';

   dbms_output.put_line('订单编号为:'||in_order_id||'工作流数据处理完毕 !');
  commit;
end loop;
end;





/

