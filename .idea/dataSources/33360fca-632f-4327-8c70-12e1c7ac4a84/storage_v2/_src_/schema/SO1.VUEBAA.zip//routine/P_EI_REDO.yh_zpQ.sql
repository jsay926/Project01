create PROCEDURE     p_ei_redo (in_einvoice_id NUMBER) AS
BEGIN

  UPDATE so1.vm_work_flow t
  SET t.state=2,t.error_message=''
  WHERE queue_id='QH_EINVOICE'
  AND t.vars LIKE '%'||in_einvoice_id||'%'
  AND t.state=99 ;

  UPDATE so1.vm_schedule t
  SET t.state='W'
  WHERE t.workflow_id IN (SELECT task_id FROM so1.vm_work_flow WHERE queue_id='QH_EINVOICE' AND vars LIKE '%'||in_einvoice_id||'%');

  COMMIT ;

END p_ei_redo ;
/

