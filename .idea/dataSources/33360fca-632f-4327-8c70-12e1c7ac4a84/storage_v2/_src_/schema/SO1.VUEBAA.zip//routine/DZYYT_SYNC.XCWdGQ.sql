create procedure dzyyt_sync as

  v_sql1 varchar2(500);

begin


v_sql1 :='TRUNCATE TABLE so1.tmp_synccust_info ';


/*create table so1.tmp_synccust_info as
  select cm.cust_id,p.prod_inst_id,p.own_corp_org_id from so1.cm_customer cm,so1.ins_prod p where 0 = 1*/

EXECUTE immediate v_sql1 ;

INSERT INTO so1.tmp_synccust_info
  select distinct p.cust_id,p.prod_inst_id,p.own_corp_org_id from rep.szstbsync@szrep t,so1.ins_prod p where t.stbno = p.bill_id;

COMMIT;

UPDATE so1.batchsyn_custInf t
SET t.state2 = 1
where exists (SELECT 1 FROM so1.tmp_synccust_info tmp WHERE tmp.cust_id=t.cust_id);  --5963

COMMIT ;

update  so1.ord_sync_sub_info ord
set state0 = 1
where exists (select * from so1.tmp_synccust_info t where ord.prod_inst_id = t.prod_inst_id);  --6074
COMMIT ;


insert into rep.rep_log values ('dzyyt_sync_update', '已更新执行时间', sysdate);
  commit;

exception
  when others then
                null;
            rollback;

end dzyyt_sync;
/

