create PROCEDURE tvNumber_2_IMSI AS
    v_tv_Number          VARCHAR2(15);
    v_prod_inst_id  NUMBER(14);
    v_cust_id   NUMBER(14);
BEGIN
 for prod in (SELECT  insProd.Prod_Inst_Id,insProd.Cust_Id,insProd.Tv_Number from so1.ins_prod insProd) loop
      if prod.tv_number<> null  or prod.tv_number<>' ' then
            update  zg.i_user  u set u.imsi=prod.tv_number WHERE u.cust_id=prod.cust_id and u.serv_id=prod.prod_inst_id;
             commit;
      end if;
  end loop;
exception
  WHEN OTHERS THEN
   null;
END tvNumber_2_IMSI;




/

