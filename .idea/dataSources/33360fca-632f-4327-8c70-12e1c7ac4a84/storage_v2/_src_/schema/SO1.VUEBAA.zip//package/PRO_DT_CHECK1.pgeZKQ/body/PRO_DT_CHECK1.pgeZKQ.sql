create PACKAGE BODY     "PRO_DT_CHECK1"
As

   Procedure record_data(v_data In Varchar2)                                                            --??????? ????so1.tmp_record_data
             Is
             v_id Number;
   Begin
        Select Max(Id)+1 Into v_id From so1.tmp_record_data;
        If v_id Is Null Then
           v_id :=1;
        End If;
       Select Max(sync)+1 Into c_sync From so1.tmp_record_data;
       If c_sync Is Null Then
           c_sync :=1;
        End If;
        Insert Into so1.tmp_record_data
        Values(
               v_id,
               Sysdate,
               v_data,
               c_sync
        );
        Commit;
   Exception
               When Others Then
                    Rollback;
                    Raise;
   End record_data;

   Procedure get_old_cust(v_old_cust_mode Out t_old_cust_mode)                                 --?????????
             Is
   Begin
         Select /*+ parallel(cust,3)*/Count(1) Into v_old_cust_mode.old_cust
         From uc.uc_customer cust,gj4.dt_org org
         Where cust.corp_org_id = org.org_id;                                                                     --???????

         Select /*+ parallel(cat,3)*/Count(1) Into v_old_cust_mode.old_con
         From cs.cs_contact cat
         Where Exists (Select 1 From gj4.mp_cust_acc_sub ms
         Where ms.contact_id = cat.contact_id);                                                                  --???????

         Select /*+ parallel(cat,3)*/ Count(1) Into v_old_cust_mode.old_addr
         From cs.cs_address addr,cs.cs_contact cat
         Where cat.Addr_Id=addr.addr_id
         And Exists (Select 1 From gj4.mp_cust_acc_sub ms Where cat.contact_id=ms.contact_id);                    --??????

         Select /*+ parallel(acct,3)*/ Count(1) Into v_old_cust_mode.old_acct                  --??????
         From cs.cs_account acct
         Where Exists (Select 1 From gj4.mp_cust_acc_sub ms
         Where ms.customer_id = acct.customer_id);

         record_data('old_cust:'||v_old_cust_mode.old_cust||';old_con:'||v_old_cust_mode.old_con||';old_addr:'||v_old_cust_mode.old_addr||';old_acct:'||v_old_cust_mode.old_acct);
   Exception
             When Others Then
                  v_result := -1;
                  record_data(v_result);
   End get_old_cust;

   Procedure get_new_cust(v_new_cust_mode Out t_new_cust_mode)                             --????????
             Is
   Begin

         Select /*+ parallel(cust,3)*/ Count(1) Into v_new_cust_mode.new_cust
         From so1.cm_customer cust;                                                                                --???????

         Select /*+ parallel(info,3)*/ Count(1) Into v_new_cust_mode.new_con
         From so1.cm_cust_contact_info info;                                                                    --????????

         Select /*+ parallel(addr,3)*/ Count(1) Into v_new_cust_mode.new_addr
         From so1.ins_address addr;                                                                                   --??????

         Select /*+ parrallel(acct,3)*/ Count(1) Into v_new_cust_mode.new_acct
         From so1.acct acct;                                                                                               --??????

         Select Count(*) Into v_new_cust_mode.invalid_cust                                                                           --??????????
         From gj4.mp_cust_acc_sub ms
         Where ms.subscriber_id Is Null;

         record_data('new_cust:'||v_new_cust_mode.new_cust||';new_con:'||v_new_cust_mode.new_con||
                            ';new_addr:'||v_new_cust_mode.new_addr||';new_acct:'||v_new_cust_mode.new_acct||
                            ';????????'||v_new_cust_mode.invalid_cust);
   Exception
             When Others Then
                  v_result := -2;
                  record_data(v_result);
   End get_new_cust;

   Procedure get_old_sub(v_old_sub_mode Out t_old_sub_mode)
             Is
   Begin
        Select /*+ parallel(sub,3)*/ Count(1) Into v_old_sub_mode.old_sub                       --??????
        From cs.cs_subscriber sub,gj4.dt_org org
        Where sub.corp_org_id=org.org_id;

        Select /*+ parallel(subp,3)*/ Count(1) Into v_old_sub_mode.old_subp                 --????????
        From cs.cs_subscriber sub,cs.cs_prod_subscription subp,gj4.dt_org org
        Where sub.corp_org_id=org.org_id And subp.subscriber_id=sub.subscriber_id;

         record_data('old_sub:'||v_old_sub_mode.old_sub||';old_subp:'||v_old_sub_mode.old_subp);
   Exception
             When Others Then
                  v_result := -3;
                  record_data(v_result);
   End get_old_sub;

   Procedure get_new_sub(v_new_sub_mode Out t_new_sub_mode)                               --???????
             Is
   Begin
        Select /*+ parallel(prod,3)*/ Count(1) Into v_new_sub_mode.new_sub                 --???????
        From so1.ins_prod prod;

         Select /*+ parallel(offer,3)*/ Count(1) Into v_new_sub_mode.new_offer               --???????
        From so1.ins_offer offer;

        Select /*+ parallel(pkg,3)*/ Count(1) Into v_new_sub_mode.new_srvpkg                --???????
        From so1.ins_srvpkg pkg;

        Select /*+ parallel(pkg,3)*/ Count(1) Into v_new_sub_mode.new_srv                      --????????
        From so1.ins_srv srv;
        record_data('new_sub:'||v_new_sub_mode.new_sub||';new_offer:'||v_new_sub_mode.new_offer||'new_srvpkg:'||v_new_sub_mode.new_srvpkg||'new_srv:'||v_new_sub_mode.new_srv);
   Exception
             When Others Then
                  v_result := -4;
                  record_data(v_result);
   End get_new_sub;

   Procedure get_old_book(v_old_book Out t_old_book)                                                    --???????
             Is
   Begin
          Select sum(decode(bk.book_item_id,1,bk.amount,0))                                               --????????
                  ,sum(decode(bk.book_item_id,2,bk.amount,0))
                  ,sum(decode(bk.book_item_id,3,bk.amount,0))
                  ,sum(decode(bk.book_item_id,4,bk.amount,0))
                  ,sum(decode(bk.book_item_id,18,bk.amount,0))
                  ,sum(decode(bk.book_item_id,20,bk.amount,0))
                  ,sum(decode(bk.book_item_id,101100081,bk.amount,0))
        Into v_old_book
        From bm.bm_book bk
        Where Exists (Select 1 From gj4.mp_cust_acc_sub ms
        Where ms.account_id=bk.account_id);

        record_data('book_item_id_1='||v_old_book.old_book_1||';'||
                           'book_item_id_2='||v_old_book.old_book_2||';'||
                           'book_item_id_3='||v_old_book.old_book_3||';'||
                           'book_item_id_4='||v_old_book.old_book_4||';'||
                           'book_item_id_18='||v_old_book.old_book_18||';'||
                           'book_item_id_20='||v_old_book.old_book_20||';'||
                           'book_item_id_101100081='||v_old_book.old_book_101100081
                          );
   Exception
             When Others Then
                  v_result := -5;
                  record_data(v_result);
   End get_old_book;

   Procedure get_new_book(v_new_book Out t_new_book)                                                       --???????
             Is
   Begin
        Select Sum(decode(ab.balance_type_id,1,ab.balance,0))                                          --????????
                  ,Sum(decode(ab.balance_type_id,2,ab.balance,0))
                  ,Sum(decode(ab.balance_type_id,3,ab.balance,0))
                  ,Sum(decode(ab.balance_type_id,4,ab.balance,0))
                  ,Sum(decode(ab.balance_type_id,11,ab.balance,0))
                  ,Sum(decode(ab.balance_type_id,12,ab.balance,0))
                  ,Sum(decode(ab.balance_type_id,13,ab.balance,0))
                  ,Sum(decode(ab.balance_type_id,21,ab.balance,0))
                  ,Sum(decode(ab.balance_type_id,22,ab.balance,0))
                  ,Sum(decode(ab.balance_type_id,23,ab.balance,0))
                  Into v_new_book
        From zg.acct_balance ab;

      record_data('balance_type_id_1_vs_1='||v_new_book.new_1_vs_1||';'||
                           'balance_type_id_2_vs_2='||v_new_book.new_2_vs_2||';'||
                           'balance_type_id_3_vs_3='||v_new_book.new_3_vs_3||';'||
                           'balance_type_id_4_vs_4='||v_new_book.new_4_vs_4||';'||
                           'balance_type_id_18_vs_11='||v_new_book.new_18_vs_11||';'||
                           'balance_type_id_20_vs_12='||v_new_book.new_20_vs_12||';'||
                           'balance_type_id_101100081_vs_13='||v_new_book.new_101100081_vs_13||';'||
                           'balance_type_id_vs_21='||v_new_book.new_vs_21||';'||
                           'balance_type_id_vs_22='||v_new_book.new_vs_22||';'||
                           'balance_type_id_vs_23='||v_new_book.new_vs_23
                          );
   Exception
             When Others Then
                  v_result := -6;
                  record_data(v_result);
   End get_new_book;

End pro_dt_check1;
/

