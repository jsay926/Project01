create procedure old_work_flow_finish
Authid Current_User is
begin
              /*create table gj4.tmp_wf_list_his  (subscriber_id number(12) ,finish_date date ,  deal_date date );
              create table gj4.tmp_wf_list (subscriber_id number(12) ,finish_date date ,  deal_date date );
              */
              insert into gj4.tmp_wf_list_his select * from gj4.tmp_wf_list;
              delete from gj4.tmp_wf_list where 1=1;
              insert into gj4.tmp_wf_list
              select distinct wo.subscriber_id ,   max(wo.finish_date) , max(sysdate)
               from cs.cs_work_order@oboss wo  where wo.finish_date >date'2012-9-9'
               and wo.subscriber_id not in
                            (select subscriber_id from gj4.tmp_wf_list_his
                             union
                             select subscriber_id from gj4.tmp_wf_list)
               group by wo.subscriber_id;

              ----用户表
              Update so1.ins_prod prod Set prod.state=1, prod.os_status='1'
              Where Exists (Select 1 From  gj4.tmp_wf_list wf Where wf.subscriber_id=prod.prod_inst_id)
              and prod.state ='99' ;

              ---套餐订购和产品订购关系表
              Update so1.ins_off_ins_prod_rel rel Set rel.state=1
              Where Exists (Select 1 From  gj4.tmp_wf_list wf Where wf.subscriber_id=rel.prod_inst_id)
              and rel.state='99';

              ---套餐订购
              Update so1.ins_offer offer Set offer.state=1
              Where Exists (Select 1 From so1.ins_off_ins_prod_rel rel,gj4.tmp_wf_list wf
              Where wf.subscriber_id=rel.prod_inst_id And rel.offer_inst_id=offer.offer_inst_id)
              and offer.state='99';

              ---产品订购
              Update so1.ins_srvpkg pkg Set pkg.state=1,pkg.os_status='',valid_date=sysdate
              Where Exists (Select * From  gj4.tmp_wf_list wf Where wf.subscriber_id=pkg.prod_inst_id)
              and ( pkg.state='99' or pkg.os_status='99' );

              ---服务订购
              Update so1.ins_srv srv Set srv.state=1,valid_date=sysdate
              Where Exists (Select 1 From  gj4.tmp_wf_list wf Where wf.subscriber_id=srv.prod_inst_id)
              and srv.state='99' ;

              ----产品订购和服务订购的关系
              Update so1.ins_srvpkg_ins_srv_rel rel Set rel.state=1,valid_date=sysdate
              Where Exists (Select 1 From  gj4.tmp_wf_list wf ,  so1.ins_srvpkg pkg
              Where pkg.prod_inst_id=wf.subscriber_id And pkg.srvpkg_inst_id=rel.srvpkg_inst_id)
              and rel.state='99';

              -----帐管和帐处接口表

              ---create table gj4.i_user as select * from zg.i_user where 1=2 ;

              delete from gj4.i_user;

              ----帐管用户接口表
              INSERT INTO gj4.i_user(ACCT_ID,CUST_ID,SERV_ID,USER_PROPERTY,USER_TYPE,MSISDN,IMSI,IMEI,BRAND,ORG_ID
                                     ,REGION_CODE,COUNTY_CODE,CREATE_DATE,FIRST_USE_TIME,BEGIN_DATE,VALID_DATE,EXPIRE_DATE
                                     ,CYCLE_DAY,NEXT_CYCLE_DAY,DONE_CODE,RES_FLAG,REMARK,SO_NBR,MAIN_SERV_ID,BILL_TYPE
                                     ,SUB_STATUS,AOC_FLAG,SPEC_FLAG,USER_STS,CORP_ORG_ID
                                    )
              SELECT PROD.ACCT_ID,PROD.CUST_ID,PROD.PROD_INST_ID,PROD.USER_PROP,DECODE(MR.ROLE_SPEC,800300000001,1,800300000002,2,800300000003,3,800300000004,1,800300000005,6,9)
                     ,SUBSTRB(PROD.BILL_ID,1,50),SUBSTRB(PROD.SUB_BILL_ID,1,50),NULL IMEI,0 BRAND_ID,NVL(PROD.ORG_ID,0)
                     ,prod.region_id REGION_CODE,0 COUNTY_CODE,PROD.CREATE_DATE,NVL(PROD.BILL_START_DATE,PROD.CREATE_DATE),PROD.CREATE_DATE,PROD.Create_Date,PROD.EXPIRE_DATE
                     ,0 CYCLE_DAY,0 NEXT_CYCLE_DAY,0 DONE_CODE,NULL RES_FLAG,NULL REMARK,PROD.DONE_CODE,PROD.MAIN_PROD_INST_ID,1 BILL_TYPE
                     ,0 SUB_STATUS,0 AOC_FLAG,NULL SPEC_FLAG,0 USER_STS,PROD.OWN_CORP_ORG_ID
              FROM SO1.INS_PROD PROD
              LEFT JOIN (    select  uir.product_item_id offer_id , uir.relat_product_item_id PRODUCT_SPEC , extend_attr_e  ROLE_SPEC
                                         from product.up_item_relat uir where uir.prod_item_relat_kind_id like '%%OFFER_PLAN_GENERAL_PRODUCT_SPEC%'  and del_flag =0
                                    )   MR
              ON MR.OFFER_ID=PROD.OFFER_ID AND MR.PRODUCT_SPEC=PROD.PROD_SPEC_ID Join  gj4.tmp_wf_list wf
              On wf.subscriber_id=prod.prod_inst_id And Not Exists (Select 1 From zg.i_user u Where u.serv_id=wf.subscriber_id);

              Insert Into zg.i_user
              Select * From  gj4.i_user;
              
              insert into zg.i_user_plan(serv_id,plan_id,region_code,valid_date,expire_date,done_code,so_nbr,remark)
              select u.serv_id,10001,512,u.valid_date,u.expire_date,0,0,'割接预开通'
              from gj4.i_user u;

              insert into so1.ins_srvpkg_so_id_rel (ins_off_id,ins_srvpkg_id,ins_prod_id,prod_id,so_id)
              select  pkg.offer_inst_id, pkg.srvpkg_inst_id, pkg.prod_inst_id ,pp.prod_id, pkg.srvpkg_inst_id
              FROM SO1.INS_SRVPKG PKG
               join (   select  uir.product_item_id , pi.extend_id  prod_id
                             from product.up_item_relat  uir, product.up_product_item pi
                             where uir.relat_product_item_id= pi.product_item_id
                                 and uir.prod_item_relat_kind_id like '%SERVICE_PRICE_GENERAL_PRICE_PLAN_PKG_BOSS%'
                                 and uir.del_flag=0 and pi.del_flag=0
                                 and pi.item_type like 'PRICE_PLAN') pp
              on pkg.srvpkg_id = pp.product_item_id JOIN SO1.INS_PROD PROD
              ON PROD.PROD_INST_ID=PKG.PROD_INST_ID  JOIN SO1.INS_OFFER OFFER
              ON OFFER.OFFER_INST_ID=PKG.OFFER_INST_ID Join gj4.tmp_wf_list wf
              On wf.subscriber_id=prod.prod_inst_id
              where not exists (select 1 from ZG.I_USER_MSC where so_id = pkg.srvpkg_inst_id );

              ---帐处订购接口表
              INSERT INTO ZG.I_USER_MSC(SO_ID,SERV_ID,REGION_CODE,FUNC_TYPE,
                                           PROD_ID,BUSI_TYPE,FUNC_PARAM,
                                           PROPERTY,PLAN_ID,BEGIN_DATE,VALID_DATE,EXPIRE_DATE,DONE_CODE,
                                           REMARK,SO_NBR,OFFER_INST_ID,OPER_TYPE)
              SELECT PKG.SRVPKG_INST_ID,NVL(PROD.PROD_INST_ID,0),NVL(PROD.REGION_ID,'512'),102 FUNC_TYPE,
                     pp.prod_id,1 BUSI_TYPE ,NULL FUNC_PARAM,
                     NULL PROPERTY,0 PLAN_ID,pkg.create_date,sysdate,TO_DATE('20991231','YYYY-MM-DD'),0 DONE_CODE,
                     NULL REMARK,NULL SO_NBR,pkg.offer_inst_id,NULL OPER_TYPE
              FROM SO1.INS_SRVPKG PKG
               join (   select  uir.product_item_id , pi.extend_id  prod_id
                             from product.up_item_relat  uir, product.up_product_item pi
                             where uir.relat_product_item_id= pi.product_item_id
                                 and uir.prod_item_relat_kind_id like '%SERVICE_PRICE_GENERAL_PRICE_PLAN_PKG_BOSS%'
                                 and uir.del_flag=0 and pi.del_flag=0
                                 and pi.item_type like 'PRICE_PLAN') pp
              on pkg.srvpkg_id = pp.product_item_id JOIN SO1.INS_PROD PROD
              ON PROD.PROD_INST_ID=PKG.PROD_INST_ID  JOIN SO1.INS_OFFER OFFER
              ON OFFER.OFFER_INST_ID=PKG.OFFER_INST_ID Join gj4.tmp_wf_list wf
              On wf.subscriber_id=prod.prod_inst_id
              where not exists (select 1 from ZG.I_USER_MSC where so_id = pkg.srvpkg_inst_id );








              ---帐处优惠接口表
/*              INSERT INTO ZG.I_USER_SPROM(SO_ID,SERV_ID,SERVICE_ID,REGION_CODE,SPROM_TYPE,SPROM_ID
                                           ,BUSI_TYPE,SPROM_PARA,MAX_PROM,PROPERTY,PLAN_ID,VALID_DATE
                                           ,EXPIRE_DATE,DONE_CODE,REMARK,SO_NBR,BEGIN_DATE
                                           ,REFERENCE_OBJECT,RESULT_OBJECT,OFFER_INST_ID,OPER_TYPE
                                          )
              SELECT PKG.SRVPKG_INST_ID+10000000000,PROD.PROD_INST_ID,0 SERVICE_ID,PROD.REGION_ID,0 SPROM_TYPE
                     ,MOD(PKG.SRVPKG_ID,1000000)+90000000
                     ,0 BUSI_TYPE,NULL SPROM_PARA,NULL MAX_PROM,NULL PROPERTY,10001 PLAN_ID,PKG.VALID_DATE
                     ,PKG.EXPIRE_DATE,0,NULL REMARK,PKG.DONE_CODE,PKG.CREATE_DATE
                     ,0 REFERENCE_OBJECT,0 REFERENCE_OBJECT,PKG.OFFER_INST_ID,0 OPER_TYPE
              FROM SO1.INS_PROD PROD,SO1.INS_SRVPKG PKG,SO1.INS_OFFER OFFER, gj4.i_user u
              WHERE PROD.PROD_INST_ID=PKG.PROD_INST_ID AND OFFER.OFFER_INST_ID=PKG.OFFER_INST_ID
              And u.serv_id=prod.prod_inst_id
              AND EXISTS (SELECT 1 FROM GJ4.DT_SERVICE SERV,GJ4.DT_PROD_PLAN_MAPPING DPP
                  WHERE DPP.SERV_ID = SERV.SERV_ID AND SERV.SERVICE_TYPE = 4 AND DPP.NEW_PROD_ID = PKG.SRVPKG_ID)
                  and not exists (select 1 from  ZG.I_USER_SPROM  usp where usp.serv_id= prod.prod_inst_id and usp.sprom_id=MOD(PKG.SRVPKG_ID,1000000)+90000000 );
*/
                    ---帐处优惠接口表
                          INSERT INTO ZG.I_USER_SPROM(SO_ID,SERV_ID,SERVICE_ID,REGION_CODE,SPROM_TYPE,SPROM_ID
                                                       ,BUSI_TYPE,SPROM_PARA,MAX_PROM,PROPERTY,PLAN_ID,VALID_DATE
                                                       ,EXPIRE_DATE,DONE_CODE,REMARK,SO_NBR,BEGIN_DATE
                                                       ,REFERENCE_OBJECT,RESULT_OBJECT,OFFER_INST_ID,OPER_TYPE
                                                      )
                          SELECT PKG.SRVPKG_INST_ID+10000000000,pkg.PROD_INST_ID,0 SERVICE_ID,pkg.REGION_ID,0 SPROM_TYPE
                                 ,pi.extend_id
                                 ,0 BUSI_TYPE,NULL SPROM_PARA,NULL MAX_PROM,NULL PROPERTY,10001 PLAN_ID,PKG.VALID_DATE
                                 ,PKG.EXPIRE_DATE,0,NULL REMARK,PKG.DONE_CODE,PKG.CREATE_DATE
                                 ,0 REFERENCE_OBJECT,0 REFERENCE_OBJECT,PKG.OFFER_INST_ID,0 OPER_TYPE
               from  so1.ins_srvpkg pkg ,  product.up_item_relat uir  , product.up_price_plan upp , product.up_product_item pi ,base.CFG_SO_TO_BILLING_DATA c
              where pkg.srvpkg_id= uir.product_item_id and uir.prod_item_relat_kind_id  IN
                          ('SERVICE_PRICE_GENERAL_PRICE_PLAN_PKG_BOSS',
                           'SERVICE_PRICE_GENERAL_PRICE_PLAN_PKG_BILLING')
              and uir.relat_product_item_id= upp.price_plan_id
              and upp.price_plan_id= pi.product_item_id
              and upp.price_plan_type_cd= c.price_plan_type and upp.interface_code= c.interface_code
              and pkg.state<>99
              AND c.IMPLCLASS_TYPE  in (2)
               and pkg.expire_date>sysdate
              and not exists (select 1 from zg.i_user_sprom usp
                                               where usp.serv_id= pkg.prod_inst_id and usp.sprom_id= pi.extend_id);

           insert into so1.ins_srvpkg_so_id_rel (ins_off_id,ins_srvpkg_id,ins_prod_id,prod_id,so_id)
              select  pkg.offer_inst_id, pkg.srvpkg_inst_id, pkg.prod_inst_id , usp.sprom_id, usp.so_id
               from  so1.ins_srvpkg pkg ,  product.up_item_relat uir  , product.up_price_plan upp , product.up_product_item pi ,
               base.CFG_SO_TO_BILLING_DATA c, zg.i_user_sprom usp
              where pkg.srvpkg_id= uir.product_item_id and uir.prod_item_relat_kind_id  IN
                          ('SERVICE_PRICE_GENERAL_PRICE_PLAN_PKG_BOSS',
                           'SERVICE_PRICE_GENERAL_PRICE_PLAN_PKG_BILLING')
              and uir.relat_product_item_id= upp.price_plan_id
              and upp.price_plan_id= pi.product_item_id
              and upp.price_plan_type_cd= c.price_plan_type and upp.interface_code= c.interface_code
              and pkg.state<>99
              AND c.IMPLCLASS_TYPE  in (2)
              and pkg.expire_date>sysdate
              and usp.serv_id= pkg.prod_inst_id and usp.sprom_id= pi.extend_id
              and usp.expire_date >sysdate
              and usp.sprom_id <>1006
              and not exists (select 1 from so1.ins_srvpkg_so_id_rel  iss
                                               where iss.ins_srvpkg_id= pkg.srvpkg_inst_id and iss.so_id= usp.so_id);




              ---接口用户状态
              INSERT INTO ZG.I_USER_STATUS(SERV_ID,USER_STS,STOP_STS,REGION_CODE,VALID_DATE,EXPIRE_DATE
                                            ,DONE_CODE,REMARK,SO_NBR,MGNT_STS,OPER_STS,ACCT_STS
                                           )
              SELECT PROD.PROD_INST_ID,DECODE(PROD.STATE,'1',1,'M',4,'C',1,'D',14,6,1,0),0,nvl(PROD.REGION_ID,0),PROD.VALID_DATE
                     ,PROD.EXPIRE_DATE,0,PROD.REMARK,0,NULL MGNT_STS,NULL OPER_STS,NULL ACCT_STS
              FROM SO1.INS_PROD PROD,gj4.i_user u
              Where u.serv_id=prod.prod_inst_id
              and not exists (select 1 from  ZG.I_USER_STATUS ius where ius.serv_id= prod.prod_inst_id);


              ----订购状态
              INSERT INTO ZG.I_USER_PROD_STS(SO_ID,SERV_ID,REGION_CODE,SERVICE_ID,PROD_STS,BEGIN_DATE
                                              ,VALID_DATE,EXPIRE_DATE,SO_NBR,DONE_CODE,REMARK,PAY_SERVICE_ID
                                             )
              SELECT PKG.SRVPKG_INST_ID, pkg.prod_inst_id ,NVL(PKG.REGION_ID,0)
                                                                                                            ,NVL(PKG.PROD_SERVICE_ID,0),
                            (case when pkg.state=1 then 1  ---正常出账
                            when pkg.state=3 and ( pkg.os_status like '%l%'  or  pkg.os_status like '%6%'  or  pkg.os_status like '%f%' )then 5     ---不出账
                            when pkg.state=3 and ( pkg.os_status like '%1%' )then 2     ---欠费停
                            when pkg.state=3 and ( pkg.os_status like '%3%'  )then 4     ---主动暂停
                            when pkg.state=3 and ( pkg.os_status like '%4%'  )then 3     ---管理停
                            when pkg.state=3  then 2   ---停机出账
                            else 1 end)  PROD_STS
                     ,nvl(PKG.Valid_Date,SYSDATE),nvl(PKG.Done_Date,SYSDATE),nvl(PKG.EXPIRE_DATE,SYSDATE),PKG.DONE_CODE,0 DONE_CODE,
                     NULL REMARK,  pkg.prod_service_id PAY_SERVICE_ID
              FROM SO1.INS_SRVPKG PKG  JOIN SO1.INS_PROD PROD
              ON PROD.PROD_INST_ID=PKG.PROD_INST_ID  JOIN SO1.INS_OFFER OFFER
              ON OFFER.OFFER_INST_ID=PKG.OFFER_INST_ID Join gj4.tmp_wf_list wf
              On wf.subscriber_id=prod.prod_inst_id
              Where prod.state!='99' And pkg.prod_service_id!=0
              and  pkg.srvpkg_id <>800600040002
              and not exists (select 1 from ZG.I_USER_PROD_STS where so_id = pkg.srvpkg_inst_id);


              ----优惠订购状态
              INSERT INTO ZG.I_USER_PROD_STS(SO_ID,SERV_ID,REGION_CODE,SERVICE_ID,PROD_STS,BEGIN_DATE
                                              ,VALID_DATE,EXPIRE_DATE,SO_NBR,DONE_CODE,REMARK,PAY_SERVICE_ID
                                             )
              SELECT PKG.SRVPKG_INST_ID+10000000000, pkg.prod_inst_id ,NVL(PKG.REGION_ID,0)
                                                                                                            ,NVL(PKG.PROD_SERVICE_ID,0),
                           (case when pkg.state=1 then 1  ---正常出账
                            when pkg.state=3 and ( pkg.os_status like '%l%'  or  pkg.os_status like '%6%'  or  pkg.os_status like '%f%' )then 5     ---不出账
                            when pkg.state=3 and ( pkg.os_status like '%1%' )then 2     ---欠费停
                            when pkg.state=3 and ( pkg.os_status like '%3%'  )then 4     ---主动暂停
                            when pkg.state=3 and ( pkg.os_status like '%4%'  )then 3     ---管理停
                            when pkg.state=3  then 2   ---停机出账
                            else 1 end)  PROD_STS
                     ,nvl(PKG.Valid_Date,SYSDATE),nvl(PKG.Valid_Date,SYSDATE),nvl(PKG.EXPIRE_DATE,SYSDATE),PKG.DONE_CODE,0 DONE_CODE,
                     NULL REMARK,  pkg.prod_service_id PAY_SERVICE_ID
               from  so1.ins_srvpkg pkg ,  product.up_item_relat uir  , product.up_price_plan upp , product.up_product_item pi ,
               base.CFG_SO_TO_BILLING_DATA c, zg.i_user_sprom usp
              where pkg.srvpkg_id= uir.product_item_id and uir.prod_item_relat_kind_id  IN
                          ('SERVICE_PRICE_GENERAL_PRICE_PLAN_PKG_BOSS',
                           'SERVICE_PRICE_GENERAL_PRICE_PLAN_PKG_BILLING')
              and uir.relat_product_item_id= upp.price_plan_id
              and upp.price_plan_id= pi.product_item_id
              and upp.price_plan_type_cd= c.price_plan_type and upp.interface_code= c.interface_code
              and pkg.state<>99
              AND c.IMPLCLASS_TYPE  in (2)
              and pkg.expire_date>sysdate
              and usp.serv_id= pkg.prod_inst_id and usp.sprom_id= pi.extend_id
              and usp.expire_date >sysdate
              and usp.sprom_id <>1006
              and not exists (select 1 from ZG.I_USER_PROD_STS where so_id = pkg.srvpkg_inst_id);

              ---分业务表

              INSERT INTO ZG.USER_SERVICE_STS(SERV_ID,SERVICE_ID,OWE_BUSINESS_TYPE_ID,STATE,
                                              EFF_DATE,EXP_DATE,SO_NBR,OS_STS,ACCT_ID)
              SELECT PKG.PROD_INST_ID,NVL(PKG.PROD_SERVICE_ID,0),min(DECODE(PKG.OS_STATUS,1,0,3,8,0,0,0)),1 STATE
                     ,min(PKG.CREATE_DATE),max(PKG.EXPIRE_DATE),0 SO_NBR
                     ,min( case when pkg.state=3 and (pkg.os_status like '%1%')
                                     then '00000000000000010000000000000000000000000000000000'
                                     else '00000000000000000000000000000000000000000000000000'
                                     end),PROD.ACCT_ID
                     ---DECODE(PKG.State,1,'00000000000000000000000000000000000000000000000000','00000000000000010000000000000000000000000000000000')
              FROM SO1.INS_SRVPKG PKG LEFT JOIN SO1.INS_PROD PROD
              ON PROD.PROD_INST_ID=PKG.PROD_INST_ID,GJ4.DT_ORG D
              Where pkg.prod_service_id!=0
              AND PROD.OWN_CORP_ORG_ID=D.NEW_ORG_ID
              and pkg.prod_inst_id in (select wf.subscriber_id from gj4.tmp_wf_list wf)
              GROUP BY PKG.PROD_INST_ID,PKG.PROD_SERVICE_ID,PROD.ACCT_ID;


              ---帐管用户
              INSERT INTO ZG.SERV(SERV_ID,CUST_ID,PRODUCT_ID,BILLING_CYCLE_TYPE_ID,PRODUCT_FAMILY_ID,CREATE_DATE
                                  ,RENT_DATE,COMPLETED_DATE,STATE,EFF_DATE,EXP_DATE,SERV_CODE
                                  ,CUST_CODE,PRODUCT_CODE
                                  ,ORDER_NUMBER,PRE_FLAG,TRANS_FEE_FLAG,PROMOTION_ID,INSTANCE_NUM,PROMOTION_FLAG
                                  ,GROUP_SERV_CODE,GROUP_PRODUCT_CODE,USER_TYPE,MOB_MENU_LEVEL,CREDIT_LEVEL,REGION_ID
                                  ,EXCHANGE_ID,C6,AREA_ID,SO_NBR,ACC_NBR,BILL_TYPE,ACCT_ID,WRITEOFF_PROPERTY,BRAND
                                  ,GROUP_FLAG,CORP_ORG_ID,DATA_ORG_ID,SUB_BILL_ID,RES_EQU_NO,CUST_ADDR_ID,MAIN_SERV_ID
                                 )
              Select PROD.PROD_INST_ID,PROD.CUST_ID,0 PRODUCT_ID,0 BILLING_CYCLE_TYPE_ID,0 PRODUCT_FAMILY_ID,PROD.CREATE_DATE
                     ,PROD.CREATE_DATE,PROD.CREATE_DATE,DECODE(PROD.STATE,'1','2HA','2','2HD','M','2HC','A','2HB','C','2HB','D','2HB','E','2HB','99'),PROD.CREATE_DATE,PROD.EXPIRE_DATE,PROD.PROD_INST_ID
                     ,CUST.CUST_CODE,PROD.PROD_SPEC_ID
                     ,CUST.DONE_CODE,0 PRE_FLAG,0 TRANS_FEE_FLAG,NULL PROMOTION_ID,NULL INSTANCE_NUM,NULL PROMOTION_FLAG
                     ,NULL GROUP_SERV_CODE,NULL GROUP_PRODUCT_CODE,DECODE(PROD.PROD_SPEC_ID,800200000002,2,800200000003,4,800200000001,1,99),NULL MOB_MENU_LEVEL,NULL CREDIT_LEVEL,ADDR.REGION_ID
                     ,0 EXCHANGE_ID,NULL C6,0 AREA_ID,CUST.DONE_CODE,PROD.BILL_ID ACC_NBR,2 BILL_TYPE,PROD.ACCT_ID,NULL WRITEOFF_PROPERTY,0 BRAND
                     ,NULL GROUP_FLAG,PROD.OWN_CORP_ORG_ID,PROD.OWN_ORG_ID,PROD.SUB_BILL_ID,NULL RES_EQU_NO,ADDR.CUST_ADDR_ID,NVL(PROD.MAIN_PROD_INST_ID,0)
              FROM SO1.INS_PROD PROD JOIN SO1.CM_CUSTOMER CUST
              ON PROD.CUST_ID=CUST.CUST_ID LEFT JOIN SO1.ACCT ACCT
              ON ACCT.ACCT_ID=PROD.ACCT_ID AND CUST.CUST_ID=ACCT.CUST_ID LEFT JOIN SO1.INS_ADDRESS ADDR
              ON ADDR.CUST_ID=CUST.CUST_ID  Join gj4.i_user u
              On u.serv_id=prod.prod_inst_id
              Where Not Exists (Select 1 From ZG.SERV serv Where serv.serv_id=u.serv_id);


              Update ZG.I_USER_STATUS t Set t.USER_STS=1
              Where Exists (Select 1 From gj4.tmp_wf_list wf Where wf.subscriber_id=t.serv_id);

              Update ZG.I_USER_PROD_STS t Set t.prod_sts = 1
              Where Exists (Select 1 From gj4.tmp_wf_list wf Where wf.subscriber_id=t.serv_id)
              and t.expire_date >sysdate ;

              Update ZG.SERV t Set t.state='2HA'
              Where Exists (Select 1 From gj4.tmp_wf_list wf Where wf.subscriber_id=t.serv_id);

              insert into zg.cc_plan_instance_relation
              select zg.seq_cc_plan_relation_id.nextval,20 cc_plan_id,1 instance_type,prod_inst_id,acct_id,1 priority,valid_date,expire_date
              from so1.ins_prod
              where prod_inst_id in (select wf.subscriber_id from gj4.tmp_wf_list wf);

              Insert Into zg.i_sale_oper
              Select wf.subscriber_id,0,0,0,'11111111111111111111111111111111',ip.region_id,Sysdate,Sysdate,0,0,0,1
              From gj4.tmp_wf_list wf,so1.ins_prod ip
              WHERE wf.subscriber_id=ip.prod_inst_id ;






              ---用户和帐户关系表
              INSERT INTO ZG.SERV_ACCT(ACCT_ID,SERV_ID,BILLING_CYCLE_TYPE_ID,ACCT_ITEM_GROUP_ID,PRIORITY,PAYMENT_RULE_ID
                                        ,PAYMENT_LIMIT_TYPE,PAYMENT_LIMIT,STATE,EFF_DATE,EXP_DATE,IS_DEFAULT_ACCT_ID
                                        ,SO_NBR,STATE_DATE,ACCT_ITEM_TYPE_ID)
              SELECT SERV.ACCT_ID,SERV.SERV_ID,0 BILLING_CYCLE_TYPE_ID,0 ACCT_ITEM_GROUP_ID,1 PRIORITY,0 PAYMENT_RULE_ID
                     ,'5XA' PAYMENT_RULE_ID,'9999999' PAYMENT_LIMIT,'00A' STATE,SERV.EFF_DATE,SERV.EXP_DATE,'T' IS_DEFAULT_ACCT_ID
                     ,SERV.SO_NBR,SERV.CREATE_DATE,'82000001'
              FROM ZG.SERV SERV where serv.serv_id in (select serv_id  from gj4.i_user );



              commit;

              insert into so1.bat_author_tmp
              (bat_author_tmp_id,busi_type,act_type,cust_id,cust_code,offer_inst_id,
              offer_id,prod_inst_id,create_date,op_id,done_code,org_id,state,remark)
              select so1.bat_author_tmp$seq.nextval ,'','', ipd.cust_id ,'', 0,0,wf.subscriber_id,sysdate ,2,222,2001,0,''
              from gj4.tmp_wf_list wf,so1.ins_prod ipd
              where wf.subscriber_id=ipd.prod_inst_id;
              commit;
end  old_work_flow_finish ;





/

