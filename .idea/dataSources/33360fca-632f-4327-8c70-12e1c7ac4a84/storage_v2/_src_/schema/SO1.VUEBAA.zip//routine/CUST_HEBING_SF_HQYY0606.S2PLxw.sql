create procedure     cust_hebing_sf_hqyy0606
as
 cursor cur_value is select t.prod_inst_id from so1.ins_prod_bak_hqyy0605 t where t.cust_id<>140441857; --需要更改
begin
  for i in cur_value
  loop
       exit when cur_value%notfound;
  insert into zg.i_sale_oper_test2   --表明需要更改
      select  i.prod_inst_id,0,0,0,'11111111111111111111111111111111',512,sysdate,null,0 ,null,0 ,1 from dual t ;
  end loop;
  commit;
end cust_hebing_sf_hqyy0606;


/

