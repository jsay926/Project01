create PROCEDURE       "TY_FINDADDR" ()
is
begin
  dbms_output.enable(1000000000000);
  execute immediate 'alter session set nls_date_format='||''''||'yyyy-mm-dd hh24:mi:ss'||'''';
  print_insert('ORD_CUST','');
exception
   /*when others then
      rollback;*/
end ty_findAddr;





/

