create procedure SO_SYNCH_STDADDR is
  v_cust_id  NUMBER(14);
  CURSOR CUR_SYN_ADDRS IS
         SELECT * FROM PBOSS.ADDR_STDADDR_SYNCH SYN WHERE SYN.STATE = 1 ORDER BY SYN.RECID;

  CURSOR CUR_SYN_ISTD (P_STDID NUMBER) IS
         SELECT * FROM SO1.INS_ADDRESS ISD where ISD.STD_ADDR_ID = P_STDID;

  CURSOR CUR_SYN_CINFS (P_CUSTID NUMBER) IS
       SELECT * FROM SO1.CM_CUST_CONTACT_INFO CIF where CIF.CUST_ID = P_CUSTID;

  VAR_REC_ADDRSYN  PBOSS.ADDR_STDADDR_SYNCH%ROWTYPE;
  VAR_REC_INSADDRS SO1.INS_ADDRESS%ROWTYPE;
  VAR_REC_CINF SO1.CM_CUST_CONTACT_INFO%ROWTYPE;

begin
       OPEN CUR_SYN_ADDRS;
            --处理同步临时表游标
            LOOP
              FETCH CUR_SYN_ADDRS INTO VAR_REC_ADDRSYN;
              EXIT WHEN CUR_SYN_ADDRS%NOTFOUND;

                    OPEN CUR_SYN_ISTD(VAR_REC_ADDRSYN.STD_ADDR_ID);
                        --处理实例地址游标
                        LOOP
                           FETCH CUR_SYN_ISTD INTO VAR_REC_INSADDRS;
                           EXIT WHEN CUR_SYN_ISTD%notfound;
                                --更新实例地址
                                 UPDATE SO1.INS_ADDRESS IST SET IST.STD_ADDR_NAME = VAR_REC_ADDRSYN.DETAIL_NAME_NEW
                                 WHERE IST.CUST_ADDR_ID = VAR_REC_INSADDRS.CUST_ADDR_ID;
                                 ----add 2014.6.5
                                 select cust_id into v_cust_id from SO1.INS_ADDRESS IST WHERE IST.CUST_ADDR_ID = VAR_REC_INSADDRS.CUST_ADDR_ID;
                                 update so1.batchsyn_custinf t set state0=1,state2=1 where cust_id=v_cust_id; 
                                 --end add
                                 OPEN CUR_SYN_CINFS(VAR_REC_INSADDRS.CUST_ID);
                                     --处理客户联系人信息游标
                                     LOOP
                                        FETCH CUR_SYN_CINFS INTO VAR_REC_CINF;
                                        EXIT WHEN CUR_SYN_CINFS%notfound;
                                          --更新客户联系信息
                                          UPDATE  SO1.CM_CUST_CONTACT_INFO CIF SET CIF.CONT_ADDR = VAR_REC_ADDRSYN.DETAIL_NAME_NEW
                                          WHERE CIF.CONT_ID = VAR_REC_CINF.CONT_ID;
                                     END LOOP;
                                 CLOSE CUR_SYN_CINFS;
                         END LOOP;
                    CLOSE CUR_SYN_ISTD;
             --更新同步临时表数据为已处理
             UPDATE PBOSS.ADDR_STDADDR_SYNCH SYN SET SYN.STATE = 2 WHERE SYN.RECID = VAR_REC_ADDRSYN.RECID;
            END LOOP;
       CLOSE CUR_SYN_ADDRS;
       COMMIT;
end SO_SYNCH_STDADDR;




/

