create PROCEDURE queryTaskInfo(taskIds  in varchar2,
                                          p_CURSOR out PBOSS_PACKAGE.pboss_tasks_cursor) IS
BEGIN
  /* dbms_output.put_line(taskIds);*/
  OPEN p_CURSOR FOR
   select TASK_ID, /*工单ID*/
           CUST_CODE, /*客户证号*/
           CUST_NAME as CONTACT_NAME, /*姓名*/
           /*COLUMN2 as CONTACT_TEL, \*联系人电话*\
           COLUMN4 as CALL_TEL, \*来电电话*\*/
             Case When COLUMN2 Is  Not null Then COLUMN2
             Else   COLUMN10
               End  CONTACT_TEL,
            Case When COLUMN4 Is  Not null Then COLUMN4
             Else   COLUMN11
               End CALL_TEL,
           INSTALL_ADDR, /*安装地址*/
           STD_ADDR_NAME, /*标准地址名称*/
           OLD_STD_ADDR_NAME, /*标准地址名称*/
           ORDER_TYPE_CODE, /*定单类型*/
           COLUMN5 as MAC_NAME, /*MAC地址*/
           COLUMN8 as STB_RES_CODE, /* --机顶盒号*/
           COLUMN9 as CACARD_ID, /* --智能卡号*/
           PROD_CODE, /*--产品规格id*/
           (SELECT t.organize_name from sec.sec_organize t WHERE 1 = 1 and t.organize_id= SO_APPLY_ORG_ID) as ORG_ID, /*--受理组织ID*/
           (SELECT t.organize_name from sec.sec_organize t WHERE 1 = 1 and t.organize_id= SO_OWNER_ORG_ID) as OWNER_ORG_ID, /* -- 所属组织ID*/
           URGENCY_TIMES, /* --催单次数*/
           CREATE_DATE, /*--工单生成时间*/
           COMPLETE_DATE, /*-- 工单完成时间*/
           ALARM_DATE, /*--告警时间*/
           DELAY_DATE, /*  -- 超时时间*/
           BOOKING_START_DATE, /* --预约施工开始时间*/
           BOOKING_END_DATE, /* --预约施工结束时间*/
           TCOLUMN7 as AREA_NAME, /*  --片区名称*/
           STATE as TASK_STATE, /* --工单状态*/
           ORDER_STATE, /*--订单状态*/
           SO_SERIAL_CODE, /* --受理流水号*/
           DEAL_RESULT, /*--处理结果*/
           REMARKS, /*--工单备注*/
           ORDER_REMARK, /* --订单备注*/
           IS_DISPATCH, /* --是否调度*/
           IS_BOOKING, /*--是否预约*/
           CUST_TYPE, /* --客户类型 */
           CUST_LEVEL, /* --客户级别*/
           STATION_TYPE_ID, /* --工单对应岗位类型id*/
           (SELECT t.organize_name from sec.sec_organize t WHERE 1 = 1 and t.organize_id= REGION_ID) as REGION_ID , /* --地区id*/
           ALARM_DELAY_FLAG, /*--预警超时标志*/
           STANDARD_ADDR_ID, /* --标准地址ID*/
           TASK_TYPE_CODE, /*  --工单类型  outline.construct*/
          ORDER_ID , /*--订单id*/
          UPDATE_DATE,  /*工单最后更新时间*/
          ASSIGN_STAFF_NAME,  /*工单派发的操作员姓名*/
          ASSIGN_STAFF_CODE,  /*工单派发的操作员工号*/
          (SELECT t.static_name from  pboss.sf_static_data t WHERE 1 = 1 and  t.dict_id in (15) and t.static_code=  ORDER_OPER ) as ORDER_OPER  /*--定单操作   pboss.sf_static_data t WHERE 1 = 1 and  t.dict_id in (15);*/
      from (SELECT O.SO_ORDER_ID AS SO_ORDER_ID,
                   O.ORDER_ID AS ORDER_ID,
                   O.SO_SERIAL_CODE AS SO_SERIAL_CODE,
                   decode(O.PROD_CODE,800200000001,'数字用户', 800200000002, '模拟用户',800200000003 ,'宽带用户',800200000099,'融合虚用户',800200000103, '合同虚用户','') AS PROD_CODE,
                   (SELECT  t.order_item_name from  pboss.sf_order_type_def t WHERE 1 = 1 and t.order_item_code=O.ORDER_TYPE_CODE) AS ORDER_TYPE_CODE,
                   O.ACCESS_NUM AS ACCESS_NUM,
                   O.DONE_DATE AS SO_DATE,
                    (SELECT t.static_name from  pboss.sf_static_data t WHERE 1 = 1 and  t.dict_id in (17) and t.static_code=O.STATE)  AS ORDER_STATE,
                   O.ORDER_OPER AS ORDER_OPER,
                   O.OP_CODE AS SO_STAFF_CODE,
                   O.DISTRICT_ID AS DIST_ID,
                   O.MERGE_FLAG AS MERGE_FLAG,
                   O.ORDER_GRP_ID AS ORDER_GRP_ID,
                   O.ORDER_KIND AS ORDER_KIND,
                   O.INSTALL_ADDR AS INSTALL_ADDR,
                   O.OLD_INSTALL_ADDR AS OLD_INSTALL_ADDR,
                   O.STD_ADDR_ID AS STANDARD_ADDR_ID,
                   O.STD_ADDR_NAME AS STD_ADDR_NAME,
                   O.OLD_STD_ADDR_ID AS OLD_STD_ADDR_ID,
                   O.OLD_STD_ADDR_NAME AS OLD_STD_ADDR_NAME,
                   O.PRODUCT_TYPE AS PRODUCT_TYPE,
                   O.OP_NAME AS OP_NAME,
                   O.PRODUCT_NUMBER AS PRODUCT_NUMBER,
                   O.URGENCY_TIMES AS URGENCY_TIMES,
                   O.OUTLINE_FLAG AS OUTLINE_FLAG,
                   O.PRIORITY AS PRIORITY,
                   O.REMARK AS ORDER_REMARK,
                   O.IS_MAIN_PROD AS IS_MAIN_PROD,
                   C.CUST_ID AS CUST_ID,
                   C.CUST_NAME AS CUST_NAME,
                    (select csd.code_name from base.cfg_static_data csd  WHERE csd.state=1 and csd.code_type='CM_CUSTOMER@CUST_TYPE' and csd.code_value=C.CUST_TYPE)  AS CUST_TYPE,
                   C.CUST_CODE AS CUST_CODE,
                   (select csd.code_name from base.cfg_static_data csd  WHERE csd.state=1 and csd.code_type='CM_CUSTOMER@CUST_LEVEL' and csd.code_value=C.CUST_LEVEL) AS CUST_LEVEL,
                   C.CUST_CERT_TYPE  AS CUST_CERT_TYPE,
                   C.CUST_CERT_NO AS CUST_CERT_NO,
                   T.TASK_ID AS TASK_ID,
                   T.TASK_TYPE_NAME AS TASK_TYPE_CODE,
                   T.TASK_TYPE_NAME AS TASK_TYPE_NAME,
                   T.ORG_ID AS SO_APPLY_ORG_ID,
                   T.OWN_ORG_ID AS SO_OWNER_ORG_ID,
                   T.CREATE_DATE AS CREATE_DATE,
                   T.ASSIGN_STAFF_ID AS ASSIGN_STAFF_ID,
                   T.ASSIGN_STAFF_NAME AS ASSIGN_STAFF_NAME,
                   T.ASSIGN_STAFF_CODE AS ASSIGN_STAFF_CODE,
                   T.ASSIGN_STATION_ID AS ASSIGN_STATION_ID,
                   T.ASSIGN_STATION_NAME AS ASSIGN_STATION_NAME,
                   T.OWN_ORG_ID AS OWN_ORG_ID,
                   T.LOCK_DATE AS LOCK_DATE,
                   T.LOCK_STAFF_ID AS LOCK_STAFF_ID,
                   T.LOCK_STAFF_NAME AS LOCK_STAFF_NAME,
                   T.LOCK_STAFF_CODE AS LOCK_STAFF_CODE,
                   T.EXECUTE_DATE AS EXECUTE_DATE,
                   T.EXECUTE_STAFF_ID AS EXECUTE_STAFF_ID,
                   T.EXECUTE_STAFF_NAME AS EXECUTE_STAFF_NAME,
                   T.EXECUTE_STAFF_CODE AS EXECUTE_STAFF_CODE,
                   T.COMPLETE_DATE AS COMPLETE_DATE,
                   T.DEAL_PRIORITY AS DEAL_PRIORITY,
                   T.ALARM_DATE AS ALARM_DATE,
                   T.DELAY_DATE AS DELAY_DATE,
                   T.ALARM_DELAY_FLAG AS ALARM_DELAY_FLAG,
                   T.ALARM_TIMES AS ALARM_TIMES,
                   T.BOOKING_START_DATE AS BOOKING_START_DATE,
                   T.BOOKING_END_DATE AS BOOKING_END_DATE,
                   T.DEAL_WAY AS DEAL_WAY,
                   T.DEAL_RESULT AS DEAL_RESULT,
                   T.SMALL_STATE AS SMALL_STATE,
                    (SELECT ps.static_name from  pboss.sf_static_data ps WHERE 1 = 1 and  ps.dict_id in (9) and ps.static_code=T.STATE) AS STATE,
                   T.REMARK AS REMARKS,
                   T.TASK_AUTO_FLAG AS TASK_AUTO_FLAG,
                   T.REGION_ID AS REGION_ID,
                   S.IS_DISPATCH AS IS_DISPATCH,
                   S.IS_BOOKING AS IS_BOOKING,
                   S.IS_BATCH AS IS_BATCH,
                   S.IS_BRANCH AS IS_BRANCH,
                   S.IS_MUL_LAY AS IS_MUL_LAY,
                   S.BRANCH_CONTENT AS BRANCH_CONTENT,
                   S.BRANCH_EXTEND AS BRANCH_EXTEND,
                   S.IS_PRINT AS IS_PRINT,
                   0 AS ROAD_ID,
                   S.STATION_TYPE_ID AS STATION_TYPE_ID,
                   O.ACCESS_WAY AS ACCESS_WAY,
                   O.BUSI_TYPE AS BUSI_TYPE,
                   (case
                     when INS.Order_Amount is null then
                      1
                     else
                      INS.Order_Amount
                   end) AS ORDER_AMOUNT,
                   OI.COLUMN0,
                   OI.COLUMN1,
                   OI.COLUMN2,
                   OI.COLUMN3,
                   OI.COLUMN4,
                   OI.COLUMN5,
                   OI.COLUMN6,
                   OI.COLUMN7,
                   OI.COLUMN8,
                   OI.COLUMN9,
                   OI.COLUMN10,
                   OI.COLUMN11,
                   OI.COLUMN12,
                   OI.COLUMN13,
                   OI.COLUMN14,
                   OI.COLUMN15,
                   OI.COLUMN16,
                   OI.COLUMN17,
                   OI.COLUMN18,
                   OI.COLUMN19,
                   OI.COLUMN20,
                   OI.COLUMN21,
                   OI.COLUMN22,
                   OI.COLUMN23,
                   OI.COLUMN24,
                   OI.COLUMN25,
                   OI.COLUMN26,
                   OI.COLUMN27,
                   OI.COLUMN28,
                   OI.COLUMN29,
                   OI.COLUMN30,
                   OI.COLUMN31,
                   OI.COLUMN32,
                   OI.COLUMN33,
                   OI.COLUMN34,
                   TI.TCOLUMN0,
                   TI.TCOLUMN1,
                   TI.TCOLUMN2,
                   TI.TCOLUMN3,
                   TI.TCOLUMN4,
                   TI.TCOLUMN5,
                   TI.TCOLUMN6,
                   TI.TCOLUMN7,
                   TI.TCOLUMN8,
                   TI.TCOLUMN9,
                   sync.update_date as UPDATE_DATE
              FROM pboss.SF_TASK_INS        T,
                   pboss.SF_ORDER           O,
                   pboss.SF_ORDER_CUST      C,
                   pboss.SF_TASK_TEMPLATE   S,
                   pboss.SF_ORDER_GROUP_INS INS,
                   pboss.SF_ORDER_SIDE_INFO OI,
                   pboss.SF_TASK_SIDE_INFO  TI,
                   so1.PBOSS_TASK_SYNC  sync
             WHERE T.ORDER_ID = O.ORDER_ID
               AND O.ORDER_ID = C.ORDER_ID
               AND O.ORDER_ID = OI.ORDER_ID(+)
               AND T.TASK_ID = TI.TASK_ID(+)
                AND  T.TASK_ID = sync.TASK_ID(+)
               AND O.Order_Grp_Id = INS.ORDER_GRP_ID(+)
               AND T.TASK_TYPE_CODE = S.TASK_TYPE_CODE)
     where 1 = 1
       and TASK_ID in
           (SELECT TO_NUMBER(p.s_value)
              from table(System.Split(taskIds, ',')) p)
       and TASK_AUTO_FLAG = 0
       and (MERGE_FLAG != 3 OR MERGE_FLAG is null)
       --and (OWN_ORG_ID=2001);
       ;
end queryTaskInfo;
/

