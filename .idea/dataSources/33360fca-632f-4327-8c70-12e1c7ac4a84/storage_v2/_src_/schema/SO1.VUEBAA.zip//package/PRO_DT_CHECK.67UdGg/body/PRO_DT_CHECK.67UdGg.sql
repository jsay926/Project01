create PACKAGE BODY       "PRO_DT_CHECK" 
As

   Procedure record_data(v_data In Varchar2)                                                            --??????? ????so1.tmp_record_data
             Is
             v_id Number;
   Begin
        Select Max(Id)+1 Into v_id From so1.tmp_record_data;
        If v_id Is Null Then
           v_id :=1;
        End If;
       Select Max(sync)+1 Into c_sync From so1.tmp_record_data;
       If c_sync Is Null Then
           c_sync :=1;
        End If;
        Insert Into so1.tmp_record_data
        Values(
               v_id,
               Sysdate,
               v_data,
               c_sync
        );
        Commit;
   Exception
               When Others Then
                    Rollback;
                    Raise;
   End record_data;

   Procedure get_old_cust(v_old_cust_mode Out t_old_cust_mode)                                 --?????????
             Is
   Begin
         Select /*+ parallel(cust,3)*/Count(1) Into v_old_cust_mode.old_cust
         From uc.uc_customer cust,gj.dt_org org
         Where cust.corp_org_id = org.org_id;                                                                     --???????

         Select /*+ parallel(cat,3)*/Count(1) Into v_old_cust_mode.old_con
         From cs.cs_contact cat
         Where Exists (Select 1 From gj.mp_cust_acc_sub ms
         Where ms.contact_id = cat.contact_id);                                                                  --???????

         Select /*+ parallel(cat,3)*/ Count(1) Into v_old_cust_mode.old_addr
         From cs.cs_address addr,cs.cs_contact cat
         Where cat.Addr_Id=addr.addr_id
         And Exists (Select 1 From gj.mp_cust_acc_sub ms Where cat.contact_id=ms.contact_id);                    --??????

         Select /*+ parallel(acct,3)*/ Count(1) Into v_old_cust_mode.old_acct                  --??????
         From cs.cs_account acct
         Where Exists (Select 1 From gj.mp_cust_acc_sub ms
         Where ms.customer_id = acct.customer_id);

         record_data('old_cust:'||v_old_cust_mode.old_cust||';old_con:'||v_old_cust_mode.old_con||';old_addr:'||v_old_cust_mode.old_addr||';old_acct:'||v_old_cust_mode.old_acct);
   Exception
             When Others Then
                  v_result := -1;
                  record_data(v_result);
   End get_old_cust;

   Procedure get_new_cust(v_new_cust_mode Out t_new_cust_mode)                             --????????
             Is
   Begin

         Select /*+ parallel(cust,3)*/ Count(1) Into v_new_cust_mode.new_cust
         From so1.cm_customer cust;                                                                                --???????

         Select /*+ parallel(info,3)*/ Count(1) Into v_new_cust_mode.new_con
         From so1.cm_cust_contact_info info;                                                                    --????????

         Select /*+ parallel(addr,3)*/ Count(1) Into v_new_cust_mode.new_addr
         From so1.ins_address addr;                                                                                   --??????

         Select /*+ parrallel(acct,3)*/ Count(1) Into v_new_cust_mode.new_acct
         From so1.acct acct;                                                                                               --??????

         Select Count(*) Into v_new_cust_mode.invalid_cust                                                                           --??????????
         From gj.mp_cust_acc_sub ms
         Where ms.subscriber_id Is Null;

         record_data('new_cust:'||v_new_cust_mode.new_cust||';new_con:'||v_new_cust_mode.new_con||
                            ';new_addr:'||v_new_cust_mode.new_addr||';new_acct:'||v_new_cust_mode.new_acct||
                            ';????????'||v_new_cust_mode.invalid_cust);
   Exception
             When Others Then
                  v_result := -2;
                  record_data(v_result);
   End get_new_cust;

   Procedure get_old_sub(v_old_sub_mode Out t_old_sub_mode)
             Is
   Begin
        Select /*+ parallel(sub,3)*/ Count(1) Into v_old_sub_mode.old_sub                       --??????
        From cs.cs_subscriber sub,gj.dt_org org
        Where sub.corp_org_id=org.org_id;

        Select /*+ parallel(subp,3)*/ Count(1) Into v_old_sub_mode.old_subp                 --????????
        From cs.cs_subscriber sub,cs.cs_prod_subscription subp,gj.dt_org org
        Where sub.corp_org_id=org.org_id And subp.subscriber_id=sub.subscriber_id;

         record_data('old_sub:'||v_old_sub_mode.old_sub||';old_subp:'||v_old_sub_mode.old_subp);
   Exception
             When Others Then
                  v_result := -3;
                  record_data(v_result);
   End get_old_sub;

   Procedure get_new_sub(v_new_sub_mode Out t_new_sub_mode)                               --???????
             Is
   Begin
        Select /*+ parallel(prod,3)*/ Count(1) Into v_new_sub_mode.new_sub                 --???????
        From so1.ins_prod prod;

         Select /*+ parallel(offer,3)*/ Count(1) Into v_new_sub_mode.new_offer               --???????
        From so1.ins_offer offer;

        Select /*+ parallel(pkg,3)*/ Count(1) Into v_new_sub_mode.new_srvpkg                --???????
        From so1.ins_srvpkg pkg;

        Select /*+ parallel(pkg,3)*/ Count(1) Into v_new_sub_mode.new_srv                      --????????
        From so1.ins_srv srv;
        record_data('new_sub:'||v_new_sub_mode.new_sub||';new_offer:'||v_new_sub_mode.new_offer||'new_srvpkg:'||v_new_sub_mode.new_srvpkg||'new_srv:'||v_new_sub_mode.new_srv);
   Exception
             When Others Then
                  v_result := -4;
                  record_data(v_result);
   End get_new_sub;

   Procedure get_old_book(v_old_book Out t_old_book)                                                    --???????
             Is
   Begin
        Select sum(decode(bk.book_item_id,10,bk.amount,0))                                               --????????
                  ,sum(decode(bk.book_item_id,20,bk.amount,0))
                  ,sum(decode(bk.book_item_id,30,bk.amount,0))
                  ,sum(decode(bk.book_item_id,40,bk.amount,0))
                  ,sum(decode(bk.book_item_id,50,bk.amount,0))
                  ,sum(decode(bk.book_item_id,60,bk.amount,0))
                  ,sum(decode(bk.book_item_id,70,bk.amount,0))
                  ,sum(decode(bk.book_item_id,80,bk.amount,0))
                  ,sum(decode(bk.book_item_id,110,bk.amount,0))
                  ,sum(decode(bk.book_item_id,120,bk.amount,0))
        Into v_old_book
        From bm.bm_book bk
        Where Exists (Select 1 From gj.mp_cust_acc_sub ms
        Where ms.account_id=bk.account_id);

        record_data('book_item_id_10='||v_old_book.old_book_10||';'||
                           'book_item_id_20='||v_old_book.old_book_20||';'||
                           'book_item_id_30='||v_old_book.old_book_30||';'||
                           'book_item_id_40='||v_old_book.old_book_40||';'||
                           'book_item_id_50='||v_old_book.old_book_50||';'||
                           'book_item_id_60='||v_old_book.old_book_60||';'||
                           'book_item_id_70='||v_old_book.old_book_70||';'||
                           'book_item_id_80='||v_old_book.old_book_80||';'||
                           'book_item_id_110='||v_old_book.old_book_110||';'||
                           'book_item_id_120='||v_old_book.old_book_120
                          );
   Exception
             When Others Then
                  v_result := -5;
                  record_data(v_result);
   End get_old_book;

   Procedure get_new_book(v_new_book Out t_new_book)                                                       --???????
             Is
   Begin
        Select Sum(decode(ab.balance_type_id,102001,ab.balance,0))                                          --????????
                  ,Sum(decode(ab.balance_type_id,102002,ab.balance,0))
                  ,Sum(decode(ab.balance_type_id,106001,ab.balance,0))
                  ,Sum(decode(ab.balance_type_id,101001,ab.balance,0))
                  ,Sum(decode(ab.balance_type_id,108001,ab.balance,0))
                  ,Sum(decode(ab.balance_type_id,107001,ab.balance,0))
                  ,Sum(decode(ab.balance_type_id,104001,ab.balance,0))
                  ,Sum(decode(ab.balance_type_id,104003,ab.balance,0))
                  Into v_new_book
        From zg.acct_balance@zg ab;

        record_data('balance_type_id_10_vs_102001='||v_new_book.new_10_vs_102001||';'||
                           'balance_type_id_20_vs_102002='||v_new_book.new_20_vs_102002||';'||
                           'balance_type_id_30_40_vs_106001='||v_new_book.new_30_40_vs_106001||';'||
                           'balance_type_id_50_vs_101001='||v_new_book.new_50_vs_101001||';'||
                           'balance_type_id_60_vs_108001='||v_new_book.new_60_vs_108001||';'||
                           'balance_type_id_70_80_vs_107001='||v_new_book.new_70_80_vs_107001||';'||
                           'balance_type_id_110_vs_104001='||v_new_book.new_110_vs_104001||';'||
                           'balance_type_id_120_vs_104003='||v_new_book.new_120_vs_104003
                          );
   Exception
             When Others Then
                  v_result := -6;
                  record_data(v_result);
   End get_new_book;

End pro_dt_check;
/

