create FUNCTION       "DT_TRAN_UNION" (invoice_id In Number)
        Return Varchar2 Is
        v_chg_item_id Number;
        v_amount Number;
        v_result Varchar2(300);
        v_count Number;
        Cursor v_cur  Is Select /*+ index(dtl)*/ chg_item_id,amount From bm.bm_invoice_dtl dtl
               Where dtl.Invoice_Id = invoice_id;
Begin
      Open v_cur;
      v_count :=0;
      Loop
           Fetch v_cur Into v_chg_item_id,v_amount;
           Exit When v_cur%Notfound;
           v_count :=v_count + 1;
           If v_result Is Null  Then
               If v_cur%Rowcount = 1 Then
                   v_result := v_chg_item_id||':1:'||v_amount;
                   Exit;
               Else
                   v_result := v_chg_item_id||':1:'||v_amount||'|';
               End If;
           Elsif v_result Is Not Null And v_cur%Rowcount = v_count Then
                   v_result := v_chg_item_id||':1:'||v_amount||'|';
           Else
                  v_result := v_chg_item_id||':1:'||v_amount;
           End If;
      End Loop;
      Close v_cur;
      Return  v_result;
Exception
          When Others Then
                Return Null;
End;





/

