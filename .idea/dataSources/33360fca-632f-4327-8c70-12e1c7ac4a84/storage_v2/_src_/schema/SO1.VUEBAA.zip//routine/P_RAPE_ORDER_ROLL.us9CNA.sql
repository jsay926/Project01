create PROCEDURE p_rape_order_roll (in_order_id IN VARCHAR2 )

AS

BEGIN

  dbms_output.put_line('需要处理的订单编号为:'||in_order_id);

----------------订单移入历史

insert into so1.ord_address select * from so1.ord_address_f_2013 t where t.cust_order_id = in_order_id;
insert into so1.ord_cust select * from so1.ord_cust_f_2013 t where t.cust_order_id = in_order_id;
insert into so1.ord_custinfo select * from so1.ord_custinfo_f_2013 t where t.cust_order_id = in_order_id;
INSERT INTO so1.ord_accrel SELECT * FROM so1.ord_accrel_f_2013 t WHERE t.cust_order_id = in_order_id;
INSERT INTO so1.ord_acctinfo SELECT * FROM so1.ord_acctinfo_f_2013 t WHERE t.cust_order_id = in_order_id;
insert into so1.ord_busi select * from so1.ord_busi_f_2013 t where t.cust_order_id = in_order_id;
insert into so1.ord_offer select * from so1.ord_offer_f_2013 t where t.cust_order_id = in_order_id;
insert into so1.ord_price select * from so1.ord_price_f_2013 t where t.cust_order_id = in_order_id;
insert into so1.ord_prod select * from so1.ord_prod_f_2013 t where t.cust_order_id = in_order_id;
insert into so1.ord_srvpkg select * from so1.ord_srvpkg_f_2013 t where t.cust_order_id = in_order_id;
insert into so1.ord_srv select * from so1.ord_srv_f_2013 t where t.cust_order_id = in_order_id;
insert into so1.ord_srvpkg_ord_srv select * from so1.ord_srvpkg_ord_srv_f_2013 t where t.cust_order_id = in_order_id;
insert into so1.ord_srv_attr select * from so1.ord_srv_attr_f_2013 t where t.cust_order_id = in_order_id;
insert into so1.ord_prod_res SELECT * FROM so1.ord_prod_res_f_2013 t where t.cust_order_id = in_order_id;

dbms_output.put_line('订单编号为:'||in_order_id||'已经被移入历史!');



---------------删除订单

delete from so1.ord_address_f_2013 t where t.cust_order_id = in_order_id;
delete from so1.ord_cust_f_2013 t where t.cust_order_id = in_order_id;
DELETE from so1.ord_custinfo_f_2013 t where t.cust_order_id = in_order_id;
DELETE FROM so1.ord_accrel_f_2013 t WHERE t.cust_order_id = in_order_id;
DELETE FROM so1.ord_acctinfo_f_2013 t WHERE t.cust_order_id = in_order_id;
delete from so1.ord_busi_f_2013 t where t.cust_order_id = in_order_id;
delete from so1.ord_offer_f_2013 t where t.cust_order_id = in_order_id;
delete from so1.ord_price_f_2013 t where t.cust_order_id = in_order_id;
delete from so1.ord_prod_f_2013 t where t.cust_order_id = in_order_id;
delete from so1.ord_srvpkg_f_2013 t where t.cust_order_id = in_order_id;
delete from so1.ord_srv_f_2013 t where t.cust_order_id = in_order_id;
delete from so1.ord_srvpkg_ord_srv_f_2013 t where t.cust_order_id = in_order_id;
delete from so1.ord_prod_res_f_2013 t where t.cust_order_id = in_order_id;
delete from so1.ord_srv_attr_f_2013 t where t.cust_order_id = in_order_id;

dbms_output.put_line('订单编号为:'||in_order_id||'已经被删除!');



--------工作流挪历史


insert into so1.vm_work_flow
select * from so1.his_vm_work_flow t WHERE t.vars LIKE '%'||in_order_id||'%';

insert into so1.vm_task
select * from so1.his_vm_task
where workflow_id in (select task_id FROM so1.his_vm_work_flow t WHERE t.vars LIKE '%'||in_order_id||'%');

delete FROM so1.his_vm_task
where workflow_id  IN (select task_id FROM so1.his_vm_work_flow t WHERE t.vars LIKE '%'||in_order_id||'%');

delete FROM so1.his_vm_work_flow t WHERE t.vars LIKE '%'||in_order_id||'%';

 dbms_output.put_line('订单编号为:'||in_order_id||'工作流数据处理完毕 !');

commit;
end;





/

