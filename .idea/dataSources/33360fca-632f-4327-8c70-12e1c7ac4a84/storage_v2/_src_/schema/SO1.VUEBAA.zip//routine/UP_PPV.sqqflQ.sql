create FUNCTION       "UP_PPV" 
(
in_ppv_id  in number
) return number
IS

------------------------------
ln_done_code    number;
ln_ppv_id  number;
----------------------------
begin

        ln_ppv_id:=in_ppv_id;

        select zg.I_SALE_OPER$SEQ.nextval@zg.domain  into ln_done_code
        from dual;

        insert into zg.i_ppv_info@zg.domain (PPV_ID, PPV_TYPE, REGION_CODE, STD_FEE, PRICE_UNIT,
        CP_CODE, BEGIN_DATE, VALID_DATE, EXPIRE_DATE, REMARK, SO_NBR, DONE_CODE)
        select PPV_ID, PPV_TYPE,0 REGION_CODE, STD_FEE, PRICE_UNIT, CP_CODE, CREATE_DATE, VALID_DATE, EXPIRE_DATE,
        description REMARK,0 SO_NBR,ln_done_code
        from product.up_ppv
        WHERE PPV_ID=ln_ppv_id OR ln_ppv_id=0;

        insert into zg.i_ppv_prod_rel@zg.domain
        select PPV_ID,0 SERVICE_ID,0 REGION_CODE,0 SPROM_TYPE, extend_id SPROM_ID, SYSDATE BEGIN_DATE, SYSDATE VALID_DATE, TO_DATE('2099-1-1','YYYY-MM-DD')EXPIRE_DATE,
        'TEST' REMARK,0 SO_NBR,ln_done_code DONE_CODE
        from product.up_servicepkg_ppv_rel A,PRODUCT.UP_ITEM_RELAT B,product.up_product_item c
        WHERE A.SERVICE_PRICE_ID=B.PRODUCT_ITEM_ID
        AND PROD_ITEM_RELAT_KIND_ID='SERVICE_PRICE_GENERAL_PRICE_PLAN_PKG_BOSS'
        and b.RELAT_PRODUCT_ITEM_ID=c.product_item_id
        and (PPV_ID=in_ppv_id OR in_ppv_id=0);


        insert into zg.i_sale_oper@zg.domain
        select ppv_id ,0,0,0,'00000000000000000110000000000000',0,sysdate,'',ln_done_code done_code,'',0,2
        from product.up_ppv
        where PPV_ID=in_ppv_id OR in_ppv_id=0;

        commit;

  return  0;
exception
  when no_data_found then
      rollback;
      return -98;
   when others then
      rollback;
      return -99;
end;







/

