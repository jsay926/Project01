create PROCEDURE       "PROC_TAXINVNO" (TAXINVID VARCHAR2,INVNO VARCHAR2,OP_DATE DATE,OP_TYPE VARCHAR2)
 AS
  TABLENAME VARCHAR2(255);
  TAXID NUMBER(12);
  OPDATE  VARCHAR2(100);
  BEGIN
    OPDATE := TO_CHAR(OP_DATE,'YYYYMMDD') ;
    -- 判断CRM还是帐管侧的流水号
      IF(SUBSTR(TAXINVID,0,3) = 'CRM') THEN
       -- 取分表的日期和TAXID     
          TABLENAME := 'SO1.ORD_INVOICE' || SUBSTR(TAXINVID,INSTR(TAXINVID,'_',-1,1));
          TAXID := SUBSTR(TAXINVID,5,INSTR(TAXINVID,'_',-1)-5);
          -- 打印成功
          IF(upper(OP_TYPE) = 'PRINT') THEN
             EXECUTE IMMEDIATE 'UPDATE '|| TABLENAME ||' SET INVOICE_NUM = ' || INVNO || ', DONE_DATE   = to_date(' || OPDATE || ',''YYYYMMDD'' ),STATE = 1,PRINT_COUNT = PRINT_COUNT + 1 WHERE INVOICE_ID = ' || TAXID  ;
          -- 作废退票
          ELSIF(UPPER(OP_TYPE) = 'CANCEL') THEN
             EXECUTE IMMEDIATE 'UPDATE '|| TABLENAME ||' SET INVOICE_NUM = ' || INVNO || ', DONE_DATE   = to_date(' || OPDATE || ',''YYYYMMDD'' ),STATE = 2 WHERE INVOICE_ID = ' || TAXID;
          END IF ;
      -- 帐管侧更新
      ELSE
          TABLENAME := 'ZG.INVOICE_20' || SUBSTR(TAXINVID,2,4);
          -- 打印成功
          IF(upper(OP_TYPE) = 'PRINT') THEN
             EXECUTE IMMEDIATE 'UPDATE ' || TABLENAME || ' SET INVOICE_CODE = ' || INVNO || ', PAY_DATE = to_date(' ||  OP_DATE || ',''YYYYMMDD'' ), STATE = 1,PRINT_COUNT = PRINT_COUNT+1 WHERE PAYMENT_ID = ' || TAXINVID;
          -- 作废退票
          ELSIF(upper(OP_TYPE) = 'CANCEL') THEN
             EXECUTE IMMEDIATE 'UPDATE ' || TABLENAME || ' SET INVOICE_CODE = ' || INVNO || ', PAY_DATE = to_date(' ||  OP_DATE || ',''YYYYMMDD'' ), STATE = 2 WHERE PAYMENT_ID = ' || TAXINVID;
          END IF  ;
     END IF ;
--Exception
--          When Others THEN
--            ROLLBACK ;
    COMMIT;
  END;





/

