create function why(name VARCHAR2) return VARCHAR2 as
  language java name ' InterRMIClient.entry () return java.lang.String ';


/

