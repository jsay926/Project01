create PROCEDURE     p_run_pre_allot AS

BEGIN

insert into so1.crm_act_dtl_sync (SUB_ID, ACC_ID, OLD_SUB_ID, OLD_ACC_ID, CRM_ACT_ID, BUSI_CODE, ORIG_DONE_CODE, DONE_CODE, BUSI_TYPE,
            CHG_TYPE, PRE_FEE, SCHEME_FEE_FLAG, SCHEM_FEE, ALLOT_MONTH, OPER_ID, ORG_ID, VALID_DATE, EXPIRE_DATE, REMARK,
            CREATE_DATE, UPDATE_DATE, STATUS, MULTI_FLAG, EXT1, EXT2, EXT3, EXT4, EXT5, EXT6)
SELECT b.prod_inst_id, b.acct_id, NULL , NULL , c.product_item_id, 121000, NULL , so1.done_code$seq.nextval, 1,
       0, 0, NULL , NULL , 0, NULL , d.organize_id, a.pre_order_date , DATE'2050-01-01', '0',
       a.pre_order_date , a.pre_order_date , 1, NULL ,
       a.cust_code, a.bill_id, a.sub_bill_id, a.prom_name, a.organize_name, a.pre_order_date
FROM so1.tmp_allot_sync a
JOIN so1.ins_prod b ON a.bill_id=b.bill_id AND a.sub_bill_id=b.sub_bill_id
JOIN product.up_product_item c ON a.prom_name=c.name AND c.item_type='OFFER_PLAN'
JOIN sec.sec_organize d ON a.organize_name=d.organize_name
WHERE trunc(a.pre_order_date)=TRUNC(SYSDATE)
AND a.state=0 ;
COMMIT ;

UPDATE so1.tmp_allot_sync t
SET t.state=1
WHERE EXISTS (SELECT 1 FROM so1.crm_act_dtl_sync t1
              WHERE t.cust_code=t1.ext1
                AND t.bill_id=t1.ext2
                AND t.sub_bill_id=t1.ext3
                AND t.prom_name=t1.ext4
                AND t.organize_name=t1.ext5
                AND t.pre_order_date=t1.ext6) ;
COMMIT ;

INSERT INTO zg.crm_act_dtl_sync
SELECT SUB_ID, ACC_ID, OLD_SUB_ID, OLD_ACC_ID, CRM_ACT_ID, BUSI_CODE, ORIG_DONE_CODE, DONE_CODE, BUSI_TYPE,
       CHG_TYPE, PRE_FEE, SCHEME_FEE_FLAG, SCHEM_FEE, ALLOT_MONTH, OPER_ID, ORG_ID, VALID_DATE, EXPIRE_DATE,
       '' REMARK, CREATE_DATE, UPDATE_DATE, STATUS, MULTI_FLAG, '', '', '', '', '', ''
FROM so1.crm_act_dtl_sync
WHERE remark='0';
COMMIT ;

UPDATE so1.crm_act_dtl_sync t
SET t.remark='1'
WHERE EXISTS (SELECT 1 FROM so1.tmp_allot_sync t1
              WHERE t.ext1=t1.cust_code
              AND   t.ext2=t1.bill_id
              AND   t.ext3=t1.sub_bill_id
              AND   t.ext4=t1.prom_name
              AND   t.ext5=t1.organize_name
              AND   t.ext6=t1.pre_order_date) ;
COMMIT ;

END ;
/

