create PROCEDURE       "SELECT_INDEX_COLUMNS" is
  all_columns varchar2(2000);
  cursor c1 is
    select * from index_nouniq_column_num where column_num >= 2; --???????????????
  dummy c1%rowtype;
begin
  open c1;
  fetch c1
    into dummy;
  while c1%found loop
    select getcloumns(dummy.owner, dummy.index_name, dummy.column_num) --??????????
      into all_columns
      from dual;
    insert into index_columns
    values
      (dummy.owner, dummy.index_name, dummy.uniqueness, all_columns); --?????????
    fetch c1
      into dummy;
  end loop;
  commit;
  close c1;
exception
  when others then
    rollback;
end;





/

