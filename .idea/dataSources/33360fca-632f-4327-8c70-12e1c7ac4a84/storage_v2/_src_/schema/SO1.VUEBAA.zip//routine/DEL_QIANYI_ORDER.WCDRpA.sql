create PROCEDURE del_qianyi_order

AS
 cursor vars is  (select cust_order_id from (select distinct( t.cust_id),t.cust_order_id,t1.order_id from so1.ord_busi t left join pboss.SF_ORDER_CUST t1 on t.cust_id=t1.cust_id
    where t.business_id=800001000036) t where exists ( select 1 from  pboss.sf_task_ins s where s.order_id=t.order_id and s.state=3
    and s.task_type_name='外线施工(装)' and s.complete_date is not null));
BEGIN



--------工作流处理

  for cur in vars loop

   UPDATE so1.vm_work_flow t SET t.state='2',t.error_count='',t.error_message='' WHERE vars like '%'||cur.cust_order_id||'%';

   UPDATE so1.vm_task t SET t.state=3
   WHERE workflow_id in (select task_id from so1.vm_work_flow where vars like '%'||cur.cust_order_id||'%') AND task_base_type='user';

   UPDATE so1.vm_schedule t SET t.state='W'
   WHERE workflow_id in (select task_id from so1.vm_work_flow where vars like '%'||cur.cust_order_id||'%');
   
   commit;

  end loop;

   exception
     when others then
       rollback;


end;


/

