create view LDAP_USER as
  (select ip.login_name,ip.password,
decode(sr.state,'1','active','close') dgstate,
decode(ip.state,'1','active','close') state,
ip.prod_inst_id,
ip.own_corp_org_id,
         to_char(sr.done_date,'yyyymmddhhmiss') done_date, to_char(sr.expire_date,'yyyymmddhhmiss') expire_date
           from so1.ins_prod ip, so1.ins_srvpkg sr
          where ip.prod_inst_id = sr.prod_inst_id
            and ip.prod_spec_id = 800200000003
            and ip.access_mode = '4'
            and ip.state = '1')




/

