create PROCEDURE DANG_TEST01_copytable
IS
--v_srvpkg_inst_id  number(16);
begin
   for v_srvpkg_inst_id in (select srvpkg_inst_id from so1.ins_srvpkg t where srvpkg_id=800600000469)loop
     insert into so1.ins_srvpkg_so_id_rel(INS_OFF_ID,INS_SRVPKG_ID,INS_PROD_ID,PROD_ID,SO_ID)
     select INS_OFF_ID,INS_SRVPKG_ID,INS_PROD_ID,10648,test_seq_dr.nextval
     from so1.ins_srvpkg_so_id_rel where ins_srvpkg_id=v_srvpkg_inst_id and rownum=1;
     insert into so1.ins_srvpkg_so_id_rel(INS_OFF_ID,INS_SRVPKG_ID,INS_PROD_ID,PROD_ID,SO_ID)
     select INS_OFF_ID,INS_SRVPKG_ID,INS_PROD_ID,10649,test_seq_dr.nextval
     from so1.ins_srvpkg_so_id_rel where ins_srvpkg_id=v_srvpkg_inst_id and rownum=1;     
     commit;
   end loop;
exception
   when others then
      rollback;
end;




/

