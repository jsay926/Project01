create procedure INSERT_SF_LOG_FAIL as

sqlstr1 varchar2(2000);

begin
  sqlstr1 := 'INSERT INTO SO1.SF_LOG_FAIL
  SELECT *
    FROM PBOSS.SF_ORDER_LOG T
   WHERE T.LOG_ACTION_CODE = ''task_sync''
   -- AND  t.order_id = 28644933
     AND T.REMARK =
         ''工单同步编码：EXCEPTION，工单同步描述：java.net.ConnectException: Connection timed out''
     AND TRUNC(T.STATE_DATE) = TO_DATE(''20170523'', ''yyyymmdd'')';

  --dbms_output.put_line(sqlstr1);
  execute immediate sqlstr1;

end INSERT_SF_LOG_FAIL;
/

