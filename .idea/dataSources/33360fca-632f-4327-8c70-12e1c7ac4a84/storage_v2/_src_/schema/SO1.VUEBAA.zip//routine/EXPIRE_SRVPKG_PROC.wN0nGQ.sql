create PROCEDURE "EXPIRE_SRVPKG_PROC" (v_expire_date In Date) is
  
  --1、查询过期服务包对应上发I表（I_USER_MSC）的数据
  cursor I_USER_MSC_EXPIRE_DATE is
  select t.so_id, t1.expire_date,t1.prod_inst_id
  from zg.I_USER_MSC@zg.domain t, so1.ins_srvpkg t1, product.up_product_item t2, product.up_item_relat t3
  where t1.expire_date <= v_expire_date
  and t.serv_id = t1.prod_inst_id
  and t1.srvpkg_id = t3.product_item_id
  and t3.relat_product_item_id = t2.product_item_id
  and (t3.prod_item_relat_kind_id = 'SERVICE_PRICE_GENERAL_PRICE_PLAN_PKG_BOSS'
  or t3.prod_item_relat_kind_id = 'SERVICE_PRICE_GENERAL_PRICE_PLAN_PKG_BILLING')
  and t.prod_id = t2.extend_id
  and t.offer_inst_id = t1.offer_inst_id
  and t1.state = 1;
  
  --2、查询过期服务包对应上发I表（I_USER_SPROM）的数据
  cursor I_USER_SPROM_EXPIRE_DATE is
  select t.so_id, t1.expire_date,t1.prod_inst_id
  from I_USER_SPROM@zg t, so1.ins_srvpkg t1, product.up_product_item t2, product.up_item_relat t3
  where t1.expire_date <= v_expire_date
  and t.serv_id = t1.prod_inst_id
  and t1.srvpkg_id = t3.product_item_id
  and t3.relat_product_item_id = t2.product_item_id
  and (t3.prod_item_relat_kind_id = 'SERVICE_PRICE_GENERAL_PRICE_PLAN_PKG_BOSS'
  or t3.prod_item_relat_kind_id = 'SERVICE_PRICE_GENERAL_PRICE_PLAN_PKG_BILLING')
  and t.sprom_id = t2.extend_id
  and t.offer_inst_id = t1.offer_inst_id
  and t1.state = 1;

  --3、查询过期服务包对应上发I表（I_USER_PROD_STS）的数据
  cursor I_USER_PROD_STS_EXPIRE_MSC is
  select tt.so_id,tt.valid_date,t1.expire_date,t1.prod_inst_id
  from I_USER_PROD_STS@zg tt, I_USER_MSC@zg t,so1.ins_srvpkg t1, product.up_product_item t2, product.up_item_relat t3
  where t1.expire_date <= v_expire_date
  and t.serv_id = t1.prod_inst_id
  and t1.srvpkg_id = t3.product_item_id
  and t3.relat_product_item_id = t2.product_item_id
  and (t3.prod_item_relat_kind_id = 'SERVICE_PRICE_GENERAL_PRICE_PLAN_PKG_BOSS'
  or t3.prod_item_relat_kind_id = 'SERVICE_PRICE_GENERAL_PRICE_PLAN_PKG_BILLING')
  and t.prod_id = t2.extend_id
  and t.offer_inst_id = t1.offer_inst_id
  and t.so_id = tt.so_id
  and t1.state = 1;

  --4、查询过期服务包对应上发I表（I_USER_PROD_STS）的数据
  cursor I_USER_PROD_STS_EXPIRE_SPROM is
  select tt.so_id,tt.valid_date,t1.expire_date,t1.prod_inst_id
  from I_USER_PROD_STS@zg tt, I_USER_SPROM@zg t,so1.ins_srvpkg t1, product.up_product_item t2, product.up_item_relat t3
  where t1.expire_date <= v_expire_date
  and t.serv_id = t1.prod_inst_id
  and t1.srvpkg_id = t3.product_item_id
  and t3.relat_product_item_id = t2.product_item_id
  and (t3.prod_item_relat_kind_id = 'SERVICE_PRICE_GENERAL_PRICE_PLAN_PKG_BOSS'
  or t3.prod_item_relat_kind_id = 'SERVICE_PRICE_GENERAL_PRICE_PLAN_PKG_BILLING')
  and t.sprom_id = t2.extend_id
  and t.offer_inst_id = t1.offer_inst_id
  and t.so_id = tt.so_id
  and t1.state = 1;
  
  --5、查询过期服务包对应上发I表（I_SPROM_PARAM）的数据
  cursor I_SPROM_PARAM_EXPIRE_MSC is
  select tt.so_id,tt.key_id,tt.valid_date,t1.expire_date,t1.prod_inst_id
  from I_SPROM_PARAM@zg tt, I_USER_MSC@zg t,so1.ins_srvpkg t1, product.up_product_item t2, product.up_item_relat t3
  where t1.expire_date <= v_expire_date
  and t.serv_id = t1.prod_inst_id
  and t1.srvpkg_id = t3.product_item_id
  and t3.relat_product_item_id = t2.product_item_id
  and (t3.prod_item_relat_kind_id = 'SERVICE_PRICE_GENERAL_PRICE_PLAN_PKG_BOSS'
  or t3.prod_item_relat_kind_id = 'SERVICE_PRICE_GENERAL_PRICE_PLAN_PKG_BILLING')
  and t.prod_id = t2.extend_id
  and t.offer_inst_id = t1.offer_inst_id
  and t.so_id = tt.so_id
  and t1.state = 1;  

  --6、查询过期服务包对应上发I表（I_SPROM_PARAM）的数据
  cursor I_SPROM_PARAM_EXPIRE_SPROM is
  select tt.so_id,tt.key_id,tt.valid_date,t1.expire_date,t1.prod_inst_id
  from I_SPROM_PARAM@zg tt, I_USER_SPROM@zg t,so1.ins_srvpkg t1, product.up_product_item t2, product.up_item_relat t3
  where t1.expire_date <= v_expire_date
  and t.serv_id = t1.prod_inst_id
  and t1.srvpkg_id = t3.product_item_id
  and t3.relat_product_item_id = t2.product_item_id
  and (t3.prod_item_relat_kind_id = 'SERVICE_PRICE_GENERAL_PRICE_PLAN_PKG_BOSS'
  or t3.prod_item_relat_kind_id = 'SERVICE_PRICE_GENERAL_PRICE_PLAN_PKG_BILLING')
  and t.sprom_id = t2.extend_id
  and t.offer_inst_id = t1.offer_inst_id
  and t.so_id = tt.so_id
  and t1.state = 1;
  
  --6、查询过期策划实例ID
  cursor INS_OFFER_EXPIRE is
  select t1.offer_inst_id, t1.srvpkg_inst_id, t1.prod_inst_id
  from so1.ins_offer t, so1.ins_srvpkg t1
  where t.offer_inst_id = t1.offer_inst_id
  and t1.expire_date <= v_expire_date
  and t1.state = 1;  
  
  v_count Number;  
  v_done_code_seq Number;
  v_ord_cust_seq Number;
begin
  
  dbms_output.put_line('['||to_char(sysdate,'yyyy-mm-dd hh24:mi:ss')||'] Start.');
  
  --No1.处理I_USER_MSC表数据，把失效日期置为服务包的失效日期
  for my_cur1 in I_USER_MSC_EXPIRE_DATE loop
    update zg.I_USER_MSC@zg.domain
    set expire_date = my_cur1.expire_date
    where so_id = my_cur1.so_id;
    
    select so1.done_code$seq.nextval,so1.ord_cust$seq.nextval
    into v_done_code_seq, v_ord_cust_seq
    from dual;
    
    insert into zg.i_Sale_Oper@zg.domain 
    (SERV_ID, CUST_ID, ACCT_ID, GROUP_ID, UP_FIELD, REGION_CODE, COMMIT_DATE, UP_DATE, DONE_CODE, REMARK, SO_NBR, MDB_TYPE)
    values (my_cur1.prod_inst_id, 0, 0, 0, '00000000000000010000000000000000', 0,sysdate, null, v_done_code_seq, v_ord_cust_seq, '', 1);
    
    --此处也可以单条/分批次提交，避免锁表情况
    if mod(I_USER_MSC_EXPIRE_DATE%rowcount,1000)=0 then
      commit;
      dbms_output.put_line('['||to_char(sysdate,'yyyy-mm-dd hh24:mi:ss')||'] No1.处理I_USER_MSC表数据:'||I_USER_MSC_EXPIRE_DATE%rowcount);
    end if;
  end loop;
  
  dbms_output.put_line('['||to_char(sysdate,'yyyy-mm-dd hh24:mi:ss')||'] No1.处理I_USER_MSC表数据');
  commit;
  
  --No2.处理I_USER_SPROM表数据，把失效日期置为服务包的失效日期
  for my_cur2 in I_USER_SPROM_EXPIRE_DATE loop
    update zg.I_USER_SPROM@zg.domain
    set expire_date = my_cur2.expire_date
    where so_id = my_cur2.so_id;

    select so1.done_code$seq.nextval,so1.ord_cust$seq.nextval
    into v_done_code_seq, v_ord_cust_seq
    from dual;
    
    insert into zg.i_Sale_Oper@zg.domain 
    (SERV_ID, CUST_ID, ACCT_ID, GROUP_ID, UP_FIELD, REGION_CODE, COMMIT_DATE, UP_DATE, DONE_CODE, REMARK, SO_NBR, MDB_TYPE)
    values (my_cur2.prod_inst_id, 0, 0, 0, '01000000000000000000000000000000', 0,sysdate, null, v_done_code_seq, v_ord_cust_seq, '', 1);

    --此处也可以单条/分批次提交，避免锁表情况
    if mod(I_USER_SPROM_EXPIRE_DATE%rowcount,1000)=0 then
      commit;
      dbms_output.put_line('['||to_char(sysdate,'yyyy-mm-dd hh24:mi:ss')||'] No2.处理I_USER_SPROM表数据:'||I_USER_SPROM_EXPIRE_DATE%rowcount);
    end if;
  end loop;  
  
  dbms_output.put_line('['||to_char(sysdate,'yyyy-mm-dd hh24:mi:ss')||']  No2.处理I_USER_SPROM表数据');
  commit;

  --No3.处理I_USER_PROD_STS表数据，把失效日期置为服务包的失效日期
  for my_cur3 in I_USER_PROD_STS_EXPIRE_MSC loop
    update zg.I_USER_PROD_STS@zg.domain
    set expire_date = my_cur3.expire_date
    where so_id = my_cur3.so_id;

    select so1.done_code$seq.nextval,so1.ord_cust$seq.nextval
    into v_done_code_seq, v_ord_cust_seq
    from dual;
    
    insert into zg.i_Sale_Oper@zg.domain 
    (SERV_ID, CUST_ID, ACCT_ID, GROUP_ID, UP_FIELD, REGION_CODE, COMMIT_DATE, UP_DATE, DONE_CODE, REMARK, SO_NBR, MDB_TYPE)
    values (my_cur3.prod_inst_id, 0, 0, 0, '00000000000000000001000000000000', 0,sysdate, null, v_done_code_seq, v_ord_cust_seq, '', 1);

    --此处也可以单条/分批次提交，避免锁表情况
    if mod(I_USER_PROD_STS_EXPIRE_MSC%rowcount,1000)=0 then
      commit;
      dbms_output.put_line('['||to_char(sysdate,'yyyy-mm-dd hh24:mi:ss')||'] No3.处理I_USER_PROD_STS表数据:'||I_USER_PROD_STS_EXPIRE_MSC%rowcount);
    end if;
  end loop;  
  
  dbms_output.put_line('['||to_char(sysdate,'yyyy-mm-dd hh24:mi:ss')||'] No3.处理I_USER_PROD_STS表数据');
  commit;

  --No4.处理I_USER_PROD_STS表数据，把失效日期置为服务包的失效日期
  for my_cur4 in I_USER_PROD_STS_EXPIRE_SPROM loop
    update zg.I_USER_PROD_STS@zg.domain
    set expire_date = my_cur4.expire_date
    where so_id = my_cur4.so_id;

    select so1.done_code$seq.nextval,so1.ord_cust$seq.nextval
    into v_done_code_seq, v_ord_cust_seq
    from dual;
    
    insert into zg.i_Sale_Oper@zg.domain 
    (SERV_ID, CUST_ID, ACCT_ID, GROUP_ID, UP_FIELD, REGION_CODE, COMMIT_DATE, UP_DATE, DONE_CODE, REMARK, SO_NBR, MDB_TYPE)
    values (my_cur4.prod_inst_id, 0, 0, 0, '00000000000000000001000000000000', 0,sysdate, null, v_done_code_seq, v_ord_cust_seq, '', 1);

    --此处也可以单条/分批次提交，避免锁表情况
    if mod(I_USER_PROD_STS_EXPIRE_SPROM%rowcount,1000)=0 then
      commit;
      dbms_output.put_line('['||to_char(sysdate,'yyyy-mm-dd hh24:mi:ss')||'] No4.处理I_USER_PROD_STS表数据:'||I_USER_PROD_STS_EXPIRE_SPROM%rowcount);
    end if;
  end loop;  
  
  dbms_output.put_line('['||to_char(sysdate,'yyyy-mm-dd hh24:mi:ss')||'] No4.处理I_USER_PROD_STS表数据');
  commit;
  
  --No5.处理I_SPROM_PARAM表数据，把失效日期置为服务包的失效日期
  for my_cur5 in I_SPROM_PARAM_EXPIRE_MSC loop
    update zg.I_SPROM_PARAM@zg.domain
    set expire_date = my_cur5.expire_date
    where so_id = my_cur5.so_id;

    select so1.done_code$seq.nextval,so1.ord_cust$seq.nextval
    into v_done_code_seq, v_ord_cust_seq
    from dual;
    
    insert into zg.i_Sale_Oper@zg.domain 
    (SERV_ID, CUST_ID, ACCT_ID, GROUP_ID, UP_FIELD, REGION_CODE, COMMIT_DATE, UP_DATE, DONE_CODE, REMARK, SO_NBR, MDB_TYPE)
    values (my_cur5.prod_inst_id, 0, 0, 0, '00000000000000000000000010000000', 0,sysdate, null, v_done_code_seq, v_ord_cust_seq, '', 1);

    --此处也可以单条/分批次提交，避免锁表情况
    if mod(I_SPROM_PARAM_EXPIRE_MSC%rowcount,1000)=0 then
      commit;
      dbms_output.put_line('['||to_char(sysdate,'yyyy-mm-dd hh24:mi:ss')||'] No5.处理I_SPROM_PARAM表数据:'||I_SPROM_PARAM_EXPIRE_MSC%rowcount);
    end if;
  end loop;  
  
  dbms_output.put_line('['||to_char(sysdate,'yyyy-mm-dd hh24:mi:ss')||'] No5.处理I_SPROM_PARAM表数据');
  commit;

  --No6.处理I_SPROM_PARAM表数据，把失效日期置为服务包的失效日期
  for my_cur6 in I_SPROM_PARAM_EXPIRE_SPROM loop
    update zg.I_SPROM_PARAM@zg.domain
    set expire_date = my_cur6.expire_date
    where so_id = my_cur6.so_id;

    select so1.done_code$seq.nextval,so1.ord_cust$seq.nextval
    into v_done_code_seq, v_ord_cust_seq
    from dual;
    
    insert into zg.i_Sale_Oper@zg.domain 
    (SERV_ID, CUST_ID, ACCT_ID, GROUP_ID, UP_FIELD, REGION_CODE, COMMIT_DATE, UP_DATE, DONE_CODE, REMARK, SO_NBR, MDB_TYPE)
    values (my_cur6.prod_inst_id, 0, 0, 0, '00000000000000000000000010000000', 0,sysdate, null, v_done_code_seq, v_ord_cust_seq, '', 1);

    --此处也可以单条/分批次提交，避免锁表情况
    if mod(I_SPROM_PARAM_EXPIRE_SPROM%rowcount,1000)=0 then
      commit;
      dbms_output.put_line('['||to_char(sysdate,'yyyy-mm-dd hh24:mi:ss')||'] No6.处理I_SPROM_PARAM表数据:'||I_SPROM_PARAM_EXPIRE_SPROM%rowcount);
    end if;
  end loop;   
  
  dbms_output.put_line('['||to_char(sysdate,'yyyy-mm-dd hh24:mi:ss')||'] No6.处理I_SPROM_PARAM表数据');
  commit;
  
  --No7.生成取消CA授权的特殊授权网元指令
  insert into ua.ua_ne_command_call 
  (NE_CMD_CALL_ID, BUSI_CMD_CALL_ID, CUSTOMER_ORDER_ID, PRODUCT_ORDER_ID, DONE_CODE, PRODUCT_INST_ID, NE_COMMAND_ID, BUSI_CMD_CODE, BUSI_CMD_ID, CMD_OBJECT, NE_ID, BUSI_PRIORITY, CMD_ORDER, ORG_ID, COMMAND_CONTENT, CREATE_DATE, CMD_MAX_RETRY_COUNT, DEAL_STATE, CMD_EXEC_DATE, CMD_STATE, CMD_STATUS_INFO, CMD_RETRY_COUNT, CMD_LAST_SEND_DATE, CMD_CONFIRM_DATE, AUTH_OBJECT_NO, PROD_ACT_TYPES, NET_ID, SERVER_FLAG)
  select ua.ua_ne_command_call$seq.nextval, 0, null, null, null, null, 104, ' ', 0, 1, 27, 5, 1, 0, 
  '<?xml version="1.0" encoding="gb2312"?>
  <root>
    <special_busi_type>SAU</special_busi_type>
    <special_auth>
      <iccard_no>'||  bb1.ICCARD ||'</iccard_no>
      <local_codes>' || bb1.authcodes || '</local_codes>
    </special_auth>
  </root>', 
  to_date(to_char(sysdate,'yyyy-mm-dd'), 'yyyy-mm-dd'), null, 0, null, '0', '时间量产品退订特殊授权处理('||to_char(sysdate,'yyyy-MM-dd')||')', null, null, null, bb1.ICCARD, '', 1, null
  from
  (
  select prod.bill_id ICCARD, wmsys.wm_concat(cac.auth_code) authcodes
  from so1.ins_prod prod, so1.ins_srvpkg_ins_srv_rel rel, so1.ins_srv srv, 
       UA.UA_SERVICE_CONTENT_REL scr , UA.UA_NE_CONTENT_AUTH_CODE cac,
  (
  -----短信订购到期用户和服务包
  select pkg.prod_inst_id, pkg.srvpkg_inst_id, pkg.srvpkg_id 
  from so1.ins_srvpkg pkg
  where pkg.expire_date <= v_expire_date
  and   pkg.state = 1
  ) srvpkginst
  where prod.prod_inst_id = srvpkginst.prod_inst_id
  and srvpkginst.srvpkg_inst_id = rel.srvpkg_inst_id
  and rel.srv_inst_id = srv.srv_inst_id
  and srv.service_id = scr.service_id
  and scr.content_id= cac.content_id
  and cac.ne_id = 27
  group by prod.bill_id
  ) bb1;
  
  commit;
  dbms_output.put_line('['||to_char(sysdate,'yyyy-mm-dd hh24:mi:ss')||'] No7.生成取消CA授权的特殊授权网元指令');

  --No8.服务包属性资料表（ins_srv_attr）挪历史
  insert into so1.h_ins_srv_attr_2011 
  select so1.h_ins_srv_attr$seq.nextval, t.* 
  from so1.ins_srv_attr t, so1.ins_srvpkg t1
  where t.srv_inst_id = t1.srvpkg_inst_id
  and t1.expire_date <= v_expire_date
  and (t.attr_type_code = 'ATTR_SRVPKG'
  or t.attr_type_code = 'ATTR_PRICE')  
  and t1.state = 1;
  --删除资料信息
  delete from so1.ins_srv_attr t 
  where EXISTS(
  select t.attr_inst_id from so1.ins_srvpkg t1
  where t.srv_inst_id = t1.srvpkg_inst_id
  and t1.expire_date <= v_expire_date
  and (t.attr_type_code = 'ATTR_SRVPKG'
  or t.attr_type_code = 'ATTR_PRICE')
  and t1.state = 1);
  
  commit;
  dbms_output.put_line('['||to_char(sysdate,'yyyy-mm-dd hh24:mi:ss')||'] No8.服务包属性资料表（ins_srv_attr）挪历史');

  --No9.服务属性资料表（ins_srv_attr）挪历史
  insert into so1.h_ins_srv_attr_2011 
  select so1.h_ins_srv_attr$seq.nextval, t.*
  from so1.ins_srv_attr t, so1.ins_srvpkg t1, so1.ins_srvpkg_ins_srv_rel t2
  where t2.srvpkg_inst_id = t1.srvpkg_inst_id
  and t2.srv_inst_id = t.srv_inst_id
  and t1.expire_date <= v_expire_date
  and t.attr_type_code = 'ATTR_OPEN'
  and t1.state = 1;
  --删除当前数据
  delete from so1.ins_srv_attr t 
  where EXISTS(
  select t.attr_inst_id from so1.ins_srvpkg t1, so1.ins_srvpkg_ins_srv_rel t2
  where t2.srvpkg_inst_id = t1.srvpkg_inst_id
  and t2.srv_inst_id = t.srv_inst_id
  and t1.expire_date <= v_expire_date
  and t.attr_type_code = 'ATTR_OPEN'  
  and t1.state = 1);
  
  commit;
  dbms_output.put_line('['||to_char(sysdate,'yyyy-mm-dd hh24:mi:ss')||'] No9.服务属性资料表（ins_srv_attr）挪历史');
  
  --No10.服务资料表（ins_srv）挪历史
  insert into so1.h_ins_srv_2011
  select so1.h_ins_srv$seq.nextval, t.* 
  from so1.ins_srv t, so1.ins_srvpkg t1, so1.ins_srvpkg_ins_srv_rel t2
  where t2.srvpkg_inst_id = t1.srvpkg_inst_id
  and t2.srv_inst_id = t.srv_inst_id
  and t1.expire_date <= v_expire_date
  and t1.state = 1;
  --删除当前数据
  delete from so1.ins_srv t 
  where EXISTS(
  select t.srv_inst_id from so1.ins_srvpkg t1, so1.ins_srvpkg_ins_srv_rel t2
  where t2.srvpkg_inst_id = t1.srvpkg_inst_id
  and t2.srv_inst_id = t.srv_inst_id
  and t1.expire_date <= v_expire_date
  and t1.state = 1); 
  
  commit;
  dbms_output.put_line('['||to_char(sysdate,'yyyy-mm-dd hh24:mi:ss')||'] No10.服务资料表（ins_srv）挪历史');

  --No11.服务包和服务关系表（ins_srvpkg_ins_srv_rel）挪历史
  insert into so1.h_ins_srvpkg_ins_srv_rel_2011
  select so1.h_ins_srvpkg_ins_srv$seq.nextval, t.* 
  from so1.ins_srvpkg_ins_srv_rel t, so1.ins_srvpkg t1
  where t.srvpkg_inst_id = t1.srvpkg_inst_id
  and t1.expire_date <= v_expire_date
  and t1.state = 1;
  --删除当前数据
  delete from so1.ins_srvpkg_ins_srv_rel t 
  where EXISTS(
  select t.srvpkg_inst_id from so1.ins_srvpkg t1
  where t.srvpkg_inst_id = t1.srvpkg_inst_id
  and t1.expire_date <= v_expire_date
  and t1.state = 1);
  
  commit;   
  dbms_output.put_line('['||to_char(sysdate,'yyyy-mm-dd hh24:mi:ss')||'] No11.服务包和服务关系表（ins_srvpkg_ins_srv_rel）挪历史');
  
  for my_cur7 in INS_OFFER_EXPIRE loop
    
    select count(1) into v_count
    from so1.ins_srvpkg t1
    where t1.offer_inst_id = my_cur7.offer_inst_id
    and (t1.expire_date > v_expire_date
    or t1.state != 1);    
    
    if v_count = 0 then
      --No12.策划资料表（ins_offer）挪历史
      insert into so1.h_ins_offer_2011
      select so1.h_ins_offer$seq.nextval, t.* 
      from so1.ins_offer t
      where t.offer_inst_id =  my_cur7.offer_inst_id;
      --删除当前数据
      delete from so1.ins_offer t 
      where t.offer_inst_id =  my_cur7.offer_inst_id;

      --No13.策划和用户关系资料表（ins_off_ins_prod_rel）挪历史
      insert into so1.h_ins_off_ins_prod_rel_2011
      select so1.h_ins_off_ins_prod$seq.nextval, t.* 
      from so1.ins_off_ins_prod_rel t
      where t.prod_inst_id =  my_cur7.prod_inst_id
      and t.offer_inst_id = my_cur7.offer_inst_id;
      --删除当前数据
      delete from so1.ins_off_ins_prod_rel t 
      where t.prod_inst_id = my_cur7.prod_inst_id
      and t.offer_inst_id = my_cur7.offer_inst_id;

    end if;

    --此处也可以单条/分批次提交，避免锁表情况
    if mod(INS_OFFER_EXPIRE%rowcount,500)=0 then
      commit;
      dbms_output.put_line('['||to_char(sysdate,'yyyy-mm-dd hh24:mi:ss')||'] No12.策划资料表（ins_offer）挪历史'||INS_OFFER_EXPIRE%rowcount);
      dbms_output.put_line('['||to_char(sysdate,'yyyy-mm-dd hh24:mi:ss')||'] No13.策划和用户关系资料表（ins_off_ins_prod_rel）挪历史'||INS_OFFER_EXPIRE%rowcount);
    end if;    
    
  end loop;
  
  commit;     
  dbms_output.put_line('['||to_char(sysdate,'yyyy-mm-dd hh24:mi:ss')||'] No12.策划资料表（ins_offer）挪历史');
  dbms_output.put_line('['||to_char(sysdate,'yyyy-mm-dd hh24:mi:ss')||'] No13.策划和用户关系资料表（ins_off_ins_prod_rel）挪历史');

  --No14.服务包资料表（ins_srvpkg）挪历史
  insert into so1.h_ins_srvpkg_2011
  select so1.h_ins_srvpkg$seq.nextval, t.* 
  from so1.ins_srvpkg t
  where t.expire_date <= v_expire_date
  and t.state = 1;
  --删除当前数据
  delete from so1.ins_srvpkg t 
  where t.expire_date <= v_expire_date
  and t.state = 1;
  
  commit;
  
  dbms_output.put_line('['||to_char(sysdate,'yyyy-mm-dd hh24:mi:ss')||'] No14.服务包资料表（ins_srvpkg）挪历史');
  
dbms_output.put_line('['||to_char(sysdate,'yyyy-mm-dd hh24:mi:ss')||'] End!');
 
end EXPIRE_SRVPKG_PROC;






/

