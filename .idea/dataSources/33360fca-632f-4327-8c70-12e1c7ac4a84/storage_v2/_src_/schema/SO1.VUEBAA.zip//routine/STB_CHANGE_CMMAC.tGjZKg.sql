create procedure     stb_change_cmmac(stb_id  in varchar2,cmmac in varchar2 ,v_message out varchar2) 
 as
v_stb_id varchar2(40) ;
v_cmmac varchar2(20);
v_state   varchar2(2);
cout   number ;
begin
select rt.serial_no , rt.state  ,rt.cmmac  into v_stb_id, v_state , v_cmmac  from res.res_terminal  rt where rt.serial_no =stb_id;
select count(*) into cout from res.res_terminal  rt where rt.cmmac =cmmac and rt.serial_no<>stb_id ;
/*修改已经绑定用户的机顶盒号*/
if (V_cmmac<>cmmac and cout=0 and v_state=3 ) then

 update res.res_terminal  rt  set rt.cmmac=cmmac where rt.serial_no =stb_id ;
 update so1.ins_prod_res pr set pr.res_equ_no2=cmmac where pr.res_equ_no =stb_id;
  insert into so1.BAT_AUTHOR_TMP 
select  so1.bat_author_tmp$seq.nextval,null,null,p.cust_id,null,0,0,p.prod_inst_id,sysdate ,2,222,2001,0,null
from so1.ins_prod p where p.bill_id=stb_id;
commit;
--DBMS_OUTPUT.put_line('机顶盒mac已经修改，并对用户进行了刷新授权');
v_message:='机顶盒mac已经修改，并对用户进行了刷新授权';
 /*修改没有绑定用户的机顶盒号*/
else if (V_cmmac<>cmmac and cout=0 and v_state<>3 ) then
 update res.res_terminal  rt  set rt.cmmac=cmmac where rt.serial_no =stb_id ;
-- update so1.ins_prod_res pr set pr.res_equ_no2=cmmac where pr.res_equ_no =stb_id;
-- DBMS_OUTPUT.put_line('机顶盒mac已经修改,该机顶盒上没有用户');
v_message:='机顶盒mac已经修改,该机顶盒上没有用户';
 commit;
  else if (v_stb_id is null) then
--DBMS_OUTPUT.put_line('机顶盒不存在');
v_message:='机顶盒不存在';
  else if (cout>0) then
--DBMS_OUTPUT.put_line('机顶盒对应的mac已经存在');
v_message:='该cmmac已经存在其他机顶盒上';

 end if ;
 end if;
 end if;
 end if;
 end;




/

