create PROCEDURE     queryStdAddrCode(stdAddrId  in varchar2,
                                          stdAddrCode out varchar2) IS
     TYPE emp_ssn_array IS TABLE OF NUMBER INDEX BY BINARY_INTEGER;
     stdAddrIds  emp_ssn_array;
     indexNum number;
    cursor cur_proc is
         SELECT rownum, t.* FROM pboss.ADDR_STD_ADDR t
            START WITH t.STD_ADDR_ID = stdAddrId
          CONNECT BY PRIOR t.PARENT_ADDR_ID = t.STD_ADDR_ID;
BEGIN
            for std in cur_proc loop
                 stdAddrIds(std.rownum) :=std.STD_ADDR_ID;
              end loop;
              indexNum :=stdAddrIds.count;
              if indexNum >0 then
              stdAddrCode  := stdAddrIds(indexNum);
              indexNum :=indexNum-1;
             while indexNum >=1
               loop
                  stdAddrCode  := stdAddrCode ||'-'|| stdAddrIds(indexNum);
                   DBMS_OUTPUT.PUT_LINE(stdAddrIds(indexNum));
                   indexNum :=indexNum-1;
             END LOOP;
             end if;
end queryStdAddrCode;


/

