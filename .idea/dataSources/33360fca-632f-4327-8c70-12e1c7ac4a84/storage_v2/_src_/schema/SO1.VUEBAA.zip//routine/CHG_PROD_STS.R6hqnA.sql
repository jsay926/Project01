create PROCEDURE       "CHG_PROD_STS" (
                                      v_prod_inst_id In Number
                                      ,v_status         In Number
                                      ,v_os_status    In Varchar2
                                     )
       Is
      v_result Varchar2(50);
      -- v_status : 1????2????3???
      --v_os_status: 1??????2?????3??????4?????5???
      v_prod_status Varchar2(2);
      v_offer_status Number(1);
      v_srvpkg_status Number(2);
      v_serv_status Number;
Begin
      so1.pro_prod_sts( v_status => v_status
                                 ,v_prod_status   =>v_prod_status
                                 ,v_offer_status   =>v_offer_status
                                 ,v_srvpkg_status => v_srvpkg_status
                                 ,v_serv_status     => v_serv_status
                                );

    Update so1.ins_prod prod Set prod.state=v_prod_status,prod.os_status=''
    Where prod.prod_inst_id=v_prod_inst_id;
    Commit;
    Update so1.ins_off_ins_prod_rel rel Set rel.state=v_offer_status
    Where rel.prod_inst_id=v_prod_inst_id;
    Commit;
    Update so1.ins_offer offer Set offer.state=v_offer_status
    Where Exists (Select 1 From so1.ins_off_ins_prod_rel rel
        Where rel.offer_inst_id=offer.offer_inst_id And rel.prod_inst_id=v_prod_inst_id);
    Commit;
    Update so1.ins_srvpkg pkg Set pkg.state=decode(v_srvpkg_status,0,pkg.state,v_srvpkg_status),pkg.os_status=v_os_status
    Where pkg.prod_inst_id=v_prod_inst_id;
    Commit;
    Update so1.ins_srvpkg_ins_srv_rel rel Set rel.state=decode(v_srvpkg_status,0,rel.state,v_srvpkg_status)
    Where rel.prod_inst_id=v_prod_inst_id;
    Commit;
    Update so1.ins_srv srv Set srv.state=decode(v_srvpkg_status,0,srv.state,v_srvpkg_status)
    Where srv.prod_inst_id=v_prod_inst_id;
    Commit;
    so1.chg_serv_sts(v_prod_inst_id,v_serv_status);
    dbms_output.put_line('????');
Exception
          When Others Then
               v_result:='??ID: '||v_prod_inst_id||' ??????(crm?)';
               Insert Into so1.pro_log Values(so1.error_msg_seq.nextval,v_result,Sysdate);
               Commit;
End;





/

