create view BOSS2UA as
  select e.ne_name,e.ne_id,o.organize_name from ua.ua_ne_send_rel r,ua.ua_net_elements e ,sec.sec_organize o
 where r.ne_id = e.ne_id and r.org_id = o.organize_id and e.ne_state =1  order by e.ne_name


/

