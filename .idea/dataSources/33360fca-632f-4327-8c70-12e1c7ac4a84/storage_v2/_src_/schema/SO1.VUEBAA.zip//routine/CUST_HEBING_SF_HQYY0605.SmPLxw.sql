create procedure     cust_hebing_sf_hqyy0605
as
 cursor old_cur_value is select t.prod_inst_id from so1.ins_prod_bak_hqyy0605 t;
 new_cru_value  old_cur_value%rowtype;
begin
  open old_cur_value;
  loop fetch old_cur_value into new_cru_value;
       exit when old_cur_value%notfound;
  insert into zg.i_sale_oper
      select  new_cru_value.prod_inst_id,0,0,0,'11111111111111111111111111111111',514,sysdate,null,0 ,null,0 ,1 from dual t ;
  end loop;
  commit;
  close old_cur_value;
end cust_hebing_sf_hqyy0605;


/

