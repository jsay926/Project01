create view I_SALE_OPER as
  select "SERV_ID","CUST_ID","ACCT_ID","GROUP_ID","UP_FIELD","REGION_CODE","COMMIT_DATE","UP_DATE","DONE_CODE","REMARK","SO_NBR","MDB_TYPE" from    zg.I_SALE_OPER@zg.domain





/

