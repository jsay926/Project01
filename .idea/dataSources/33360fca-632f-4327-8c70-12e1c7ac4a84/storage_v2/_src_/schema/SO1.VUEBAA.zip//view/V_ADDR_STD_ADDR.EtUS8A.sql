create view V_ADDR_STD_ADDR as
  select a.std_addr_id, a.std_addr_type, a.detail_name, a.district_id,a.parent_addr_id
  from pboss.ADDR_STD_ADDR a
 WHERE A.STATE = 1




/

