create PROCEDURE     queryOfferInfo(flag  in  number,p_CURSOR out so1.QUERY_OFFER_PACKAGE.query_offer_cursor) IS
BEGIN
 IF flag=1 THEN
  OPEN p_CURSOR FOR
  select b.offer_id,
       a.name offer_name,
        a.description,
       ca.catalog_name,
       b.offer_type offer_kind,
       a.use_eff_date,
       a.use_exp_date,
       c.catalog_id
  from product.up_product_item      a,
       product.up_offer             b,
       product.up_item_catalog      c,
       product.UP_PROD_ITEM_CATALOG ca
 where c.product_item_id = a.product_item_id
   and a.product_item_id = b.offer_id
   and c.catalog_id = ca.catalog_id
   and sysdate between a.use_eff_date and a.use_exp_date
   and a.state = '5'
   and a.del_flag = '0'
   and b.del_flag = '0'
   and c.del_flag = '0'
 order by c.catalog_id, a.name ;
END IF;

 if flag=0  then
   OPEN p_CURSOR FOR
    select b.offer_id,
        a.name offer_name,
        a.description,
        ca.catalog_name,
        b.offer_type offer_kind,
        a.use_eff_date,
        a.use_exp_date,
        c.catalog_id
   from product.up_product_item      a,
        product.up_offer             b,
        product.up_item_catalog      c,
        product.UP_PROD_ITEM_CATALOG ca
  where c.product_item_id = a.product_item_id
    and a.product_item_id = b.offer_id
    and c.catalog_id = ca.catalog_id
    and a.product_item_id not in
        (select a2.product_item_id
           from product.up_product_item      a2,
                product.up_offer             b2,
                product.up_item_catalog      c2,
                product.UP_PROD_ITEM_CATALOG ca2
          where c2.product_item_id = a2.product_item_id
            and a2.product_item_id = b2.offer_id
            and c2.catalog_id = ca2.catalog_id
            and sysdate between a2.use_eff_date and a2.use_exp_date
            and a2.state = '5'
            and a2.del_flag = '0'
            and b2.del_flag = '0'
            and c2.del_flag = '0')
  order by c.catalog_id, a.name ;
 end if;
end queryOfferInfo;


/

