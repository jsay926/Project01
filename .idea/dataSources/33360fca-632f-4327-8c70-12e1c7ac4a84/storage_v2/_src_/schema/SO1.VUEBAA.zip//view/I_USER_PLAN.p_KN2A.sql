create view I_USER_PLAN as
  select "SERV_ID","PLAN_ID","REGION_CODE","VALID_DATE","EXPIRE_DATE","DONE_CODE","SO_NBR","REMARK" from    zg.I_USER_PLAN@zg.domain





/

