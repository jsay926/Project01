create view CRM_TOTAL_11 as
  select t1.cycle_id || '_' || 10001 id, 10001 code, t1.cycle_id cycle, '????' type1, '' type2, '' type3,'' type4,'????'  name, t1.pt_new-t2.pt_new value
  from so1.rpt_day_org t1,so1.rpt_day_org t2
  where t2.org_id= t1.org_id
  and t2.cycle_id = to_char(to_date(t1.cycle_id,'yyyymmdd')-1,'yyyymmdd')
  and t1.org_id = 502
union all
select  t1.cycle_id || '_' || 10002 id,10002 code, t1.cycle_id cycle, '????' type1, '' type2, '' type3,'' type4,'????'  name, t1.hd_new-t2.hd_new value
  from so1.rpt_day_org t1,so1.rpt_day_org t2
  where t2.org_id= t1.org_id
  and t2.cycle_id = to_char(to_date(t1.cycle_id,'yyyymmdd')-1,'yyyymmdd')
  and t1.org_id = 502
union all
select  t1.cycle_id || '_' || 10003 id,10003 code, t1.cycle_id cycle, '??????' type1, '' type2, '' type3,'' type4,'????'  name, t1.gqhd_new-t2.gqhd_new value
  from so1.rpt_day_org t1,so1.rpt_day_org t2
  where t2.org_id= t1.org_id
  and t2.cycle_id = to_char(to_date(t1.cycle_id,'yyyymmdd')-1,'yyyymmdd')
  and t1.org_id = 502

union all
select  t1.cycle_id || '_' || 10004 id,10004 code, t1.cycle_id cycle, '????' type1, '' type2, '' type3,'' type4,'????'  name, t1.gq_new-t2.gq_new value
  from so1.rpt_day_org t1,so1.rpt_day_org t2
  where t2.org_id= t1.org_id
  and t2.cycle_id = to_char(to_date(t1.cycle_id,'yyyymmdd')-1,'yyyymmdd')
  and t1.org_id = 502
union all
select  t1.cycle_id || '_' || 10005 id,10005 code, t1.cycle_id cycle, '????' type1, '' type2, '' type3,'' type4,'????'  name, t1.pt_transfer-t2.pt_transfer value
  from so1.rpt_day_org t1,so1.rpt_day_org t2
  where t2.org_id= t1.org_id
  and t2.cycle_id = to_char(to_date(t1.cycle_id,'yyyymmdd')-1,'yyyymmdd')
  and t1.org_id = 502
union all
select  t1.cycle_id || '_' || 10006 id,10006 code, t1.cycle_id cycle, '????' type1, '' type2, '' type3,'' type4,'????'  name, t1.hd_transfer-t2.hd_transfer value
  from so1.rpt_day_org t1,so1.rpt_day_org t2
  where t2.org_id= t1.org_id
  and t2.cycle_id = to_char(to_date(t1.cycle_id,'yyyymmdd')-1,'yyyymmdd')
  and t1.org_id = 502
union all
select  t1.cycle_id || '_' || 10007 id,10007 code, t1.cycle_id cycle, '??????' type1, '' type2, '' type3,'' type4,'??????'  name, t1.gqhd_transfer-t2.gqhd_transfer value
  from so1.rpt_day_org t1,so1.rpt_day_org t2
  where t2.org_id= t1.org_id
  and t2.cycle_id = to_char(to_date(t1.cycle_id,'yyyymmdd')-1,'yyyymmdd')
  and t1.org_id = 502
union all
select  t1.cycle_id || '_' || 10008 id,10008 code, t1.cycle_id cycle, '????' type1, '' type2, '' type3,'' type4,'????'  name, t1.gq_transfer -t2.gq_transfer value
  from so1.rpt_day_org t1,so1.rpt_day_org t2
  where t2.org_id= t1.org_id
  and t2.cycle_id = to_char(to_date(t1.cycle_id,'yyyymmdd')-1,'yyyymmdd')
  and t1.org_id = 502
union all
select  t1.cycle_id || '_' || 10009 id,10009 code, t1.cycle_id cycle, '????' type1, '' type2, '' type3,'' type4,'????'  name, t1.pt_de-t2.pt_de value
  from so1.rpt_day_org t1,so1.rpt_day_org t2
  where t2.org_id= t1.org_id
  and t2.cycle_id = to_char(to_date(t1.cycle_id,'yyyymmdd')-1,'yyyymmdd')
  and t1.org_id = 502
union all
select  t1.cycle_id || '_' || 10010 id,10010 code, t1.cycle_id cycle, '????' type1, '' type2, '' type3,'' type4,'????'  name, t1.hd_de-t2.hd_de  value
  from so1.rpt_day_org t1,so1.rpt_day_org t2
  where t2.org_id= t1.org_id
  and t2.cycle_id = to_char(to_date(t1.cycle_id,'yyyymmdd')-1,'yyyymmdd')
  and t1.org_id = 502
union all
select  t1.cycle_id || '_' || 10011 id,10011 code, t1.cycle_id cycle, '??????' type1, '' type2, '' type3,'' type4,'??????'  name, t1.gqhd_de-t2.gqhd_de value
  from so1.rpt_day_org t1,so1.rpt_day_org t2
  where t2.org_id= t1.org_id
  and t2.cycle_id = to_char(to_date(t1.cycle_id,'yyyymmdd')-1,'yyyymmdd')
  and t1.org_id = 502
union all
select  t1.cycle_id || '_' || 10012 id,10012 code, t1.cycle_id cycle, '????' type1, '' type2, '' type3,'' type4,'????'  name, t1.gq_de-t2.gq_de  value
  from so1.rpt_day_org t1,so1.rpt_day_org t2
  where t2.org_id= t1.org_id
  and t2.cycle_id = to_char(to_date(t1.cycle_id,'yyyymmdd')-1,'yyyymmdd')
  and t1.org_id = 502
union all
select  t1.cycle_id || '_' || 10013 id,10013 code, t1.cycle_id cycle, '????' type1, '' type2, '' type3,'' type4,'????'  name, t1.pt_relay-t2.pt_relay value
  from so1.rpt_day_org t1,so1.rpt_day_org t2
  where t2.org_id= t1.org_id
  and t2.cycle_id = to_char(to_date(t1.cycle_id,'yyyymmdd')-1,'yyyymmdd')
  and t1.org_id = 502
  union all
select  t1.cycle_id || '_' || 10014 id,10014 code, t1.cycle_id cycle, '????' type1, '' type2, '' type3,'' type4,'????'  name, t1.hd_relay-t2.hd_relay  value
  from so1.rpt_day_org t1,so1.rpt_day_org t2
  where t2.org_id= t1.org_id
  and t2.cycle_id = to_char(to_date(t1.cycle_id,'yyyymmdd')-1,'yyyymmdd')
  and t1.org_id = 502
  union all
select  t1.cycle_id || '_' || 10015 id,10015 code, t1.cycle_id cycle, '??????' type1, '' type2, '' type3,'' type4,'??????'  name, t1.gqhd_relay -t2.gqhd_relay value
  from so1.rpt_day_org t1,so1.rpt_day_org t2
  where t2.org_id= t1.org_id
  and t2.cycle_id = to_char(to_date(t1.cycle_id,'yyyymmdd')-1,'yyyymmdd')
  and t1.org_id = 502
  union all
select  t1.cycle_id || '_' || 10016 id,10016 code, t1.cycle_id cycle, '????' type1, '' type2, '' type3,'' type4,'????'  name, t1.gq_relay-t2.gq_relay value
  from so1.rpt_day_org t1,so1.rpt_day_org t2
  where t2.org_id= t1.org_id
  and t2.cycle_id = to_char(to_date(t1.cycle_id,'yyyymmdd')-1,'yyyymmdd')
  and t1.org_id = 502
  union all
select  t1.cycle_id || '_' || 10017 id,10017 code, t1.cycle_id cycle, '????' type1, '' type2, '' type3,'' type4,'????'  name, t1.cu_pt-t2.cu_pt value
  from so1.rpt_day_org t1,so1.rpt_day_org t2
  where t2.org_id= t1.org_id
  and t2.cycle_id = to_char(to_date(t1.cycle_id,'yyyymmdd')-1,'yyyymmdd')
  and t1.org_id = 502
  union all
select  t1.cycle_id || '_' || 10018 id,10018 code, t1.cycle_id cycle, '????' type1, '' type2, '' type3,'' type4,'????'  name, t1.cu_gq-t2.cu_gq  value
  from so1.rpt_day_org t1,so1.rpt_day_org t2
  where t2.org_id= t1.org_id
  and t2.cycle_id = to_char(to_date(t1.cycle_id,'yyyymmdd')-1,'yyyymmdd')
  and t1.org_id = 502
  union all
select  t1.cycle_id || '_' || 10019 id,10019 code, t1.cycle_id cycle, '????' type1, '' type2, '' type3,'' type4,'????'  name, t1.cu_hd-t2.cu_hd value
  from so1.rpt_day_org t1,so1.rpt_day_org t2
  where t2.org_id= t1.org_id
  and t2.cycle_id = to_char(to_date(t1.cycle_id,'yyyymmdd')-1,'yyyymmdd')
  and t1.org_id = 502
  union all
select  t1.cycle_id || '_' || 10020 id,10020 code, t1.cycle_id cycle, '??????' type1, '' type2, '' type3,'' type4,'??????'  name, t1.cu_gqhd-t2.cu_gqhd  value
  from so1.rpt_day_org t1,so1.rpt_day_org t2
  where t2.org_id= t1.org_id
  and t2.cycle_id = to_char(to_date(t1.cycle_id,'yyyymmdd')-1,'yyyymmdd')
  and t1.org_id = 502
  union all
select  t1.cycle_id || '_' || 10021 id,10021 code, t1.cycle_id cycle, '?????????' type1, '' type2, '' type3,'' type4,'?????????'  name, t1.gqhd_add_sub- t2.gqhd_add_sub value
  from so1.rpt_day_org t1,so1.rpt_day_org t2
  where t2.org_id= t1.org_id
  and t2.cycle_id = to_char(to_date(t1.cycle_id,'yyyymmdd')-1,'yyyymmdd')
  and t1.org_id = 502
  union all
select  t1.cycle_id || '_' || 10022 id,10022 code, t1.cycle_id cycle, '?????????' type1, '' type2, '' type3,'' type4,'?????????'  name, t1.gqhd_cancel_sub-t2.gqhd_cancel_sub  value
  from so1.rpt_day_org t1,so1.rpt_day_org t2
  where t2.org_id= t1.org_id
  and t2.cycle_id = to_char(to_date(t1.cycle_id,'yyyymmdd')-1,'yyyymmdd')
  and t1.org_id = 502
  union all
select  t1.cycle_id || '_' || 10023 id,10023 code, t1.cycle_id cycle, '????????' type1, '' type2, '' type3,'' type4,'????????'  name, t1.gqhd_sub-t2.gqhd_sub value
  from so1.rpt_day_org t1,so1.rpt_day_org t2
  where t2.org_id= t1.org_id
  and t2.cycle_id = to_char(to_date(t1.cycle_id,'yyyymmdd')-1,'yyyymmdd')
  and t1.org_id = 502
  union all
select  t1.cycle_id || '_' || 10024 id,10024 code, t1.cycle_id cycle, '???????' type1, '' type2, '' type3,'' type4,'???????'  name, t1.gq_add_sub-t2.gq_add_sub  value
  from so1.rpt_day_org t1,so1.rpt_day_org t2
  where t2.org_id= t1.org_id
  and t2.cycle_id = to_char(to_date(t1.cycle_id,'yyyymmdd')-1,'yyyymmdd')
  and t1.org_id = 502
  union all
select  t1.cycle_id || '_' || 10025 id,10025 code, t1.cycle_id cycle, '???????' type1, '' type2, '' type3,'' type4,'???????'  name, t1.gq_cancel_sub-t2.gq_cancel_sub value
  from so1.rpt_day_org t1,so1.rpt_day_org t2
  where t2.org_id= t1.org_id
  and t2.cycle_id = to_char(to_date(t1.cycle_id,'yyyymmdd')-1,'yyyymmdd')
  and t1.org_id = 502
  union all
select  t1.cycle_id || '_' || 10026 id,10026 code, t1.cycle_id cycle, '??????' type1, '' type2, '' type3,'' type4,'??????'  name, t1.gq_sub-t2.gq_sub value
  from so1.rpt_day_org t1,so1.rpt_day_org t2
  where t2.org_id= t1.org_id
  and t2.cycle_id = to_char(to_date(t1.cycle_id,'yyyymmdd')-1,'yyyymmdd')
  and t1.org_id = 502
  union all
select  t1.cycle_id || '_' || 10027 id,10027 code, t1.cycle_id cycle, '?????????' type1, '' type2, '' type3,'' type4,'?????????'  name, t1.hd_add_sub-t2.hd_add_sub  value
  from so1.rpt_day_org t1,so1.rpt_day_org t2
  where t2.org_id= t1.org_id
  and t2.cycle_id = to_char(to_date(t1.cycle_id,'yyyymmdd')-1,'yyyymmdd')
  and t1.org_id = 502
  union all
select  t1.cycle_id || '_' || 10028 id,10028 code, t1.cycle_id cycle, '?????????' type1, '' type2, '' type3,'' type4,'?????????'  name, t1.hd_cancel_sub-t2.hd_cancel_sub value
  from so1.rpt_day_org t1,so1.rpt_day_org t2
  where t2.org_id= t1.org_id
  and t2.cycle_id = to_char(to_date(t1.cycle_id,'yyyymmdd')-1,'yyyymmdd')
  and t1.org_id = 502
  union all
select  t1.cycle_id || '_' || 10029 id,10029 code, t1.cycle_id cycle, '????????' type1, '' type2, '' type3,'' type4,'????????'  name, t1.hd_sub-t2.hd_sub  value
  from so1.rpt_day_org t1,so1.rpt_day_org t2
  where t2.org_id= t1.org_id
  and t2.cycle_id = to_char(to_date(t1.cycle_id,'yyyymmdd')-1,'yyyymmdd')
  and t1.org_id = 502
  union all
select  t1.cycle_id || '_' || 10030 id,10030 code, t1.cycle_id cycle, '?????????' type1, '' type2, '' type3,'' type4,'?????????'  name, t1.dtv_add_sub-t2.dtv_add_sub value
  from so1.rpt_day_org t1,so1.rpt_day_org t2
  where t2.org_id= t1.org_id
  and t2.cycle_id = to_char(to_date(t1.cycle_id,'yyyymmdd')-1,'yyyymmdd')
  and t1.org_id = 502
  union all
select  t1.cycle_id || '_' || 10031 id,10031 code, t1.cycle_id cycle, '?????????' type1, '' type2, '' type3,'' type4,'?????????'  name, t1.dtv_cancel_sub-t2.dtv_cancel_sub value
  from so1.rpt_day_org t1,so1.rpt_day_org t2
  where t2.org_id= t1.org_id
  and t2.cycle_id = to_char(to_date(t1.cycle_id,'yyyymmdd')-1,'yyyymmdd')
  and t1.org_id = 502
 union all
select  t1.cycle_id || '_' || 10032 id,10032 code, t1.cycle_id cycle, '????????' type1, '' type2, '' type3,'' type4,'????????'  name, t1.dtv_sub-t2.dtv_sub value
  from so1.rpt_day_org t1,so1.rpt_day_org t2
  where t2.org_id= t1.org_id
  and t2.cycle_id = to_char(to_date(t1.cycle_id,'yyyymmdd')-1,'yyyymmdd')
  and t1.org_id = 502
 union all
select  t1.cycle_id || '_' || 10033 id,10033 code, t1.cycle_id cycle, '?????????' type1, '' type2, '' type3,'' type4,'?????????'  name, t1.analog_add_sub-t2.analog_add_sub value
  from so1.rpt_day_org t1,so1.rpt_day_org t2
  where t2.org_id= t1.org_id
  and t2.cycle_id = to_char(to_date(t1.cycle_id,'yyyymmdd')-1,'yyyymmdd')
  and t1.org_id = 502
 union all
select  t1.cycle_id || '_' || 10034 id,10034 code, t1.cycle_id cycle, '?????????' type1, '' type2, '' type3,'' type4,'?????????'  name, t1.analog_cancel_sub-t2.analog_cancel_sub value
  from so1.rpt_day_org t1,so1.rpt_day_org t2
  where t2.org_id= t1.org_id
  and t2.cycle_id = to_char(to_date(t1.cycle_id,'yyyymmdd')-1,'yyyymmdd')
  and t1.org_id = 502
 union all
select  t1.cycle_id || '_' || 10035 id,10035 code, t1.cycle_id cycle, '????????' type1, '' type2, '' type3,'' type4,'????????'  name, t1.analog_sub- t2.analog_sub  value
  from so1.rpt_day_org t1,so1.rpt_day_org t2
  where t2.org_id= t1.org_id
  and t2.cycle_id = to_char(to_date(t1.cycle_id,'yyyymmdd')-1,'yyyymmdd')
  and t1.org_id = 502
 union all
select  t1.cycle_id || '_' || 10036 id,10036 code, t1.cycle_id cycle, '???????' type1, '' type2, '' type3,'' type4,'???????'  name, t1.card1_amount-t2.card1_amount value
  from so1.rpt_day_org t1,so1.rpt_day_org t2
  where t2.org_id= t1.org_id
  and t2.cycle_id = to_char(to_date(t1.cycle_id,'yyyymmdd')-1,'yyyymmdd')
  and t1.org_id = 502
 union all
select  t1.cycle_id || '_' || 10037 id,10037 code, t1.cycle_id cycle, '???????' type1, '' type2, '' type3,'' type4,'???????'  name, t1.card2_amount-t2.card2_amount value
  from so1.rpt_day_org t1,so1.rpt_day_org t2
  where t2.org_id= t1.org_id
  and t2.cycle_id = to_char(to_date(t1.cycle_id,'yyyymmdd')-1,'yyyymmdd')
  and t1.org_id = 502
 union all
select  t1.cycle_id || '_' || 10038 id,10038 code, t1.cycle_id cycle, '??VIP?????' type1, '' type2, '' type3,'' type4,'??VIP?????'  name, t1.hd_card_count-t2.hd_card_count  value
  from so1.rpt_day_org t1,so1.rpt_day_org t2
  where t2.org_id= t1.org_id
  and t2.cycle_id = to_char(to_date(t1.cycle_id,'yyyymmdd')-1,'yyyymmdd')
  and t1.org_id = 502
 union all
select  t1.cycle_id || '_' || 10039 id,10039 code, t1.cycle_id cycle, '????VIP????' type1, '' type2, '' type3,'' type4,'????VIP????'  name, t1.gqhd_card_count-t2.gqhd_card_count value
  from so1.rpt_day_org t1,so1.rpt_day_org t2
  where t2.org_id= t1.org_id
  and t2.cycle_id = to_char(to_date(t1.cycle_id,'yyyymmdd')-1,'yyyymmdd')
  and t1.org_id = 502
 union all
select  t1.cycle_id || '_' || 10040 id,10040 code, t1.cycle_id cycle, '???????????' type1, '' type2, '' type3,'' type4,'???????????'  name, t1.channel_add_sub1- t2.channel_add_sub1  value
  from so1.rpt_day_org t1,so1.rpt_day_org t2
  where t2.org_id= t1.org_id
  and t2.cycle_id = to_char(to_date(t1.cycle_id,'yyyymmdd')-1,'yyyymmdd')
  and t1.org_id = 502
 union all
select  t1.cycle_id || '_' || 10041 id,10041 code, t1.cycle_id cycle, '???????????' type1, '' type2, '' type3,'' type4,'???????????'  name, t1.channel_cancel_sub1-t2.channel_cancel_sub1  value
  from so1.rpt_day_org t1,so1.rpt_day_org t2
  where t2.org_id= t1.org_id
  and t2.cycle_id = to_char(to_date(t1.cycle_id,'yyyymmdd')-1,'yyyymmdd')
  and t1.org_id = 502
 union all
select  t1.cycle_id || '_' || 10042 id,10042 code, t1.cycle_id cycle, '??????????' type1, '' type2, '' type3,'' type4,'??????????'  name, t1.channel_sub1-t2.channel_cancel_sub1  value
  from so1.rpt_day_org t1,so1.rpt_day_org t2
  where t2.org_id= t1.org_id
  and t2.cycle_id = to_char(to_date(t1.cycle_id,'yyyymmdd')-1,'yyyymmdd')
  and t1.org_id = 502
 union all
select  t1.cycle_id || '_' || 10043 id,10043 code, t1.cycle_id cycle, '???????????' type1, '' type2, '' type3,'' type4,'???????????'  name, t1.channel_add_sub2-t2.channel_add_sub2 value
  from so1.rpt_day_org t1,so1.rpt_day_org t2
  where t2.org_id= t1.org_id
  and t2.cycle_id = to_char(to_date(t1.cycle_id,'yyyymmdd')-1,'yyyymmdd')
  and t1.org_id = 502
 union all
select  t1.cycle_id || '_' || 10044 id,10044 code, t1.cycle_id cycle, '???????????' type1, '' type2, '' type3,'' type4,'???????????'  name, t1.channel_cancel_sub2-t2.channel_cancel_sub2 value
  from so1.rpt_day_org t1,so1.rpt_day_org t2
  where t2.org_id= t1.org_id
  and t2.cycle_id = to_char(to_date(t1.cycle_id,'yyyymmdd')-1,'yyyymmdd')
  and t1.org_id = 502
 union all
select  t1.cycle_id || '_' || 10045 id,10045 code, t1.cycle_id cycle, '??????????' type1, '' type2, '' type3,'' type4,'??????????'  name, t1.channel_sub2-t2.channel_sub2 value
  from so1.rpt_day_org t1,so1.rpt_day_org t2
  where t2.org_id= t1.org_id
  and t2.cycle_id = to_char(to_date(t1.cycle_id,'yyyymmdd')-1,'yyyymmdd')
  and t1.org_id = 502
 union all
select  t1.cycle_id || '_' || 10046 id,10046 code, t1.cycle_id cycle, '?????????' type1, '' type2, '' type3,'' type4,'?????????'  name, t1.channel_add_sub-t2.channel_add_sub value
  from so1.rpt_day_org t1,so1.rpt_day_org t2
  where t2.org_id= t1.org_id
  and t2.cycle_id = to_char(to_date(t1.cycle_id,'yyyymmdd')-1,'yyyymmdd')
  and t1.org_id = 502
 union all
select  t1.cycle_id || '_' || 10047 id,10047 code, t1.cycle_id cycle, '?????????' type1, '' type2, '' type3,'' type4,'?????????'  name, t1.channel_cancel_sub- t2.channel_cancel_sub value
  from so1.rpt_day_org t1,so1.rpt_day_org t2
  where t2.org_id= t1.org_id
  and t2.cycle_id = to_char(to_date(t1.cycle_id,'yyyymmdd')-1,'yyyymmdd')
  and t1.org_id = 502
 union all
select  t1.cycle_id || '_' || 10048 id,10048 code, t1.cycle_id cycle, '????????' type1, '' type2, '' type3,'' type4,'????????'  name, t1.channel_sub- t2.channel_sub value
  from so1.rpt_day_org t1,so1.rpt_day_org t2
  where t2.org_id= t1.org_id
  and t2.cycle_id = to_char(to_date(t1.cycle_id,'yyyymmdd')-1,'yyyymmdd')
  and t1.org_id = 502

  union all
select t2.cycle_id || '_' || (20100 + rownum) id,20100 + rownum code,
       t2.cycle_id cycle,
       '???????????' type1,
       cast(t2.office_org_id as varchar(256)) type2,
       '' type3,
       org.organize_name type4,
       '???????????' name,
       t2.BOOK30_AMOUNT value
  from so1.rpt_day_office t2,sec.sec_organize org
 where t2.org_id = 502 and org.organize_id= t2.office_org_id

  union all
select t2.cycle_id || '_' || (20200 + rownum) id,
       20200 + rownum code,
       t2.cycle_id cycle,
       '?????????????' type1,
       cast(t2.office_org_id as varchar(256)) type2,
       '' type3,
       org.organize_name type4,
       '?????????????' name,
       t2.CHANNEL_SUB - t1.CHANNEL_SUB value
  from so1.rpt_day_office t1, so1.rpt_day_office t2, sec.sec_organize org
 where t2.org_id = 502
   and org.organize_id = t2.office_org_id
   and t2.office_org_id = t1.office_org_id
   and t1.cycle_id =
       to_char(to_date(t2.cycle_id, 'yyyymmdd') - 1, 'yyyymmdd')
  union all
select  t2.cycle_id || '_' || (20300 + rownum) id,20300 + rownum code,
       t2.cycle_id cycle,
       '????' type1,
       cast(t2.office_org_id as varchar(256)) type2,
       '' type3,
       org.organize_name type4,
       '????' name,
       t2.PT_DE-t1.pt_de value
  from so1.rpt_day_office t1, so1.rpt_day_office t2, sec.sec_organize org
 where t2.org_id = 502
   and org.organize_id = t2.office_org_id
   and t2.office_org_id = t1.office_org_id
   and t1.cycle_id =
       to_char(to_date(t2.cycle_id, 'yyyymmdd') - 1, 'yyyymmdd')
  union all
select  t2.cycle_id || '_' || (20400 + rownum) id,20400 + rownum code,
       t2.cycle_id cycle,
       '????' type1,
      cast(t2.office_org_id as varchar(256)) type2,
       '' type3,
       org.organize_name type4,
       '????' name,
       t2.HD_DE-t1.hd_de value
  from so1.rpt_day_office t1, so1.rpt_day_office t2, sec.sec_organize org
 where t2.org_id = 502
   and org.organize_id = t2.office_org_id
   and t2.office_org_id = t1.office_org_id
   and t1.cycle_id =
       to_char(to_date(t2.cycle_id, 'yyyymmdd') - 1, 'yyyymmdd')
  union all
select  t2.cycle_id || '_' || (20500 + rownum) id,20500 + rownum code,
       t2.cycle_id cycle,
       '??????' type1,
       cast(t2.office_org_id as varchar(256)) type2,
       '' type3,
       org.organize_name type4,
       '??????' name,
       t2.GQHD_DE-t1.GQHD_DE value
  from so1.rpt_day_office t1, so1.rpt_day_office t2, sec.sec_organize org
 where t2.org_id = 502
   and org.organize_id = t2.office_org_id
   and t2.office_org_id = t1.office_org_id
   and t1.cycle_id =
       to_char(to_date(t2.cycle_id, 'yyyymmdd') - 1, 'yyyymmdd')
  union all
select  t2.cycle_id || '_' || (20600 + rownum) id,20600 + rownum code,
       t2.cycle_id cycle,
       '????' type1,
       cast(t2.office_org_id as varchar(256)) type2,
       '' type3,
       org.organize_name type4,
       '????' name,
       t2.GQ_DE-t1.GQ_DE value
  from so1.rpt_day_office t1, so1.rpt_day_office t2, sec.sec_organize org
 where t2.org_id = 502
   and org.organize_id = t2.office_org_id
   and t2.office_org_id = t1.office_org_id
   and t1.cycle_id =
       to_char(to_date(t2.cycle_id, 'yyyymmdd') - 1, 'yyyymmdd')

  union all
select  t3.cycle_id || '_' || (30100 + rownum) id,30100 + rownum code,
       t3.cycle_id cycle,
       '?????' type1,
      cast(t3.office_org_id as varchar(256)) type2,
       cast(t3.prod_id as varchar(256)) type3,
       org.organize_name || '|' || pr.name type4,
       '?????' name,
       t3.ADD_SUB value
  from so1.rpt_day_prod t3,sec.sec_organize org, product.up_product_item pr
 where t3.org_id = 502
 and org.organize_id= t3.office_org_id
 and product_item_id= t3.prod_id

  union all
select  t3.cycle_id || '_' || (30200 + rownum) id,30200 + rownum code,
       t3.cycle_id cycle,
       '?????' type1,
      cast(t3.office_org_id as varchar(256)) type2,
       cast(t3.prod_id as varchar(256)) type3,
       org.organize_name || '|' || pr.name type4,
       '?????' name,
       t3.CANCEL_SUB value
  from so1.rpt_day_prod t3,sec.sec_organize org, product.up_product_item pr
 where t3.org_id = 502
 and org.organize_id= t3.office_org_id
 and product_item_id= t3.prod_id
  union all
select  t3.cycle_id || '_' || (30300 + rownum) id,30300 + rownum code,
       t3.cycle_id cycle,
       '????' type1,
      cast(t3.office_org_id as varchar(256)) type2,
       cast(t3.prod_id as varchar(256)) type3,
       org.organize_name || '|' || pr.name type4,
       '????' name,
       t3.SUB_COUNT value
  from so1.rpt_day_prod t3,sec.sec_organize org, product.up_product_item pr
 where t3.org_id = 502
 and org.organize_id= t3.office_org_id
 and product_item_id= t3.prod_id

  union all
select  t4.cycle_id || '_' || 40001 id,40001 code,
       t4.cycle_id cycle,
       '????????' type1,
       '' type2,
       '' type3,
       '' type4,
       '????????' name,
       t4.UNPAY_AMOUNT value
  from so1.rpt_month_org t4
 where t4.org_id = 502
  union all
select  t4.cycle_id || '_' || 40002 id,40002 code,
       t4.cycle_id cycle,
       '????????' type1,
       '' type2,
       '' type3,
       '' type4,
       '????????' name,
       t4.UNPAY_SUB value
  from so1.rpt_month_org t4
 where t4.org_id = 502
  union all
select  t4.cycle_id || '_' || 40003 id,40003 code,
       t4.cycle_id cycle,
       '????????' type1,
       '' type2,
       '' type3,
       '' type4,
       '????????' name,
       t4.CHANNEL_AMOUNT value
  from so1.rpt_month_org t4
 where t4.org_id = 502
  union all
select  t4.cycle_id || '_' || 40004 id,40004 code,
       t4.cycle_id cycle,
       '????????' type1,
       '' type2,
       '' type3,
       '' type4,
       '????????' name,
       t4.CHANNEL_SUB value
  from so1.rpt_month_org t4
 where t4.org_id = 502
  union all
select  t4.cycle_id || '_' || 40005 id,40005 code,
       t4.cycle_id cycle,
       '??????????' type1,
       '' type2,
       '' type3,
       '' type4,
       '??????????' name,
       t4.HD_CYCLE_AMOUNT value
  from so1.rpt_month_org t4
 where t4.org_id = 502
  union all
select  t4.cycle_id || '_' || 40006 id,40006 code,
       t4.cycle_id cycle,
       '??????????' type1,
       '' type2,
       '' type3,
       '' type4,
       '??????????' name,
       t4.HD_CYCLE_SUB value
  from so1.rpt_month_org t4
 where t4.org_id = 502
  union all
select  t4.cycle_id || '_' || 40007 id,40007 code,
       t4.cycle_id cycle,
       '????????' type1,
       '' type2,
       '' type3,
       '' type4,
       '????????' name,
       t4.DETAIL_AMOUNT value
  from so1.rpt_month_org t4
 where t4.org_id = 502
  union all
select  t4.cycle_id || '_' || 40008 id,40008 code,
       t4.cycle_id cycle,
       '????????' type1,
       '' type2,
       '' type3,
       '' type4,
       '????????' name,
       t4.DETAIL_SUB value
  from so1.rpt_month_org t4
 where t4.org_id = 502
  union all
select  t4.cycle_id || '_' || 40009 id,40009 code,
       t4.cycle_id cycle,
       '????' type1,
       '' type2,
       '' type3,
       '' type4,
       '????' name,
       t4.TOTAL_SUB value
  from so1.rpt_month_org t4
 where t4.org_id = 502
  union all
select  t4.cycle_id || '_' || 40010 id,40010 code,
       t4.cycle_id cycle,
       '????' type1,
       '' type2,
       '' type3,
       '' type4,
       '????' name,
       t4.TOTAL_AMOUNT value
  from so1.rpt_month_org t4
 where t4.org_id = 502
   union all
select  t5.cycle_id || '_' || (50100 + rownum) id,50100 + rownum code,
       t5.cycle_id cycle,
       '????' type1,
       '' type2,
       cast(t5.prod_id as varchar(256)) type3,
       pr.name type4,
       '????' name,
       t5.BILL_AMOUNT value
  from so1.rpt_month_prod t5,product.up_product_item pr
 where t5.org_id = 502 and product_item_id=t5.prod_id
    union all
select  t5.cycle_id || '_' || (50200 + rownum) id,50200 + rownum code,
       t5.cycle_id cycle,
       '????' type1,
       '' type2,
       cast(t5.prod_id as varchar(256)) type3,
       pr.name type4,
       '????' name,
       t5.BILL_SUB value
  from so1.rpt_month_prod t5,product.up_product_item pr
 where t5.org_id = 502 and product_item_id=t5.prod_id






/

