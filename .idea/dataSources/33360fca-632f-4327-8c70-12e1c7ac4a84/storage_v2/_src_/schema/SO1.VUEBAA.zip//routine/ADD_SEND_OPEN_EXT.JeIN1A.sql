create procedure add_send_open_ext
as
has_send_open number(2);
has_send_open_ext number(2);
begin
for cur in (select distinct business_id from base.cfg_so_busi)
loop
    select count(*) into has_send_open from base.cfg_so_busi sb
    where sb.business_id=cur.business_id and sb.busi_task_code='BUSI_SEND_OPEN_TASK';

    select count(*) into has_send_open_ext from base.cfg_so_busi sb
    where sb.business_id=cur.business_id and sb.busi_task_code='BUSI_SEND_OPEN_EXT_TASK';

    --有发开通配置但没有发开通扩展配置则增加发开通扩展配置
    if has_send_open = 1 and has_send_open_ext = 0 then
       insert into base.cfg_so_busi 
       select max(cfg.cfg_busioper_id) + 1, cur.business_id,-1,-1,-1,-1,
       null,0,null,'BUSI_SEND_OPEN_EXT_TASK',1,
       'com.asiainfo.boss.process.open.ext.SzSendOpenExtImpl',
       null,1,null,'发开通扩展配置' from base.cfg_so_busi cfg;
    end if;
end loop;
exception 
    when others then
      rollback;
end;




/

