create FUNCTION       "GETPATHBYDISTRICTID" (districtId in number) return varchar2 is
  Result varchar2(256);
begin
  select regexp_replace(wmsys.wm_concat(b.district_id),',','#') into Result
  from (select district_id
          from (select area.district_id, level lv,CONNECT_BY_ISCYCLE
                  from base.bs_district area
                 start with area.district_id = districtId
                connect by NOCYCLE area.district_id = prior area.parent_district_id) a
         order by a.lv desc) b;
  return(Result);
end getPathByDistrictId;






/

