create procedure sysBatchCustInfo_510 is
begin

--execute immediate 'alter session set "_hash_join_enabled" = false'
--sysBatchCustInfo_510
--3303,3328
--3303,3328

MERGE INTO so1.batchsyn_custInf b
USING (SELECT m.cust_id, m.max_done_code, cust.own_corp_org_id
         FROM so1.cm_customer cust,
              (SELECT CUST_ID, MAX(DONE_CODE) MAX_DONE_CODE
                 FROM (SELECT CUST_ID, nvl(DONE_CODE,0) DONE_CODE FROM so1.CM_CUST_CONTACT_INFO WHERE region_id IN (510) And done_date >Sysdate-20
                       UNION ALL
                       SELECT CUST_ID, nvl(DONE_CODE,0) DONE_CODE FROM so1.INS_ADDRESS WHERE own_corp_org_id IN (3303,3328) And done_date >Sysdate-20
                       UNION ALL
                       SELECT CUST_ID, nvl(DONE_CODE,0) DONE_CODE FROM so1.CM_CUSTOMER WHERE cust_status <> 1 AND own_corp_org_id IN (3303,3328) And done_date >Sysdate-20
                       UNION ALL
                       SELECT CUST_ID, nvl(DONE_CODE,0) DONE_CODE FROM so1.INS_PROD WHERE own_corp_org_id IN (3303,3328) And done_date >Sysdate-20)
                GROUP BY CUST_ID
          MINUS
         SELECT t.cust_id, t.done_code max_done_code FROM so1.batchsyn_custInf t WHERE t.own_corp_org_id IN (3303,3328) ) m
        WHERE m.cust_id = cust.cust_id
          AND cust.own_corp_org_id IN (3303,3328) ) cm ON (b.cust_id = cm.cust_id)

WHEN MATCHED THEN
  UPDATE
     SET b.done_code = cm.max_done_code, state0=1,state1=1,state2=1,state3=1,state4=1,state5=1,state6=1,state7=1,state8=1,state9=1,stateA=1,stateB=1,stateC=1,stateD=1,stateE=1,stateF=1,stateG=1,stateH=1,stateI=1,stateJ=1,b.update_date = sysdate
   where b.cust_id = cm.cust_id
     and b.done_code < cm.max_done_code

WHEN NOT MATCHED THEN
  INSERT
    (b.cust_id, b.done_code, b.update_date,b.own_corp_org_id,b.state0,state1,state2,state3,state4,state5,state6,state7,state8,state9,stateA,stateB,stateC,stateD,stateE,stateF,stateG,stateH,stateI,stateJ)
  VALUES
    (cm.cust_id, cm.max_done_code, sysdate,cm.own_corp_org_id,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1);

  commit;

exception
  when others then
    dbms_output.put_line(sqlcode);
    dbms_output.put_line(sqlerrm);

    rollback;

end sysBatchCustInfo_510;
/

