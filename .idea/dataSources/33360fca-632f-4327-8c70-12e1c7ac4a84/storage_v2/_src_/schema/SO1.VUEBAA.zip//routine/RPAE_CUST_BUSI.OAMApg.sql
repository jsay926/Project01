create procedure     rpae_cust_busi
 is
begin
   delete from so1.ord_cust t where exists (select 1 from so1.ord_cust_f_2013 p where p.cust_order_id=t.cust_order_id) ;
   delete from  so1.ord_busi t where exists (select 1 from so1.ord_busi_f_2013 p where p.cust_order_id=t.cust_order_id) ;
   commit;
end rpae_cust_busi;




/

