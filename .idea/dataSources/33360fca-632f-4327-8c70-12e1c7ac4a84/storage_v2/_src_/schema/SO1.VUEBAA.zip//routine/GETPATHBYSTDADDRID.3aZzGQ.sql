create FUNCTION       "GETPATHBYSTDADDRID" (stdAddrId in number) return varchar2 is
  Result varchar2(512);
  stdAddrIdPath varchar2(128); --????id??
  districtIdPath varchar2(256); --??id??
  districtId number;            --????????????id
  topStdAddrId number;          --???????id
begin
  /*
   *??????id??
  */
  select regexp_replace(wmsys.wm_concat(b.std_addr_id),',','#') into stdAddrIdPath
  from (select *
          from (select asa.std_addr_id,
                       asa.name,
                       asa.parent_addr_id,
                       asa.district_id,
                       level lv,CONNECT_BY_ISCYCLE
                  from pboss.addr_std_addr asa
                 start with asa.std_addr_id = stdAddrId
                connect by NOCYCLE  asa.std_addr_id = prior asa.parent_addr_id) a
         order by a.lv desc) b;
       select  to_number(substr(stdAddrIdPath,1,instr(stdAddrIdPath,'#',1,1)-1)) into topStdAddrId  from dual;

       select t.district_id into districtId from pboss.addr_std_addr t where t.std_addr_id = topStdAddrId;

       select getPathByDistrictId(districtId) into districtIdPath from dual;

       select districtIdPath || '#' || stdAddrIdPath into Result from dual;
  return(Result);
end getPathByStdAddrId;






/

