create package body PKG_ERROR_ORDER_DEAL is

  --add by dr 2014.1.6
  -- Purpose : 每10分钟跑一次，处理接口表vm_work_flow错单state=99，已知的错单处理流程。
  --按照报错信息进行处理：以下为有固定处理方案的错单
  /*
  1,java.lang.Exception: 修改服务属性,未查到服务实例:0
  2,java.sql.SQLException: ORA-00001: unique constraint (SO1.PK_INS_OFF_INS_PROD_REL) violated
  */
procedure ERROR_ORDER_MAIN
is
v_srvpkg_inst_id so1.ord_srvpkg.srvpkg_inst_id%type;
v_srv_inst_id    so1.ord_srv.srv_inst_id%type;
v_count number;
ls_errmsg varchar2(1024);
begin
  ERROR_ORDER_01;
  ERROR_ORDER_02;
  ERROR_ORDER_03;
  exception when others then
          ls_errmsg := substr(sqlerrm,1,1000);
          insert into so1.order_exception_log(pro_name,note,error,errordate)values
           ('PKG_ERROR_ORDER_DEAL','ERROR@-100','异常退出'||ls_errmsg,sysdate);
          commit;
end ERROR_ORDER_MAIN;

procedure ERROR_ORDER_01
is
v_srvpkg_inst_id so1.ord_srvpkg.srvpkg_inst_id%type;
v_srv_inst_id    so1.ord_srv.srv_inst_id%type;
v_count number;
ls_errmsg varchar2(1024);
begin
   for res in(select substr(vars,instr(vars, 'lOrdCustId') +12,12) order_id,--订单号
                     task_id
                     from so1.vm_work_flow t where t.state=99
                     and t.error_message like 'java.lang.Exception: 修改服务属性,未查到服务实例:0%') loop
        select min(srvpkg_inst_id)-1  into v_srvpkg_inst_id from so1.ord_srvpkg t
        where state=1 and srvpkg_id not in (800600010007) and t.cust_order_id =res.order_id;
        select count(*) into v_count from so1.ins_srvpkg where srvpkg_inst_id = v_srvpkg_inst_id;
        if v_count > 0 then
           insert into so1.order_exception_log(pro_name,note,error,errordate)values
           ('PKG_ERROR_ORDER_DEAL','ERROR@1','新装产品ID已在产品表中存在!'||v_srvpkg_inst_id,sysdate);
           goto NEXT_ERROR_ORDER01;
        end if;
        --更新产品表ID
        update so1.ord_srvpkg t set t.srvpkg_inst_id = v_srvpkg_inst_id,state=1
        where state=4 and srvpkg_id= 800600010007 and cust_order_id =res.order_id;
        --
        select min(srv_inst_id)-1 into v_srv_inst_id from so1.ord_srv t
        where state=1 and service_id not in (800700010122) and t.cust_order_id =res.order_id;
        update so1.ord_srv t set srv_inst_id= v_srv_inst_id,state=1
        where state=4 and service_id = 800700010122 and cust_order_id =res.order_id;
        --
        update so1.ord_srvpkg_ord_srv t set state=1
        where  state=4  and t.cust_order_id=res.order_id;
        --更新工作流总控表
        update so1.vm_work_flow t set state=2 where task_id=res.task_id and state=99;
        update so1.vm_schedule set state='W' where workflow_id=res.task_id and state='F';
        --对于该
        <<NEXT_ERROR_ORDER01>>
        insert into so1.order_exception_log(pro_name,note,error,errordate)values
           ('ERROR_ORDER_01','OK','cust_order_id'||res.order_id,sysdate);        
        commit;
   end loop;
  exception when others then
          ls_errmsg := substr(sqlerrm,1,1000);
          insert into so1.order_exception_log(pro_name,note,error,errordate)values
           ('PKG_ERROR_ORDER_DEAL','ERROR@-1','异常退出'||ls_errmsg,sysdate);
          commit;
end ERROR_ORDER_01;

procedure ERROR_ORDER_02
is
v_prod_inst_id   number(16);
v_offer_inst_id  number(16);
v_count number;
ls_errmsg varchar2(1024);
begin
   /*ins_off_ins_prod_rel表数据有重复*/
   for res in(select substr(vars,instr(vars, 'lOrdCustId') +12,12) order_id,--订单号
                     task_id
                     from so1.vm_work_flow t where t.state=99
                     and t.error_message like 'java.sql.SQLException: ORA-00001:%(SO1.PK_INS_OFF_INS_PROD_REL)%') loop
        select distinct prod_inst_id into v_prod_inst_id
        from so1.ord_prod t where t.cust_order_id =res.order_id;
        select offer_inst_id into v_offer_inst_id from so1.ins_off_ins_prod_rel t where prod_inst_id =v_prod_inst_id
        group by offer_inst_id having count(*)>1;
        --备份并删除多余的数据
        insert into so1.h_ins_off_ins_prod_rel_2014 
        select (select min(h_id)-1 from so1.h_ins_off_ins_prod_rel_2014 t),t.*
        from so1.ins_off_ins_prod_rel t where offer_inst_id=v_offer_inst_id
        and expire_date>sysdate and rownum=1;
        delete so1.ins_off_ins_prod_rel t where offer_inst_id=v_offer_inst_id
        and expire_date>sysdate and rownum=1;
        --更新工作流总控表
        update so1.vm_work_flow t set state=2 where task_id=res.task_id and state=99;
        update so1.vm_schedule set state='W' where workflow_id=res.task_id and state='F';
        insert into so1.order_exception_log(pro_name,note,error,errordate)values
           ('ERROR_ORDER_02','OK','cust_order_id'||res.order_id,sysdate);
        commit;
   end loop;
  exception when others then
          ls_errmsg := substr(sqlerrm,1,1000);
           insert into so1.order_exception_log(pro_name,note,error,errordate)values
           ('PKG_ERROR_ORDER_DEAL','ERROR@-2','异常退出'||ls_errmsg,sysdate);
          commit;
end ERROR_ORDER_02;

---
procedure ERROR_ORDER_03
is
v_prod_inst_id   number(16);
v_offer_inst_id  number(16);
v_count number;
ls_errmsg varchar2(1024);
begin
   /*ins_off_ins_prod_rel表数据有重复*/
   for res in(select substr(vars,instr(vars, 'customerOrderId') +17,12) order_id,--订单号
                     task_id
                     from so1.vm_work_flow t where t.state=99
                     and t.error_message like 'java.lang.Exception: 客户订单编号%下没有相应的产品订单信息%') loop
        --直接移历史
        p_rape_order(res.order_id);
        insert into so1.order_exception_log(pro_name,note,error,errordate)values
           ('ERROR_ORDER_03','OK','cust_order_id'||res.order_id,sysdate);
        commit;
   end loop;
  exception when others then
          ls_errmsg := substr(sqlerrm,1,1000);
           insert into so1.order_exception_log(pro_name,note,error,errordate)values
           ('PKG_ERROR_ORDER_DEAL','ERROR@-3','异常退出'||ls_errmsg,sysdate);
          commit;
end ERROR_ORDER_03;


procedure ERROR_ORDER_04
is
v_task_id    so1.ord_srv.srv_inst_id%type;
v_count number;
v_sql varchar2(1024);
ls_errmsg varchar2(1024);
begin
   for res in(select so_id task_id from so1.dr_015317) loop
       -- v_sql:= ' insert into so1.dr_015317  select task_id,null from  so1.vm_work_flow t where  state=99 and  t.vars like ''%'||res.cust_order_id||'%'''; 
      --  EXECUTE IMMEDIATE v_sql  ;            
        --更新工作流总控表
        update so1.vm_work_flow t set state=2 where task_id=res.task_id and state=99;
        update so1.vm_schedule set state='W' where workflow_id=res.task_id and state='F';
        --对于该 
        commit;
   end loop;
  exception when others then
          ls_errmsg := substr(sqlerrm,1,1000);
          insert into so1.order_exception_log(pro_name,note,error,errordate)values
           ('PKG_ERROR_ORDER_DEAL','ERROR@-4','异常退出'||ls_errmsg,sysdate);
          commit;
end ERROR_ORDER_04;


procedure ERROR_ORDER_SF_TO_CRM ---PBOSS工单已完成，不返回消息给CRM add by dr 20150202
is
v_sql    varchar2(1024);
ls_errmsg varchar2(1024);
begin
   for v_so_id in(select so_order_id,so_serial_code from pboss.i_crm_to_sf_his t where t.so_serial_code in (
                        select order_grp_id from pboss.sf_order t 
                        where order_grp_id in(select cust_order_id from so1.ord_cust t where business_id in(800001000002,800001000039,800001000052,800001000001))
                         and merge_flag=2 and state=3 )) loop
              v_sql := 'insert into pboss.i_sf_to_crm t (so_order_id,msg_content,create_date,excute_date,region_id,state)values
              ('||v_so_id.so_order_id||',
              ''<?xml version="1.0" encoding="UTF-8"?>
              <order_cons><so_order_id>'||v_so_id.so_order_id||'</so_order_id><oper_type>0</oper_type><region_code>0</region_code><finish_date>'||to_char(sysdate,'yyyy-mm-dd HH:MM:SS')||'</finish_date><comments></comments><attr_list><attr/></attr_list></order_cons>'',
              sysdate,sysdate,0,1)';
              EXECUTE IMMEDIATE v_sql;
        insert into so1.order_exception_log(pro_name,note,error,errordate)values
           ('ERROR_ORDER_SF_TO_CRM','OK','ORD_SERIAL_CODE'||v_so_id.so_serial_code,sysdate);        
        commit;
   end loop;
  exception when others then
          ls_errmsg := substr(sqlerrm,1,1000);
          insert into so1.order_exception_log(pro_name,note,error,errordate)values
           ('PKG_ERROR_ORDER_DEAL','ERROR@-1','异常退出'||ls_errmsg,sysdate);
          commit;
end ERROR_ORDER_SF_TO_CRM;
end PKG_ERROR_ORDER_DEAL  ;
/

