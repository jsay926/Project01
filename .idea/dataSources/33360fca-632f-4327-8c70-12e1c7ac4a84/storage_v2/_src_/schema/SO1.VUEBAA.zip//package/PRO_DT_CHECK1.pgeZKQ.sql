create PACKAGE     "PRO_DT_CHECK1"
As
   c_sync Number;
   v_result Number;
   Type t_old_cust_mode Is Record (
        old_cust               Number,
        old_con               Number,
        old_addr              Number,
        old_acct               Number
   );                                                              /*???????*/

   Type t_new_cust_mode Is Record (
        new_cust               Number,
        new_con               Number,
        new_addr              Number,
        new_acct              Number,
        invalid_cust          Number
   );                                                           /*???????*/

   Type t_old_sub_mode Is Record (
        old_sub                 Number,
        old_subp               Number
   );

   Type t_new_sub_mode Is Record (
        new_sub                Number,
        new_offer              Number,
        new_srvpkg           Number,
        new_srv                Number
   );

  Type t_old_book Is Record (
        old_book_1 Number,---现金
        old_book_2 Number,---优惠点
        old_book_3 Number,---虚拟币
        old_book_4 Number,---充值币
        old_book_18 Number,---赠送点_点播专用
        old_book_20 Number,---赠送点_宽带专用
        old_book_101100081 Number---境内付费专用账本
   );

     Type t_new_book Is Record (
        new_1_vs_1                        Number,
        new_2_vs_2                       Number,
        new_3_vs_3                 Number,
        new_4_vs_4                 Number,
        new_18_vs_11                        Number,
        new_20_vs_12                        Number,
        new_101100081_vs_13                  Number,
        new_vs_22    number,
        new_vs_21    number,
        new_vs_23    number
   );
   Procedure record_data(v_data In Varchar2);                                                          --??????? ????so1.tmp_record_data
   Procedure get_old_cust(v_old_cust_mode Out t_old_cust_mode);                           --???????     v_result:=-1;
   Procedure get_new_cust(v_new_cust_mode Out t_new_cust_mode);                      --???????     v_result:=-2;
   Procedure get_old_sub(v_old_sub_mode Out t_old_sub_mode);                             --???????      v_result:=-3;
   Procedure get_new_sub(v_new_sub_mode Out t_new_sub_mode);                        --???????      v_result:=-4;
   Procedure get_old_book(v_old_book Out t_old_book);                                          --???????       v_result:=-5;
   Procedure get_new_book(v_new_book Out t_new_book);                                     --???????        v_result:=-6;
End pro_dt_check1;




/

