create package PKG_ERROR_ORDER_DEAL is

procedure ERROR_ORDER_MAIN;

procedure ERROR_ORDER_01;

procedure ERROR_ORDER_02;

procedure ERROR_ORDER_03;

procedure ERROR_ORDER_04;

procedure ERROR_ORDER_SF_TO_CRM;

end PKG_ERROR_ORDER_DEAL;





/

