create FUNCTION       "DT_TRAN_UNION_INVO" (v_invoice_id In Number)
        Return Varchar2 Is
        v_chg_item_name Varchar2(30);
        v_amount Number;
        v_result Varchar2(300);
        v_count Number;
        Cursor v_cur  Is Select /*+ index(dtl)  use_nl(dtl,ucm) index(ucm)*/  chg_item_name,amount From bm.bm_invoice_dtl dtl,up.up_charge_item ucm
               Where dtl.Invoice_Id = v_invoice_id And ucm.chg_item_id=dtl.chg_item_id;
Begin
      Open v_cur;
      v_count :=0;
      Loop
           Fetch v_cur Into v_chg_item_name,v_amount;
           Exit When v_cur%Notfound;
           v_count :=v_count + 1;
           If v_result Is Null  Then
               If v_cur%Rowcount = 1 Then
                   v_result := v_chg_item_name||':'||v_amount;
                   Exit;
               Else
                   v_result := v_chg_item_name||':'||v_amount||';';
               End If;
           Elsif v_result Is Not Null And v_cur%Rowcount = v_count Then
                   v_result := v_chg_item_name||':'||v_amount||';';
           Else
                  v_result := v_chg_item_name||':'||v_amount;
           End If;
      End Loop;
      Close v_cur;
      Return  v_result;
Exception
          When Others Then
                Return Null;
End;





/

