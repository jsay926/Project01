create package res_common is

procedure numberToChar(

  i_number In NUMBER, /*输入数字*/
  i_length IN NUMBER, /*输出字符长度*/
  o_number Out VARCHAR2 /*输出字符*/
);

end res_common;
create or replace package body res_common is

  procedure numberToChar(

  i_number In NUMBER, /*输入数字*/
  i_length IN NUMBER, /*输出字符长度*/
  o_number Out VARCHAR2 /*输出字符*/
) As
BEGIN
  if(length(to_char(i_number))<i_length) then
      o_number :=lpad(to_char(i_number),i_length,'0');
  end if;
  if(length(to_char(i_number))=i_length) then
      o_number :=to_char(i_number);
  end if;
  if(length(to_char(i_number))>i_length) then
      o_number :=SUBSTR(to_char(i_number),length(to_char(i_number))-i_length+1,i_length);
  end if;
END numberToChar;
end res_common;
create or replace package invoice is

  -- Author  : YANGJING
  -- Created : 2011-12-6 19:17:13
  -- Purpose : 票据

  procedure gen_invoice(v_begin_innum  in number, --发票起始号
                                            v_end_num      in number, --发票结束号
                                            v_invoice_num  in number, --每册张数
                                            v_res_code     in number, --类型ID
                                            v_print_type   in number,   --打印类型
                                            v_invoice_code in varchar2, --发票代码
                                            v_rep_id       in varchar2, --仓库ID
                                            v_org_id       in varchar2, --操作员组织
                                            v_op_id        in varchar2, --操作员工号
                                            v_remark       in varchar2, --标示
                                            o_list_num     out number,--共多少册
                                            o_grp_id       out number,--批次号
                                            v_msg          out varchar2); --返回值

end invoice;
create or replace package body invoice is

 procedure gen_invoice(v_begin_innum  in number, --发票起始号
                                            v_end_num      in number, --发票结束号
                                            v_invoice_num  in number, --每册张数
                                            v_res_code     in number, --类型ID
                                            v_print_type   in number,   --打印类型
                                            v_invoice_code in varchar2, --发票代码
                                            v_rep_id       in varchar2, --仓库ID
                                            v_org_id       in varchar2, --操作员组织
                                            v_op_id        in varchar2, --操作员工号
                                            v_remark       in varchar2, --标示
                                            o_list_num     out number,--共多少册
                                            o_grp_id       out number,--批次号
                                            v_msg          out varchar2) is--返回值
  v_list_no      varchar2(25);
  list_num       number(10);
  v_count        number(10);
  v_count1       number(10);
  v_grp_id       varchar2(20);
  v_begin_num    number(25);
  n_numcount     number(20);
  n_numcount1    number(20);
  n_res_code_num number(20);
  v_res_sub_type number(2);
  v_list_no_seq  number(20);
  v_list_no_seq_c varchar2(5);
  v_invoice_num_c varchar2(8);
  v_invoice_num_begin_c varchar2(8);
  v_invoice_num_end_c varchar2(8);
  v_goto_msg               varchar2(50);
  v_res_msg               varchar2(50);
begin
  --if length(v_begin_innum) = 8 and length(v_end_num) = 8 then
  --begin
  if v_begin_innum >v_end_num then
    v_goto_msg :='10';
    goto endProduct;
  end if;
  if v_invoice_num =0 or v_invoice_num is null   then
    v_goto_msg :='20';
    goto endProduct;
  end if;
    if v_invoice_code is null then
    v_goto_msg :='30';
    goto endProduct;
  end if;
  --校验完成，开始执行发票生产

  v_count     := 0;
  v_count1    := 0;
  n_numcount  := 0;
  list_num    := (v_end_num - v_begin_innum + 1) / v_invoice_num;
  v_begin_num := v_begin_innum - 1;
  --if length(v_begin_innum) = 8 and length(v_end_num) = 8 then
  --begin
    if list_num > 0 and mod(((v_end_num - v_begin_innum + 1) / v_invoice_num), 1) = 0 then
    begin
      select count(*) into n_numcount from res_invoice a where a.invoice_code = v_invoice_code and a.invoice_no between v_begin_innum and v_end_num;
      if n_numcount = 0 then
      begin
        select count(*) into n_numcount1 from res_repository a where (a.rep_flag = 5 or a.rep_flag = 0) and a.rep_id = v_rep_id;
        if n_numcount1 = 1 then
        begin
          select count(*) into n_res_code_num from res_code_definition a where a.res_type = 7 and a.res_code = v_res_code;
          if n_res_code_num = 1 then
          begin
            select res_sub_type into v_res_sub_type from res_code_definition a where a.res_type = 7 and a.res_code = v_res_code;
            select res.RES_INVOICE_LIST_GRP_ID$SEQ.nextval into v_grp_id from dual;
            loop--册循环begin
              v_count1 := 0;
            exit when v_count = list_num;
              v_count := v_count + 1;
              --select decode(27, 26, 1, 27, 2, 29, 3, 30, 4, 28, 5) || '1' || to_char(sysdate, 'yyMMdd') || res_invoice_list_no$seq.nextval into v_list_no from dual;
              select res_invoice_list_no$seq.nextval into v_list_no_seq from dual;
              res_common.numberToChar(v_list_no_seq,5,v_list_no_seq_c);
              v_list_no := v_res_sub_type || v_print_type || to_char(sysdate, 'yyMMdd') || v_list_no_seq_c;
              dbms_output.put_line('v_list_no:'||v_list_no||';v_res_sub_type:'||v_res_sub_type||';v_print_type:'||v_print_type||';v_list_no_seq_c:'||v_list_no_seq_c);
              loop--票循环begin
              begin
                v_count1 := v_count1 + 1;
              exit when mod(v_count1, v_invoice_num+1) = 0;
                -- dbms_output.put_line('v_count1:'||v_count1);
                -- dbms_output.put_line('v_invoice_num+1:'||(v_invoice_num+1));
                -- dbms_output.put_line('mod(v_count1, v_invoice_num+1):'||mod(v_count1, v_invoice_num+1));
                v_begin_num := v_begin_num + 1;
                res_common.numberToChar(v_begin_num,8,v_invoice_num_c);--票号
                insert /*+append*/  into res_invoice (res_id,invoice_no,org_id,state,op_id,done_code,done_date,list_no,audit_flag,is_start_no,is_end_no,remark,INVOICE_CODE)
                values(res_invoice$seq.nextval,v_invoice_num_c,v_org_id,'1',v_op_id,'0',sysdate,v_list_no,'1',decode(v_count1, 1, 1, 0),decode(v_count1, v_invoice_num, 1, 0),v_remark,v_invoice_code);
                insert /*+append*/  into res_invoice_log(log_id,res_id,done_code,opt_code,org_id,state,receiver_op_id,op_date,op_id,list_no,print_type,operator_id,AMOUNT,rep_id,receive_state,remark)
                values(res_invoice_log$seq.nextval,res_invoice$seq.currval,0,1,v_org_id,'1','0',sysdate,v_op_id,to_char(v_list_no),v_print_type,'0','0',v_rep_id,'1',v_remark);
              exception
              when others THEN
                v_msg := 'INSERT_ERROR';
                rollback;
              end;
              end loop;--票循环end
              begin
                res_common.numberToChar(v_begin_num - v_invoice_num+1,8,v_invoice_num_begin_c);
                res_common.numberToChar(v_begin_num,8,v_invoice_num_end_c);
                insert /*+append*/ into res_invoice_list(LIST_NO,GRP_ID,CREATE_DATE,INVOICE_NO_START,INVOICE_NO_END,REP_ID,RES_CODE,PRINT_TYPE,LIST_COUNT,STATE,RECEIVER,IS_LOST,ORG_ID,op_id,DONE_CODE,DONE_DATE,REMARK)
                values(v_list_no,v_grp_id,sysdate,v_invoice_num_begin_c,v_invoice_num_end_c,v_rep_id,v_res_code,v_print_type,v_invoice_num,1,0,0,v_org_id,v_op_id,0,sysdate,v_remark);
            exception
              when others THEN
              v_msg := 'INSERT_ERROR';
              rollback;
              end;
              if mod(sql%rowcount,10000)=0 then
                 commit;
              end if;
            end loop;--册循环end
            v_msg := 'SUCCESS';
          end;
          else
            v_msg := '资源型号输入有误';
          end if;
        end;
        else
            v_msg := '仓库不存在，或者输入的仓库数据有误';
        end if;
      end;
      else
            v_msg := '号段内有存在的发票号';
      end if;
    end;
    else
            v_msg := '输入的发票段必须是'||v_invoice_num||'的整倍数';
    end if;
  --end;
  --else
  --          v_msg := '发票位数必须为8位';
  --end if;
            commit;
            o_grp_id := v_grp_id;
            o_list_num := list_num;
   <<endProduct>>
          select decode(v_goto_msg,10,'起始号码要大于等于结束号码',20,'每册页数必须是大于0的整数',
          30,'发票代码不能为空','ACCESS') into v_res_msg  from dual;
          if v_res_msg !='ACCESS' then
             v_msg :=v_res_msg;
          end if;
end gen_invoice;
end invoice;




/

