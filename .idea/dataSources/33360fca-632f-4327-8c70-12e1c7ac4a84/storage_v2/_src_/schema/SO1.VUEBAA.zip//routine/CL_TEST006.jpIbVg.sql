create PROCEDURE       "CL_TEST006" (tablename  in varchar2,
                                       dual_name1 in varchar2,
                                       dual_name2 in varchar2,
                                       prov_id    in varchar2,
                                       month_id   in varchar2) is

  sqlstr1 varchar2(2000);
  sqlstr2 varchar2(2000);
  dual1   varchar2(200);
  dual2   varchar2(200);
begin
  sqlstr1 := 'select count(' || dual_name1 || ') from ' || tablename ||
             'where '||dual_name1|| ' not in (select ' || dual_name2 || ' from cl_test05 ) and
prov_id= ''' || prov_id || ''' and month_id= ''' || month_id || '''';
  sqlstr2 := 'select decode(count(distinct ' || dual_name1 ||
             '),1,?, 0 ,?) from ' || tablename || 'where prov_id= ''' ||
             prov_id || ''' and month_id= ''' || month_id || '''';
  execute immediate sqlstr1
    into dual1;
  execute immediate sqlstr2
    into dual2;
end cl_test006;







/

