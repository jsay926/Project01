create PROCEDURE       "GET_ORD_DATA" 
(
in_cust_order_id  in number
) 
IS

lv_where_str   varchar2(1000);
ln_count  number;
ln_year   varchar2(1000);

begin
  
  select to_char(trunc(sysdate),'yyyy') into ln_year
  from dual;
  
  select count(*) into ln_count
  from ord_cust 
  where cust_order_id=in_cust_order_id;
  
  lv_where_str:=' where cust_order_id='||in_cust_order_id;
  
  if(ln_count >0) then
    print_insert('ORD_CUST',lv_where_str);
    print_insert('ORD_CUST_ATTR',lv_where_str);
    print_insert('ORD_CUSTINFO',lv_where_str);
    print_insert('ORD_ADDRESS',lv_where_str);
    print_insert('ORD_ACCREL',lv_where_str);
    print_insert('ORD_ACCTINFO',lv_where_str);
    print_insert('ORD_BUSI',lv_where_str);
    print_insert('ORD_BUSI_ATTR',lv_where_str);
    print_insert('ORD_BUSI_DTL',lv_where_str);
    print_insert('ORD_INVOICE',lv_where_str);
    print_insert('ORD_PRICE',lv_where_str);
    print_insert('ORD_OFFER',lv_where_str);
    print_insert('ORD_PROD',lv_where_str);
    print_insert('ORD_PROD_RES',lv_where_str);
    print_insert('ORD_SRVPKG',lv_where_str);
    print_insert('ORD_SRV',lv_where_str);
    print_insert('ORD_SRV_ATTR',lv_where_str);
  else
    print_insert('ORD_CUST'||'_f_'||ln_year,lv_where_str);
    print_insert('ORD_CUST_ATTR'||'_f_'||ln_year,lv_where_str);
    print_insert('ORD_CUSTINFO'||'_f_'||ln_year,lv_where_str);
    print_insert('ORD_ADDRESS'||'_f_'||ln_year,lv_where_str);
    print_insert('ORD_ACCREL'||'_f_'||ln_year,lv_where_str);
    print_insert('ORD_ACCTINFO'||'_f_'||ln_year,lv_where_str);
    print_insert('ORD_BUSI'||'_f_'||ln_year,lv_where_str);
    print_insert('ORD_BUSI_ATTR'||'_f_'||ln_year,lv_where_str);
    print_insert('ORD_BUSI_DTL'||'_f_'||ln_year,lv_where_str);
    print_insert('ORD_INVOICE'||'_f_'||ln_year,lv_where_str);
    print_insert('ORD_PRICE'||'_f_'||ln_year,lv_where_str);
    print_insert('ORD_OFFER'||'_f_'||ln_year,lv_where_str);
    print_insert('ORD_PROD'||'_f_'||ln_year,lv_where_str);
    print_insert('ORD_PROD_RES'||'_f_'||ln_year,lv_where_str);
    print_insert('ORD_SRVPKG'||'_f_'||ln_year,lv_where_str);
    print_insert('ORD_SRV'||'_f_'||ln_year,lv_where_str);
    print_insert('ORD_SRV_ATTR'||'_f_'||ln_year,lv_where_str);
  end if;
    
exception
   when others then
      rollback;
end;









/

