create FUNCTION "system.ENCRY" (Name VARCHAR2) return VARCHAR2
      as language java name
      'EncryptUtil.encrypt(java.lang.String) return java.lang.String' ;
----------------------调试


/

