create PROCEDURE DANG_TEST01_blc_back
IS
v_blc_back_id  number(16);
begin
  for v_blc in ( select distinct acct_id from dang_acct_blc_back_rec0409 )
  loop
    select max(blc_back_id) into v_blc_back_id from zg.acct_blc_back_rec t where
     blc_back_id in ( select blc_back_id from dang_acct_blc_back_rec0409 )
    and acct_id=v_blc.acct_id;
    delete  zg.acct_blc_back_rec t where blc_back_id = v_blc_back_id;
    commit;
  end loop;

exception
   when others then
      rollback;
end;




/

