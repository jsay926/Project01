create PROCEDURE DANG_TEST01----相同记录，保留一条
IS
v_blc_back_id  number(16);
v_count number;
ls_errmsg varchar2(1000);
begin
  for v_offer in (  select offer_inst_id from so1.ins_offer  a
                    where not exists(
                    select 1 from so1.ins_off_ins_prod_rel b
                    where b.offer_inst_id=a.offer_inst_id) )
  loop
  begin
   select count(*) into v_count from so1.h_ins_offer_2013 t where offer_inst_id =  v_offer.offer_inst_id;
    delete  so1.h_ins_offer_2013 t where offer_inst_id = v_offer.offer_inst_id and rownum<v_count;
    commit;
    exception
   when others then
          ls_errmsg := substr(sqlerrm,1,1024);
          INSERT INTO DR_EXCEPTION_LOG VALUES ('DANG_TEST01','ERROR', v_offer.offer_inst_id||ls_errmsg,SYSDATE);
    end;
  end loop;
end;




/

