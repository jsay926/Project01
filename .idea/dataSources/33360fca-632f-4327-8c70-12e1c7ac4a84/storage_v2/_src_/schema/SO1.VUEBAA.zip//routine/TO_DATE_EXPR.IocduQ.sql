create FUNCTION     to_date_expr (date date) return varchar is
begin
  return 'to_date('''||to_char(date,'yyyy-mm-dd hh24:mi:ss')||''', ''yyyy-mm-dd hh24:mi:ss'')';
end;


/

