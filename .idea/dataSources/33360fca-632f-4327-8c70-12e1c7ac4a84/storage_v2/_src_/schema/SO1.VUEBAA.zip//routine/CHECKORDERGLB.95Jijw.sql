create PROCEDURE CHECKORDERGLB(IN_CUST_CODE IN VARCHAR2,
                                          ERR_MSG      OUT VARCHAR2) IS

  V_CUST_STATUS NUMBER(1);
  V_CNT         INT;
  V_CUST_ID     NUMBER(14);
  V_SQL_OFFER   VARCHAR2(2000);
  -- V_OWN_CORP_ORG_ID NUMBER(4);
  V_PROD_STATE    VARCHAR2(3);
  V_VIP_OFFER_IDS VARCHAR2(2000);
  V_SQL_BASE      VARCHAR2(2000);
  V_PROD_INST_ID  NUMBER(14);
  TYPE C1 IS REF CURSOR;
  V_OFFERIDS C1;

  V_OFFID         NUMBER(14);
  V_OK            VARCHAR2(14);
  V_OFFER_INST_ID NUMBER(14);

  V_SRVPKG_STATUS VARCHAR2(14);
  V_SRVPKG_STATE  NUMBER(2);
  V_CUST_TYPE     NUMBER(1);

BEGIN

  SELECT COUNT(1)
    INTO V_CNT
    FROM SO1.CM_CUSTOMER
   WHERE CUST_CODE = IN_CUST_CODE;
  IF V_CNT > 0 THEN
    SELECT CUST_STATUS, CUST_TYPE
      INTO V_CUST_STATUS, V_CUST_TYPE
      FROM SO1.CM_CUSTOMER
     WHERE CUST_CODE = IN_CUST_CODE;

    IF V_CUST_TYPE <> 1 THEN
      ERR_MSG := '校验失败：该客户非公众客户！';
    ELSE
      IF V_CUST_STATUS = 2 THEN
        SELECT CUST_ID
          INTO V_CUST_ID
          FROM SO1.CM_CUSTOMER
         WHERE CUST_CODE = IN_CUST_CODE;

        --查询客户下的主机
        SELECT COUNT(1)
          INTO V_CNT
          FROM INS_PROD
         WHERE PROD_SPEC_ID = 800200000001
           AND MAIN_PROD_INST_ID = 0
           AND CUST_ID = V_CUST_ID;
        IF V_CNT = 1 THEN

          --校验主机用户状态
          SELECT STATE, PROD_INST_ID, OFFER_INST_ID
            INTO V_PROD_STATE, V_PROD_INST_ID, V_OFFER_INST_ID
            FROM INS_PROD
           WHERE PROD_SPEC_ID = 800200000001
             AND MAIN_PROD_INST_ID = 0
             AND CUST_ID = V_CUST_ID;

          IF V_PROD_STATE <> '1' THEN
            ERR_MSG := '校验失败：客户主数字用户非正常状态！';
          ELSE
            --查询主机基本包产品的状态
            SELECT COUNT(1)
              INTO V_CNT
              FROM INS_SRVPKG
             WHERE OFFER_INST_ID = V_OFFER_INST_ID;
            IF V_CNT = 1 THEN
              SELECT OS_STATUS, STATE
                INTO V_SRVPKG_STATUS, V_SRVPKG_STATE
                FROM INS_SRVPKG
               WHERE OFFER_INST_ID = V_OFFER_INST_ID;

              IF V_SRVPKG_STATE = 1 AND V_SRVPKG_STATUS IS NULL THEN
                --查询有线宝客户级套餐id集合
                V_SQL_BASE := 'SELECT code_value FROM base.cfg_static_data WHERE code_type =' || '''' ||
                              'VIP_OFFER_IDS' || '''';

                EXECUTE IMMEDIATE V_SQL_BASE
                  INTO V_VIP_OFFER_IDS;

                IF V_VIP_OFFER_IDS IS NULL THEN
                  ERR_MSG := '';
                ELSE
                  --查询主机用户下的套餐
                  V_SQL_OFFER := 'SELECT offer_id FROM so1.ins_offer WHERE offer_inst_id IN (SELECT offer_inst_id FROM so1.ins_off_ins_prod_rel WHERE  prod_inst_id = ' || '''' ||
                                 V_PROD_INST_ID || '''' ||
                                 ' AND expire_date > sysdate)';
                  --DBMS_OUTPUT.PUT_LINE(V_SQL_OFFER);

                  OPEN V_OFFERIDS FOR V_SQL_OFFER;

                  LOOP
                    FETCH V_OFFERIDS
                      INTO V_OFFID;
                    EXIT WHEN V_OFFERIDS%NOTFOUND;

                    SELECT INSTR(V_VIP_OFFER_IDS, V_OFFID)
                      INTO V_OK
                      FROM DUAL;
                    IF V_OK > 0 THEN
                      ERR_MSG := '校验失败：客户已订购有线宝客户级套餐！';
                    END IF;

                  END LOOP;
                  CLOSE V_OFFERIDS;

                END IF;
              ELSE
                ERR_MSG := '校验失败：该客户下的主终端基本包非正常状态！';
              END IF;

            ELSE
              ERR_MSG := '校验失败：未查询到客户下的主终端基本包信息或者有多条基本包信息！';
            END IF;

          END IF;

        ELSE
          ERR_MSG := '校验失败：未查询到客户下的主终端信息或存在多条主终端信息！';
        END IF;
      ELSE
        ERR_MSG := '校验失败：客户不为正常状态！';
      END IF;

    END IF;

  ELSE
    ERR_MSG := '校验失败：根据客户证号未查询到客户信息！';

  END IF;

EXCEPTION
  WHEN NO_DATA_FOUND THEN
    ERR_MSG := (SQLERRM);
  WHEN OTHERS THEN
    ERR_MSG := '校验失败：未知错误';

END CHECKORDERGLB;
/

