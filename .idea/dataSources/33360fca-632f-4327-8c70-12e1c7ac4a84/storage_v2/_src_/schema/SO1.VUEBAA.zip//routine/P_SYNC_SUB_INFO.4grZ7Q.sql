create procedure     p_sync_sub_info AS
  v_year CHAR(4);
  v_sql0 VARCHAR2(100);
  v_sql1 VARCHAR2(2000);
  v_sql2 VARCHAR2(2000);
BEGIN
  SELECT extract(YEAR FROM SYSDATE) INTO v_year FROM dual;
  /*dbms_output.put_line('当前年份是'||v_year);*/
  v_sql0 := 'TRUNCATE TABLE so1.tmp_sub_info';
  /*dbms_output.put_line(v_sql0);*/
  EXECUTE immediate v_sql0;
  v_sql1 := 'INSERT INTO so1.tmp_sub_info
SELECT t.prod_inst_id,t.own_corp_org_id,MAX(t.done_code) max_done_code
FROM
(
SELECT distinct d.prod_inst_id,a.done_code,a.own_corp_org_id
FROM
(SELECT cust_order_id,business_id,own_corp_org_id,done_date,done_code FROM so1.ord_cust_f_' ||
            v_year ||
            ' )a,
(SELECT cust_order_id,busioper_order_id FROM so1.ord_busi_f_' ||
            v_year ||
            ' )b,
(SELECT offer_order_id,cust_order_id,busioper_order_id FROM so1.ord_offer_f_' ||
            v_year ||
            ' )c,
(SELECT offer_order_id,cust_order_id,busioper_order_id,prod_inst_id FROM so1.ord_prod_f_' ||
            v_year ||
            ' )d,
(SELECT offer_order_id,cust_order_id FROM so1.ord_srvpkg_f_' ||
            v_year || ' )e
WHERE a.cust_order_id=b.cust_order_id
AND   a.cust_order_id=c.cust_order_id
AND   a.cust_order_id=d.cust_order_id
AND   a.cust_order_id=e.cust_order_id
AND   b.busioper_order_id=c.busioper_order_id
AND   b.busioper_order_id=d.busioper_order_id
AND   c.offer_order_id=d.offer_order_id
AND   c.offer_order_id=e.offer_order_id
AND   a.business_id NOT IN (800001000057,800001000058)
AND   a.done_date>sysdate-1
UNION
';/*add 2014.7.11 只取一天数据a.done_date>sysdate-1*/
  v_sql2 := 'SELECT distinct d.prod_inst_id,a.done_code,a.own_corp_org_id
FROM
(SELECT cust_order_id,cust_id,business_id,own_corp_org_id,create_date,done_code FROM so1.ord_cust )a,
(SELECT cust_order_id,busioper_order_id FROM so1.ord_busi WHERE valid_type=2)b,
(SELECT offer_order_id,cust_order_id,busioper_order_id FROM so1.ord_offer )c,
(SELECT offer_order_id,cust_order_id,busioper_order_id,prod_inst_id FROM so1.ord_prod )d,
(SELECT offer_order_id,cust_order_id FROM so1.ord_srvpkg)e
WHERE a.cust_order_id=b.cust_order_id
AND   a.cust_order_id=c.cust_order_id
AND   a.cust_order_id=d.cust_order_id
AND   a.cust_order_id=e.cust_order_id
AND   b.busioper_order_id=c.busioper_order_id
AND   b.busioper_order_id=d.busioper_order_id
AND   c.offer_order_id=d.offer_order_id
AND   c.offer_order_id=e.offer_order_id
AND   a.business_id=800001000019
) t
GROUP BY t.prod_inst_id,t.own_corp_org_id
MINUS
SELECT prod_inst_id,own_corp_org_id,done_code max_code_code FROM so1.ord_sync_sub_info ';
  /*dbms_output.put_line(v_sql1||v_sql2);*/
  EXECUTE immediate v_sql1 || v_sql2;
  COMMIT;

  UPDATE so1.ord_sync_sub_info a
     SET a.done_code = (SELECT max_done_code
                          FROM so1.tmp_sub_info b
                         WHERE a.prod_inst_id = b.prod_inst_id
                           AND a.done_code < b.max_done_code),
         a.state0    = 1,
         a.state1    = 1,
         a.state2    = 1,
         a.state3    = 1,
         a.state4    = 1,
         a.state5    = 1,
         a.state6    = 1,
         a.state7    = 1,
         a.update_date=SYSDATE 
   WHERE EXISTS (SELECT 1
            FROM so1.tmp_sub_info b
           WHERE a.prod_inst_id = b.prod_inst_id
             AND a.done_code < b.max_done_code);
  COMMIT;

  INSERT INTO so1.ord_sync_sub_info
    (prod_inst_id,
     done_code,
     update_date,
     own_corp_org_id,
     state0,
     state1,
     state2,
     state3,
     state4,
     state5,
     state6,
     state7)
    SELECT prod_inst_id,
           max_done_code,
           SYSDATE,
           own_corp_org_id,
           1,
           1,
           1,
           1,
           1,
           1,
           1,
           1
      FROM so1.tmp_sub_info b
     WHERE NOT EXISTS (SELECT 1
              FROM so1.ord_sync_sub_info a
             WHERE a.prod_inst_id = b.prod_inst_id);
  COMMIT;

exception
  when others then
    dbms_output.put_line(sqlcode);
    dbms_output.put_line(sqlerrm);
    ROLLBACK;
END p_sync_sub_info;




/

