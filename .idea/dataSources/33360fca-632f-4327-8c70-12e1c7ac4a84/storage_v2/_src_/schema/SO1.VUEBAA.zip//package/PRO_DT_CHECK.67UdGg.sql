create PACKAGE       "PRO_DT_CHECK" 
As
   c_sync Number;
   v_result Number;
   Type t_old_cust_mode Is Record (
        old_cust               Number,
        old_con               Number,
        old_addr              Number,
        old_acct               Number
   );                                                              /*???????*/

   Type t_new_cust_mode Is Record (
        new_cust               Number,
        new_con               Number,
        new_addr              Number,
        new_acct              Number,
        invalid_cust          Number
   );                                                           /*???????*/

   Type t_old_sub_mode Is Record (
        old_sub                 Number,
        old_subp               Number
   );

   Type t_new_sub_mode Is Record (
        new_sub                Number,
        new_offer              Number,
        new_srvpkg           Number,
        new_srv                Number
   );

   Type t_old_book Is Record (
        old_book_10 Number,
        old_book_20 Number,
        old_book_30 Number,
        old_book_40 Number,
        old_book_50 Number,
        old_book_60 Number,
        old_book_70 Number,
        old_book_80 Number,
        old_book_110 Number,
        old_book_120 Number
   );

    Type t_new_book Is Record (
        new_10_vs_102001                        Number,
        new_20_vs_102002                        Number,
        new_30_40_vs_106001                  Number,
        new_50_vs_101001                        Number,
        new_60_vs_108001                        Number,
        new_70_80_vs_107001                  Number,
        new_110_vs_104001                     Number,
        new_120_vs_104003                     Number
   );

   Procedure record_data(v_data In Varchar2);                                                          --??????? ????so1.tmp_record_data
   Procedure get_old_cust(v_old_cust_mode Out t_old_cust_mode);                           --???????     v_result:=-1;
   Procedure get_new_cust(v_new_cust_mode Out t_new_cust_mode);                      --???????     v_result:=-2;
   Procedure get_old_sub(v_old_sub_mode Out t_old_sub_mode);                             --???????      v_result:=-3;
   Procedure get_new_sub(v_new_sub_mode Out t_new_sub_mode);                        --???????      v_result:=-4;
   Procedure get_old_book(v_old_book Out t_old_book);                                          --???????       v_result:=-5;
   Procedure get_new_book(v_new_book Out t_new_book);                                     --???????        v_result:=-6;
End pro_dt_check;





/

