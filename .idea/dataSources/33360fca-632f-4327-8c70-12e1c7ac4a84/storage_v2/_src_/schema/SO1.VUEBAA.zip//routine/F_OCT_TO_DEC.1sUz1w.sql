create FUNCTION       "F_OCT_TO_DEC" (p_str IN VARCHAR2) RETURN VARCHAR2 IS
  ----------------------------------------------------------------------------------------------------------------------
  -- ????: f_oct_to_dec
  -- ????: ????????
  -- ????: p_str ??????
  -- ????: ??????
  -- ????: SELECT pkg_number_trans.f_oct_to_dec('3612') FROM dual;
  ----------------------------------------------------------------------------------------------------------------------
  v_return VARCHAR2(4000);
  BEGIN
  SELECT SUM(data1) INTO v_return
  FROM (SELECT substr(p_str, rownum, 1) * power(8, length(p_str) - rownum) data1
  FROM dual
  CONNECT BY rownum <= length(p_str));
  RETURN v_return;
  EXCEPTION
  WHEN OTHERS THEN
  RETURN NULL;
  END f_oct_to_dec;






/

