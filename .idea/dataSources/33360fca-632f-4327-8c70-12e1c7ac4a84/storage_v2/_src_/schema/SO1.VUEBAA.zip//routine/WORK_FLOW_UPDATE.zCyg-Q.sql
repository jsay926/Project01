create procedure work_flow_update
as
v_count number(5);
begin
   select count(1) into v_count from so1.vm_work_flow t where t.state=99 and t.error_count<5;
   if v_count > 0 then
  delete from so1.temp_task_id;
  commit;
  insert into so1.temp_task_id select task_id from so1.vm_work_flow t where t.state=99 and t.error_count<5;
  commit;
  update so1.vm_work_flow t set t.state =2 where t.task_id in(select t1.task_id from so1.temp_task_id t1);
  update so1.vm_schedule t set t.state='W' where t.workflow_id in (select t1.task_id from so1.temp_task_id t1 );
  commit;
  end if;
end;





/

