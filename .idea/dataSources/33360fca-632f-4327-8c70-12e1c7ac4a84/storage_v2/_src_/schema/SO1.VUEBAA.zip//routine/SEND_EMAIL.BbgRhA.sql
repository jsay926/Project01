create procedure send_Email(txt varchar2)
IS 
SenderAddress Varchar2(30) := 'yujing2@cccar.com.cn'; 
ReceiverAddress varchar2(200) := 'ningmeituer@163.com'; 
EmailServer varchar2(30) := 'mail.asiainfo-linkage.com'; 
Port number := 25; 

conn UTL_SMTP.CONNECTION; 
crlf VARCHAR2( 2 ):= CHR( 13 ) || CHR( 10 ); 
contentmsg VARCHAR2( 60 ) := 'hello'; 
mesg VARCHAR2( 4000 ); 
mesg_body varchar2(4000); 
BEGIN 

conn:= utl_smtp.open_connection( EmailServer, Port ); 
utl_smtp.helo( conn, EmailServer ); 
utl_smtp.mail( conn, SenderAddress); 
utl_smtp.rcpt( conn, ReceiverAddress ); 

mesg:= 
'Content-Type: text/plain; Charset=GB2312' || crlf || 
'Date:' || TO_CHAR( SYSDATE, 'dd Mon yy hh24:mi:ss' ) || crlf || 
'From:' || SenderAddress || crlf || 
'Subject: Sending Mail with Oracle PL/SQL' || crlf || 
'To: '|| ReceiverAddress || crlf || 
'' || crlf || txt || crlf ; 

utl_smtp.data( conn, mesg ); 
utl_smtp.quit( conn ); 

END;



/

