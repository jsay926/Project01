create trigger TRG_SRVPKG_OSSTATE_CHANGE
  after update
  on INS_SRVPKG
  for each row
  declare
        v_cust_id NUMBER(14);
  --需要开启自治事务
   PRAGMA AUTONOMOUS_TRANSACTION;
begin
       v_cust_id:=0;
         /* so1.ins_srvpkg 字段'osstatue'字段有变化*/
       IF  nvl(:Odata.OS_STATUS,0) <> nvl(:Ndata.OS_STATUS,0)  THEN
         BEGIN
             SELECT cm.cust_id into v_cust_id from so1.ins_prod prod,so1.batchsyn_custinf cm WHERE prod.prod_inst_id=:Odata.PROD_INST_ID and prod.cust_id=cm.cust_id;

               if  v_cust_id > 0  then
                    update so1.batchsyn_custinf   b   set b.update_date = sysdate ,  b.done_code=0, b.state1=1 where b.cust_id=v_cust_id;
                    commit;
              end if;

          END;

       END IF;
 EXCEPTION
 WHEN OTHERS THEN  null;
  --   DBMS_OUTPUT.PUT_LINE(SQLCODE||’---‘||SQLERRM);
end ;




/

