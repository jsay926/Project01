create PROCEDURE prod_tzpfmxbb(
                      --v_orgId1       VARCHAR2 ,  --营业厅 id
                      v_operatorId   VARCHAR2 ,  --营业员 id，一个或多个
                      v_backType     VARCHAR , --退账赔付类型
                      v_fromDate     DATE , --开始时间
                      v_toDate       DATE --结束时间
                      ) is
   bill_month varchar2(200);
   v_active_sql varchar2(200);
   v_active_sql1 varchar2(200);
   ls_sql varchar2(3000);
begin

        bill_month := to_char(nvl(v_toDate, SYSDATE), 'yyyymm');
        v_active_sql := '';
        IF v_backType <>'0' THEN
           v_active_sql := ' and back.operation_type = '||v_backType;
        END IF;

        v_active_sql1 := ''; 
        IF(v_operatorId IS NOT NULL ) THEN 
            v_active_sql1 := ' AND staff.staff_id in ('|| v_operatorId ||') ';
        END IF;

 ls_sql:='SELECT org.organize_name 营业厅,
       staff.staff_name 操作员,
       cust.cust_code 客户证号,
       cust.cust_name 客户名称,
       back.deal_time 受理时间,
       --decode(pay.PAYED_METHOD, 1, ''现金'', 2, ''银行托收'', 3, ''充值卡'', 4, ''支票'',''其他'') 缴费方式,
       (case when back.operation_type in(116000, 117000) then -back.amount/100 else back.amount/100  end) 金额,
       decode(back.operation_type, ''116000'', ''退账本余额'', ''117000'', ''现金赔付'', ''118000'', ''赔付到账本'',''119000'',''补收'', ''其他'')  退赔付类型,
       back.acct_item_name  退赔付子类型,
       --decode(back.operation_type, ''117000'', ''现金赔付'', ''118000'', ''赔付到账本'', ''其他'') 退赔付标识,
       btype.balance_type_name  账本
  FROM  zg.acct_blc_back_rec back
  left JOIN sec.sec_organize org ON back.org_id=org.organize_id
 left JOIN sec.sec_operator op ON back.staff_id = op.operator_id
 left JOIN sec.sec_staff staff ON op.staff_id = staff.staff_id
 left JOIN so1.acct acct ON back.acct_id=acct.acct_id
 left join so1.cm_customer cust on cust.cust_id = acct.cust_id
 LEFT JOIN zg.balance_type btype ON back.balance_type_id=btype.balance_type_id
 WHERE back.state = 0 and back.deal_time BETWEEN
       to_date(''' || to_char(v_fromDate, 'yyyy-MM-dd')||''',''yyyy-MM-dd'')
       and to_date(''' || to_char(v_toDate, 'yyyy-MM-dd') || ''',''yyyy-MM-dd'')+0.999999
       '||v_active_sql||' 
       '||v_active_sql1||'        
       order by back.deal_time';

--  open v_cur for ls_sql;

        -- 异常处理
    exception
        when others then
null;
end;




/

