create FUNCTION       "F_DEC_TO_OCT" (p_int IN VARCHAR2)
	RETURN VARCHAR2 IS
	----------------------------------------------------------------------------------------------------------------------
	-- ????: f_dec_to_oct
	-- ????: ????????
	-- ????: p_str ??????
	-- ????: ??????
	-- ????: SELECT pkg_number_trans.f_dec_to_oct('1930') FROM dual;
	----------------------------------------------------------------------------------------------------------------------
	v_return VARCHAR2(4000);
	v_bin    VARCHAR2(4000);
BEGIN
	SELECT pkg_number_trans.f_dec_to_bin(p_int) INTO v_bin FROM dual;
	v_bin := substr('00' || v_bin, -3 * ceil(length(v_bin) / 3));
	SELECT f_stragg(data1)
		INTO v_return
		FROM (SELECT (CASE upper(substr(v_bin, (rownum - 1) * 3 + 1, 3))
									 WHEN '000' THEN
										'0'
									 WHEN '001' THEN
										'1'
									 WHEN '010' THEN
										'2'
									 WHEN '011' THEN
										'3'
									 WHEN '100' THEN
										'4'
									 WHEN '101' THEN
										'5'
									 WHEN '110' THEN
										'6'
									 WHEN '111' THEN
										'7'
								 END) data1
						FROM dual
					CONNECT BY rownum <= length(v_bin) / 3);
	RETURN v_return;
EXCEPTION
	WHEN OTHERS THEN
		RETURN NULL;
END f_dec_to_oct;





/

