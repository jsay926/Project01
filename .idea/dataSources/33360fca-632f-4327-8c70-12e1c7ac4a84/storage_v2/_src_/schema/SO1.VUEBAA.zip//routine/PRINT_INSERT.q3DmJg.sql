create PROCEDURE     "PRINT_INSERT" (v_tname             VARCHAR2,
                                          in_where_str    VARCHAR2)

AS
   /* ???????? */
   TYPE cur_alldata IS REF CURSOR;

   l_alldata   cur_alldata;
   /* ???????v_row*/
   v_sql       VARCHAR2 (3999);
   v_row       VARCHAR2 (3999);
   v_string    VARCHAR2 (3999);

   /* ??????? */
   FUNCTION formatfield (v_tname VARCHAR2, v_cname VARCHAR2, v_colno NUMBER)
      RETURN VARCHAR2;

   /* ??????? */
   FUNCTION formatdata (v_tname VARCHAR2, v_row VARCHAR2)
      RETURN VARCHAR2
   AS
      v_ldata   VARCHAR2 (32765);
      v_rdata   VARCHAR2 (32765);
      v_cname   VARCHAR2 (3999);
      v_instr   NUMBER;
      v_count   NUMBER;
      v_row_cout number;
   BEGIN
      v_instr := INSTR (v_row, '(');
      v_ldata := SUBSTR (v_row, 1, v_instr);
      v_rdata := SUBSTR (v_row, v_instr + 1);
      v_instr := INSTR (v_rdata, ')');
      v_rdata := SUBSTR (v_rdata, 1, v_instr - 1);

      v_count := 0;
      v_row_cout:=0;

      LOOP
         v_instr := INSTR (v_rdata, ',');
         select count(*) into v_row_cout
         from col 
         WHERE tname = UPPER (v_tname); 
         EXIT WHEN v_count = v_row_cout-1;
         
         v_cname := SUBSTR (v_rdata, 1, v_instr - 1);
         v_rdata := SUBSTR (v_rdata, v_instr + 1);
         v_count := v_count + 1;
         /* ?????????? */
         v_cname := formatfield (v_tname, v_cname, v_count);

         /* ??????????v_ldata */
         IF v_count = 1
         THEN
            v_ldata := v_ldata || v_cname;
         ELSE
            v_ldata := v_ldata || ',' || v_cname;
         END IF;
      END LOOP;



      /* ?????????? */
      IF v_count = 1
      THEN
         v_ldata :=
            v_ldata || formatfield (v_tname, v_rdata, v_count + 1) || ');';
      ELSE
         v_ldata :=
               v_ldata
            || ','
            || formatfield (v_tname, v_rdata, v_count + 1)
            || ');';
      END IF;
      RETURN v_ldata;
   END;

   /* ????????????? */
   FUNCTION formatfield (v_tname VARCHAR2, v_cname VARCHAR2, v_colno NUMBER)
      RETURN VARCHAR2
   AS
      v_name   VARCHAR2 (3999);
      v_type   VARCHAR2 (99);
   BEGIN
      SELECT coltype
        INTO v_type
        FROM col
       WHERE tname = UPPER (v_tname) AND colno = v_colno;

      IF v_type = 'DATE'
      THEN
         v_name :=
               'to_date('
            || ''''
            || v_cname
            || ''''
            || ','
            || ''''
            || 'yyyy-mm-dd hh24:mi:ss'
            || ''''
            || ')';
      ELSIF v_type = 'VARCHAR2'
      THEN
         v_name := '''' || v_cname || '''';
      else
        if(v_cname is null) THEN
          v_name := '''' || v_cname || '''';
        else
           v_name := v_cname;
        end if ;
      END IF;

      RETURN v_name;
   END;

   /* ????????? */
   FUNCTION getfields (v_tname VARCHAR2)
      RETURN VARCHAR2
   AS
      v_fields   VARCHAR2 (3999);
   BEGIN
      FOR cur_fname IN (  SELECT cname, coltype
                            FROM col
                           WHERE tname = UPPER (v_tname)
                        ORDER BY colno)
      LOOP
         IF v_fields IS NULL
         THEN
            v_fields :=
               'nvl(' || cur_fname.cname || ',' || '''' || '0' || '''' || ')';
         ELSE
            v_fields :=
                  v_fields
               || '||'',''||'
               || 'nvl('
               || cur_fname.cname
               || ','
               || ''''
               || ''
               || ''''
               || ')';
         END IF;
      END LOOP;

      v_fields :=
            'select '
         || ''''
         || 'insert into so1.'
         || v_tname
         || ' values ('
         || ''''
         || '||'
         || v_fields
         || '||'
         || ''''
         || ')'
         || ''''
         || ' from '
         || v_tname
         || ' '|| in_where_str;
      RETURN v_fields;
   END;
BEGIN
   EXECUTE IMMEDIATE
         'alter session set nls_date_format='
      || ''''
      || 'yyyy-mm-dd hh24:mi:ss'
      || '''';


   dbms_output.enable(10000000000);
 
   DBMS_OUTPUT.put_line ('************************************??'||v_tname||'??************************************');

   v_sql := getfields (v_tname);

   --dbms_output.put_line(v_sql);
   OPEN l_alldata FOR v_sql;

   LOOP
      FETCH l_alldata INTO v_row;

      EXIT WHEN l_alldata%NOTFOUND;
      --dbms_output.put_line(v_row);
      v_string:=formatdata (v_tname, v_row);
      DBMS_OUTPUT.put_line (v_string);
   --if mod(l_alldata%rowcount,v_cbatch) = 0 then
   --dbms_output.put_line('commit;');
   --end if;
   END LOOP;

   CLOSE l_alldata;
END;





/

