create procedure CHECK_INST_PROD_RES_TWO(res_equ_no in varchar2, p_rtn_code out number) as

v_res_equ_no varchar2(60);
sqlstr1 varchar2(2000);

begin

  p_rtn_code := 0;
  v_res_equ_no := res_equ_no;

  sqlstr1 := 'select count(distinct T2.Prod_Inst_Id)
  from (select f.Res_Equ_No2, f.Cust_Id
          from So1.Ins_Prod_Res f
        union
        select c.Res_Equ_No2, d.Cust_Id
          from So1.Ord_Prod_Res c, So1.Ord_Cust d
         where c.Cust_Order_Id = d.Cust_Order_Id) t
  left join (select a.Cust_Id,
                    a.Res_Equ_No2,
                    a.Res_Code,
                    a.Prod_Inst_Id,
                    a.Res_Type
               from So1.Ins_Prod_Res a
             union
             select Op.Cust_Id,
                    b.Res_Equ_No2,
                    b.Res_Code,
                    Op.Prod_Inst_Id,
                    b.Res_Type
               from So1.Ord_Prod_Res b, So1.Ord_Prod Op
              where Op.Cust_Order_Id = b.Cust_Order_Id
                and Op.Prod_Order_Id = b.Prod_Order_Id) T2
    on T2.Cust_Id = t.Cust_Id
   and T2.Res_Equ_No2 = t.Res_Equ_No2
  left join Res.Res_Code_Definition De
    on De.Res_Sub_Type = T2.Res_Type
   and T2.Res_Code = De.Res_Code
  left join So1.Ins_Srvpkg Sp1
    On T2.Prod_Inst_Id = Sp1.Prod_Inst_Id
   And Sp1.State = 1
   And Sp1.Prod_Service_Id = 1003
  left Join (select Ff.Prod_Inst_Id, Dd.Prod_Service_Id, Dd.State
               from So1.Ord_Srvpkg Dd, So1.Ord_Prod Ff
              where Dd.Cust_Order_Id = Ff.Cust_Order_Id
                and Dd.Prod_Order_Id = Ff.Prod_Order_Id) Sp
    on Sp.Prod_Inst_Id = T2.Prod_Inst_Id and Sp.Prod_Service_Id = 1003
 where t.Res_Equ_No2 = '''||v_res_equ_no||'''
   and De.Res_Type = 2';

  dbms_output.put_line(sqlstr1);
  execute immediate sqlstr1
  into p_rtn_code;
end CHECK_INST_PROD_RES_TWO;


/

